
export type GameMode = '1min' | '3min' | '5min';

export interface GameResult {
    period: string;
    number: number;
    size: 'Big' | 'Small';
    colors: ('Green' | 'Red' | 'Violet')[];
}

export interface UserBet {
    id: string;
    period: string;
    selection: string; // "Green", "Red", "Violet", "0"-"9", "Big", "Small"
    amount: number; // Total amount bet
    quantity: number; // Multiplier of base amount
    winLoss: number; // 0 if pending
    status: 'Pending' | 'Won' | 'Lost';
    resultColor?: string; 
    fee: number; // Commission fee
    userId?: string; // Added for Admin tracking
    userName?: string; // Added for Admin tracking
}

export type BetType = 'Color' | 'Number' | 'Size';

export interface BankDetails {
    accountHolder: string;
    bankName: string;
    accountNumber: string;
    ifscCode: string;
    upiId: string;
    qrCodeImage?: string;
}

export interface UserProfile {
    name: string;
    identifier: string; // Phone or Email
    mobile?: string; // Specific mobile field for Google users (where identifier is email)
    password: string;
    village: string;
    block: string;
    district: string;
    
    // --- New Wallet Logic ---
    balance: number;        // "Wallet" - Winnings (Withdrawable)
    bankMoney: number;      // "Bank Money" - Deposits (Locked for withdrawal, usable for bets)
    bonusMoney: number;     // "Bonus" - Admin given (Locked)
    bonusWagerTarget: number; // Total bet amount required to unlock bonus
    bonusWagerProgress: number; // Current progress
    
    // --- MLM / Network Fields ---
    mlmWallet: number; // Commission claimed from pyramid scheme
    joinedAt: number; // Registration timestamp
    lastActiveDeposit: number; // Timestamp of last deposit >= 100 (for Monthly Active status)
    // ------------------------

    // --- Daily Streak & Deposit Bonus Logic ---
    depositStreak?: {
        currentDay: number;
        lastDepositDate: number; // Timestamp
    };
    isFirstDeposit?: boolean;
    // ------------------------

    // --- ID Card & Verification ---
    recoveryEmail?: string;
    isCardVerified?: boolean;
    // ------------------------------

    isAdmin: boolean;
    adminRole?: 'super' | 'guest'; 
    permissions?: string[]; // List of allowed tabs for Guest Admins
    isBlocked: boolean;
    referralCode: string;
    referredBy?: string; 
    referralIncome: number;
    profileImage?: string; 
    
    // Withdrawal Activation
    withdrawalActive: boolean;
    bankDetails?: BankDetails;

    // Daily Bonus & Tasks
    lastCheckIn?: number; // Timestamp of last daily claim
    completedTasks?: string[]; // Deprecated in favor of taskHistory
    
    // NEW: Detailed Task History for Daily/One-time logic
    taskHistory?: {
        taskId: string;
        timestamp: number;
    }[];
}

export interface Transaction {
    id: string;
    userId: string;
    userName: string;
    type: 'Deposit' | 'Withdrawal' | 'Referral' | 'Bonus' | 'MLM_Claim' | 'Task_Reward'; // Added Task_Reward
    amount: number;
    
    // --- Bonus Fields ---
    bonusAmount?: number; // The calculated bonus to be added
    appliedBonusDesc?: string; // Description e.g., "Day 5 Streak (7%)"
    // --------------------

    status: 'Pending' | 'Approved' | 'Rejected' | 'Success';
    timestamp: number;
    utr?: string; // For deposits
    
    // Withdrawal Details snapshot
    upiId?: string; 
    userQrCode?: string; 
    bankDetailsSnapshot?: string; // JSON string of bank details for Admin
    
    adminProofImage?: string; // For Withdrawal Approval Proof
}

export interface AppNotification {
    id: string;
    userId: string;
    title: string;
    message: string;
    image?: string;
    link?: string; // Added optional link field
    timestamp: number;
    read: boolean;
}

export interface ChatMessage {
    id: string;
    sender: 'User' | 'Admin';
    text: string;
    image?: string; 
    timestamp: number;
    userId?: string; 
}

export interface AdminConfig {
    upiId: string;
    qrCode: string;
    // OTP & Notification Service Config
    otpService: 'mock' | 'sms' | 'whatsapp' | 'email';
    smsApiKey: string;
    whatsappApiKey: string;
    whatsappInstanceId: string;
    gmailUser: string;
    gmailPass: string; // App Password
}

export interface TaskConfig {
    whatsappTarget: number;
    facebookTarget: number;
    instagramTarget: number;
    bonusAmount: number;
    description: string;
}

// OLD INTERFACE - Kept for backward compatibility if needed, but AdminTask is preferred
export interface PromotionalTask {
    id: string;
    title: string;
    link: string;
    image: string; // Base64
    reward: number;
    active: boolean;
    createdAt: number;
}

// NEW: Detailed Task Structure for "Daily Task Work"
export interface AdminTask {
    id: string;
    title: string;
    description: string;
    image: string; // Base64
    link: string;
    reward: number;
    rewardDest?: 'balance' | 'bankMoney' | 'bonusMoney'; // Control where the reward goes
    type: 'onetime' | 'daily';
    active: boolean;
    limit?: number; // Optional limit on total users
    createdAt: number;
    expiresAt?: number; // Timestamp for expiry
}

// --- AVIATOR ADMIN CONTROLS ---
export type AdminProfitMode = 'NONE' | 'PROFIT_30' | 'PROFIT_60' | 'PROFIT_80';

export interface AviatorAdminConfig {
  profitMode: AdminProfitMode;
  manualCrashX?: number | null;
  houseEdgeTarget: number;
  updatedAt: number;
  lastUpdatedBy?: string; // For audit
}
