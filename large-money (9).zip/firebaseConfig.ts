
// Firebase Removed
export const auth = null;
export const app = null;
export const googleProvider = null;
