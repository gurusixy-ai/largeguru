import React, { useState, useRef } from 'react';
import { UserProfile, BankDetails } from '../types';

interface BankActivationProps {
    user: UserProfile;
    onUpdateUser: (updatedUser: UserProfile) => void;
    onBack: () => void;
}

const BankActivation: React.FC<BankActivationProps> = ({ user, onUpdateUser, onBack }) => {
    const [formData, setFormData] = useState<BankDetails>({
        accountHolder: user.bankDetails?.accountHolder || '',
        bankName: user.bankDetails?.bankName || '',
        accountNumber: user.bankDetails?.accountNumber || '',
        ifscCode: user.bankDetails?.ifscCode || '',
        upiId: user.bankDetails?.upiId || '',
        qrCodeImage: user.bankDetails?.qrCodeImage || ''
    });

    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleQrUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData(prev => ({ ...prev, qrCodeImage: reader.result as string }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.accountNumber || !formData.ifscCode || !formData.accountHolder || !formData.qrCodeImage) {
            alert("Please fill all required bank details and upload QR Code.");
            return;
        }

        const updatedUser: UserProfile = {
            ...user,
            withdrawalActive: true,
            bankDetails: formData
        };

        onUpdateUser(updatedUser);
        alert("Wallet Activation Successful! You can now request withdrawals.");
        onBack(); // Go back to Withdraw page or Menu
    };

    const inputClass = "w-full bg-gray-50 border border-gray-300 rounded-lg px-4 py-3 text-gray-900 focus:ring-2 focus:ring-primary outline-none transition-all font-medium";
    const labelClass = "block text-xs font-bold text-gray-500 uppercase mb-1.5";

    return (
        <div className="min-h-screen bg-background-light dark:bg-background-dark pb-10 w-full">
            <header className="bg-white dark:bg-surface-dark border-b border-gray-200 dark:border-gray-800 p-4 sticky top-0 z-50">
                <div className="w-full flex items-center gap-3">
                    <button onClick={onBack} className="text-gray-500 hover:text-primary">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </button>
                    <h1 className="font-bold text-lg text-gray-900 dark:text-white">Activate Wallet</h1>
                </div>
            </header>

            <main className="w-full p-4 animate-fade-in">
                <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl flex gap-3 mb-6">
                    <span className="material-symbols-outlined text-blue-600">verified_user</span>
                    <div>
                        <h3 className="font-bold text-blue-800 text-sm">One-Time Activation Required</h3>
                        <p className="text-xs text-blue-600 mt-1">Please provide your Bank Details and QR Code to enable withdrawals. These details will be used by Admin to send your winnings.</p>
                    </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-5 bg-white dark:bg-surface-dark p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
                    
                    <div>
                        <label className={labelClass}>Account Holder Name</label>
                        <input type="text" className={inputClass} placeholder="As per Bank Records" value={formData.accountHolder} onChange={e => setFormData({...formData, accountHolder: e.target.value})} required />
                    </div>

                    <div>
                        <label className={labelClass}>Bank Name</label>
                        <input type="text" className={inputClass} placeholder="e.g. SBI, HDFC" value={formData.bankName} onChange={e => setFormData({...formData, bankName: e.target.value})} required />
                    </div>

                    <div>
                        <label className={labelClass}>Account Number</label>
                        <input type="text" className={inputClass} placeholder="Enter Account Number" value={formData.accountNumber} onChange={e => setFormData({...formData, accountNumber: e.target.value})} required />
                    </div>

                    <div>
                        <label className={labelClass}>IFSC Code</label>
                        <input type="text" className={inputClass} placeholder="e.g. SBIN0001234" value={formData.ifscCode} onChange={e => setFormData({...formData, ifscCode: e.target.value})} required />
                    </div>

                    <div>
                        <label className={labelClass}>UPI ID (Optional)</label>
                        <input type="text" className={inputClass} placeholder="username@upi" value={formData.upiId} onChange={e => setFormData({...formData, upiId: e.target.value})} />
                    </div>

                    <div className="border-t border-gray-100 pt-4">
                        <label className={labelClass}>Upload Payment QR Code (Required)</label>
                        <div className="flex items-center gap-4 mt-2">
                            <div 
                                onClick={() => fileInputRef.current?.click()}
                                className="size-24 border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center bg-gray-50 cursor-pointer overflow-hidden relative"
                            >
                                {formData.qrCodeImage ? (
                                    <img src={formData.qrCodeImage} className="w-full h-full object-cover" alt="QR" />
                                ) : (
                                    <span className="material-symbols-outlined text-gray-400">add_a_photo</span>
                                )}
                            </div>
                            <div className="flex-1">
                                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleQrUpload} />
                                <button type="button" onClick={() => fileInputRef.current?.click()} className="text-sm font-bold text-primary hover:underline">
                                    Click to Upload QR
                                </button>
                                <p className="text-xs text-gray-400 mt-1">This QR will be used by Admin for payments.</p>
                            </div>
                        </div>
                    </div>

                    <button type="submit" className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-4 rounded-xl shadow-lg mt-4 transition-transform active:scale-95">
                        Save & Activate Wallet
                    </button>

                </form>
            </main>
        </div>
    );
};

export default BankActivation;