
import React, { useState, useEffect } from 'react';
import { UserProfile, AdminTask, Transaction } from '../types';

interface TaskPageProps {
    user: UserProfile;
    onBack: () => void;
    onUpdateUser: (updatedUser: UserProfile) => void;
}

const TaskPage: React.FC<TaskPageProps> = ({ user, onBack, onUpdateUser }) => {
    const [tasks, setTasks] = useState<AdminTask[]>([]);
    const [loadingMap, setLoadingMap] = useState<Record<string, boolean>>({});
    const [verifyingMap, setVerifyingMap] = useState<Record<string, boolean>>({});
    const [totalTaskEarnings, setTotalTaskEarnings] = useState(0);

    useEffect(() => {
        // Load Tasks
        const storedTasks = JSON.parse(localStorage.getItem('ncci_admin_tasks') || '[]');
        setTasks(storedTasks.filter((t: AdminTask) => t.active));

        // Calculate Total Task Earnings from Transactions
        const trans = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
        const taskIncome = trans
            .filter((t: Transaction) => t.userId === user.identifier && t.type === 'Task_Reward')
            .reduce((acc: number, t: Transaction) => acc + t.amount, 0);
        setTotalTaskEarnings(taskIncome);
    }, [user.identifier]);

    // Check if task is completed or expired
    const getTaskStatus = (task: AdminTask): 'pending' | 'completed' | 'expired' => {
        // Expiry Check
        if (task.expiresAt && Date.now() > task.expiresAt) {
            return 'expired';
        }

        const history = user.taskHistory || [];
        const lastEntry = history.filter(h => h.taskId === task.id).sort((a,b) => b.timestamp - a.timestamp)[0];

        if (!lastEntry) return 'pending';

        if (task.type === 'onetime') {
            return 'completed';
        } else {
            // Daily Task Check
            const lastDate = new Date(lastEntry.timestamp).setHours(0,0,0,0);
            const today = new Date().setHours(0,0,0,0);
            return lastDate === today ? 'completed' : 'pending';
        }
    };

    const handleStartTask = (task: AdminTask) => {
        // Open Link
        window.open(task.link, '_blank');
        
        // Set loading/verifying state
        setLoadingMap(prev => ({ ...prev, [task.id]: true }));
        
        // Simulate "Doing" the task
        setTimeout(() => {
            setLoadingMap(prev => ({ ...prev, [task.id]: false }));
            setVerifyingMap(prev => ({ ...prev, [task.id]: true }));
        }, 2000); 
    };

    const handleClaimReward = (task: AdminTask) => {
        // 1. Credit to Configured Destination
        const updatedUser = { ...user };
        const dest = task.rewardDest || 'bankMoney'; // Default to bankMoney if undefined
        
        if (dest === 'balance') {
            updatedUser.balance = (updatedUser.balance || 0) + task.reward;
        } else if (dest === 'bonusMoney') {
            updatedUser.bonusMoney = (updatedUser.bonusMoney || 0) + task.reward;
        } else {
            // bankMoney
            updatedUser.bankMoney = (updatedUser.bankMoney || 0) + task.reward;
        }

        // Add to history
        updatedUser.taskHistory = [
            ...(updatedUser.taskHistory || []),
            { taskId: task.id, timestamp: Date.now() }
        ];

        // 2. Create Transaction Record
        const trans: Transaction = {
            id: 'TASK-' + Math.random().toString(36).substr(2, 9),
            userId: user.identifier,
            userName: user.name,
            type: 'Task_Reward',
            amount: task.reward,
            status: 'Success',
            timestamp: Date.now(),
            appliedBonusDesc: `Task: ${task.title} (${dest})`
        };

        const existingTrans = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
        localStorage.setItem('ncci_transactions', JSON.stringify([...existingTrans, trans]));

        // 3. Update State
        onUpdateUser(updatedUser);
        setVerifyingMap(prev => ({ ...prev, [task.id]: false }));
        setTotalTaskEarnings(prev => prev + task.reward);
        
        const destLabel = dest === 'balance' ? 'Winning Wallet' : dest === 'bonusMoney' ? 'Bonus Balance' : 'Bank Money';
        alert(`Task Completed! ₹${task.reward} added to ${destLabel}.`);
    };

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20 w-full font-display">
            {/* Header */}
            <header className="bg-gradient-to-r from-blue-600 to-indigo-700 p-6 pb-12 rounded-b-[2.5rem] relative shadow-lg">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
                <div className="relative z-10">
                    <div className="flex justify-between items-center mb-6">
                        <button onClick={onBack} className="bg-white/20 p-2 rounded-full hover:bg-white/30 transition-colors text-white">
                            <span className="material-symbols-outlined text-lg">arrow_back</span>
                        </button>
                        <h1 className="text-xl font-black text-white tracking-wide uppercase">Daily Task Work</h1>
                        <div className="size-9"></div> {/* Spacer */}
                    </div>
                    
                    <div className="text-center text-white">
                        <p className="text-xs font-bold uppercase tracking-widest opacity-80 mb-1">Total Task Earnings</p>
                        <h2 className="text-4xl font-black drop-shadow-md">₹{totalTaskEarnings.toLocaleString()}</h2>
                        <div className="mt-4 inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/20">
                            <span className="size-2 rounded-full bg-green-400 animate-pulse"></span>
                            <span className="text-[10px] font-bold">Rewards credited instantly</span>
                        </div>
                    </div>
                </div>
            </header>

            <main className="px-4 -mt-6 relative z-20 space-y-4">
                {tasks.length === 0 ? (
                    <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 text-center shadow-lg border border-gray-100 dark:border-gray-700">
                        <div className="size-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-3">
                            <span className="material-symbols-outlined text-3xl text-gray-400">assignment_late</span>
                        </div>
                        <h3 className="font-bold text-gray-600 dark:text-gray-300">No Tasks Available</h3>
                        <p className="text-xs text-gray-400 mt-1">Check back later for new earning opportunities.</p>
                    </div>
                ) : (
                    tasks.map(task => {
                        const status = getTaskStatus(task);
                        const isVerifying = verifyingMap[task.id];
                        const isLoading = loadingMap[task.id];

                        return (
                            <div key={task.id} className={`bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700 flex gap-4 transition-all ${status === 'completed' || status === 'expired' ? 'opacity-60 grayscale' : 'hover:shadow-lg hover:scale-[1.01]'}`}>
                                {/* Task Image */}
                                <div className="size-20 shrink-0 bg-gray-100 rounded-xl overflow-hidden shadow-inner relative">
                                    {task.image ? (
                                        <img src={task.image} alt="Task" className="size-full object-cover" />
                                    ) : (
                                        <div className="size-full flex items-center justify-center text-blue-500">
                                            <span className="material-symbols-outlined text-3xl">task</span>
                                        </div>
                                    )}
                                    {task.type === 'daily' && (
                                        <div className="absolute top-0 right-0 bg-orange-500 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-bl-lg">DAILY</div>
                                    )}
                                </div>

                                {/* Content */}
                                <div className="flex-1 flex flex-col justify-between">
                                    <div>
                                        <h3 className="font-bold text-sm text-gray-900 dark:text-white leading-tight mb-1">{task.title}</h3>
                                        <p className="text-[10px] text-gray-500 line-clamp-2 leading-relaxed">{task.description}</p>
                                    </div>
                                    
                                    <div className="flex items-center justify-between mt-3">
                                        <div className="text-green-600 font-black text-sm bg-green-50 px-2 py-1 rounded-lg">
                                            +₹{task.reward}
                                        </div>

                                        {status === 'expired' ? (
                                            <button disabled className="px-4 py-1.5 bg-red-100 text-red-500 text-[10px] font-bold rounded-lg flex items-center gap-1 cursor-not-allowed border border-red-200">
                                                <span className="material-symbols-outlined text-sm">event_busy</span> Expired
                                            </button>
                                        ) : status === 'completed' ? (
                                            <button disabled className="px-4 py-1.5 bg-gray-100 text-gray-400 text-[10px] font-bold rounded-lg flex items-center gap-1 cursor-default">
                                                <span className="material-symbols-outlined text-sm">check_circle</span> Done
                                            </button>
                                        ) : isVerifying ? (
                                            <button 
                                                onClick={() => handleClaimReward(task)}
                                                className="px-4 py-1.5 bg-green-500 text-white text-[10px] font-bold rounded-lg shadow-lg shadow-green-500/30 animate-pulse flex items-center gap-1 hover:bg-green-600 transition-colors"
                                            >
                                                <span className="material-symbols-outlined text-sm">redeem</span> Claim
                                            </button>
                                        ) : (
                                            <button 
                                                onClick={() => handleStartTask(task)}
                                                disabled={isLoading}
                                                className="px-4 py-1.5 bg-blue-600 text-white text-[10px] font-bold rounded-lg shadow-lg shadow-blue-500/30 flex items-center gap-1 hover:bg-blue-700 transition-colors active:scale-95"
                                            >
                                                {isLoading ? (
                                                    <span className="size-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                                                ) : (
                                                    <>
                                                        Start <span className="material-symbols-outlined text-sm">arrow_forward</span>
                                                    </>
                                                )}
                                            </button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        );
                    })
                )}
            </main>
        </div>
    );
};

export default TaskPage;
