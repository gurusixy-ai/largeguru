
import React from 'react';
import { UserProfile } from '../types';

interface LobbyProps {
    user: UserProfile;
    periodId: string;
    timeLeft: number;
    onPlay: () => void; // Launch Color Prediction (Win Go)
    onPlayAviator: () => void; // Launch Aviator
    onProfileClick: () => void;
    onWalletClick: () => void;
    notificationsCount: number;
}

const Lobby: React.FC<LobbyProps> = ({ user, periodId, timeLeft, onPlay, onPlayAviator, onProfileClick, onWalletClick, notificationsCount }) => {
    // Format timer for Hot Game Card
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    const timeString = `${minutes}:${seconds < 10 ? '0' + seconds : seconds}`;

    // Calculate Total User Money
    const totalMoney = user.balance + (user.bankMoney || 0) + (user.bonusMoney || 0);

    return (
        <div className="relative min-h-screen bg-slate-50 pb-28 text-slate-800 antialiased overflow-x-hidden font-sans">
            {/* Background Blobs */}
            <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
                <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] rounded-full bg-purple-200/30 blur-[80px]"></div>
                <div className="absolute top-[20%] -right-[10%] w-[40%] h-[40%] rounded-full bg-indigo-200/30 blur-[80px]"></div>
            </div>

            {/* Header */}
            <header className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-md shadow-sm border-b border-gray-100 max-w-md mx-auto left-0 right-0">
                <div className="flex items-center justify-between px-4 py-3">
                    <div className="flex items-center gap-3">
                        <div className="relative group cursor-pointer" onClick={onProfileClick}>
                            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 p-[2px] shadow-md">
                                <div className="w-full h-full bg-white rounded-full overflow-hidden flex items-center justify-center">
                                    {user.profileImage ? (
                                        <img alt="Profile" className="w-full h-full object-cover" src={user.profileImage} />
                                    ) : (
                                        <span className="text-lg font-bold text-indigo-600">{user.name.charAt(0)}</span>
                                    )}
                                </div>
                            </div>
                            <div className="absolute -bottom-0.5 -right-0.5 bg-gradient-to-r from-amber-300 to-yellow-500 text-[8px] font-black px-1.5 py-0.5 rounded-full text-white border border-white shadow-sm">
                                VIP 1
                            </div>
                        </div>
                        <div className="flex flex-col">
                            <h1 className="text-sm font-extrabold text-slate-800 tracking-tight leading-none">LARGE<span className="text-indigo-600">MONEY</span></h1>
                            <span className="text-[10px] text-slate-400 font-medium">Welcome back!</span>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <div className="relative group active:scale-95 transition-transform duration-200 cursor-pointer" onClick={onWalletClick}>
                            <div className="bg-slate-100 border border-slate-200 rounded-full pl-1 pr-3 py-1 flex items-center gap-2 shadow-inner">
                                <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-white shadow-sm">
                                    <span className="material-symbols-outlined text-[14px] font-bold">currency_rupee</span>
                                </div>
                                <span className="text-xs font-bold text-slate-800">{totalMoney.toLocaleString('en-IN', {minimumFractionDigits: 0, maximumFractionDigits: 0})}</span>
                                <div className="w-4 h-4 rounded-full bg-slate-200 flex items-center justify-center text-slate-500">
                                    <span className="material-symbols-outlined text-[10px]">add</span>
                                </div>
                            </div>
                        </div>
                        <button className="relative text-slate-400 hover:text-slate-600 transition-colors">
                            <span className="material-symbols-outlined text-[24px]">notifications</span>
                            {notificationsCount > 0 && <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white"></span>}
                        </button>
                    </div>
                </div>
            </header>

            <main className="relative z-10 pt-20 px-4 space-y-8">
                
                {/* HOT GAME SECTION - COLOR PREDICTION (WIN GO) */}
                <section>
                    <div className="flex items-center gap-2 mb-4">
                        <div className="p-1.5 bg-orange-100 text-orange-600 rounded-lg">
                            <span className="material-symbols-outlined text-lg animate-pulse">local_fire_department</span>
                        </div>
                        <div>
                            <h2 className="text-lg font-black text-slate-800 leading-none">Hot Game</h2>
                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Most Popular</p>
                        </div>
                    </div>

                    <div 
                        className="relative w-full bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-1 shadow-2xl shadow-indigo-500/20 overflow-hidden group cursor-pointer transform transition-all active:scale-[0.98]" 
                        onClick={onPlay} // STRICTLY BINDS TO COLOR PREDICTION
                    >
                        {/* Animated Background Pattern */}
                        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
                        <div className="absolute top-[-50%] right-[-20%] w-64 h-64 bg-white/10 rounded-full blur-[60px]"></div>
                        
                        <div className="relative p-6 flex flex-col h-48 justify-between">
                            <div className="flex justify-between items-start">
                                <div className="bg-white/20 backdrop-blur-md text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-wider shadow-sm border border-white/20 flex items-center gap-1">
                                    <span className="material-symbols-outlined text-sm">timer</span> {timeString}
                                </div>
                                <div className="text-right">
                                    <h3 className="text-2xl font-black text-white italic tracking-tighter">WIN GO</h3>
                                    <p className="text-[10px] text-indigo-200 font-bold uppercase tracking-widest">Color Prediction</p>
                                </div>
                            </div>

                            {/* Floating Balls Animation */}
                            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                <div className="flex gap-3">
                                    <div className="size-12 rounded-full bg-gradient-to-br from-green-400 to-green-600 shadow-lg shadow-green-900/20 animate-bounce flex items-center justify-center text-white font-black border-2 border-white/20">G</div>
                                    <div className="size-12 rounded-full bg-gradient-to-br from-violet-400 to-purple-600 shadow-lg shadow-purple-900/20 animate-bounce delay-100 flex items-center justify-center text-white font-black border-2 border-white/20">V</div>
                                    <div className="size-12 rounded-full bg-gradient-to-br from-red-400 to-red-600 shadow-lg shadow-red-900/20 animate-bounce delay-200 flex items-center justify-center text-white font-black border-2 border-white/20">R</div>
                                </div>
                            </div>

                            <button className="w-full bg-white hover:bg-gray-50 text-indigo-700 font-bold py-3 rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all mt-auto z-10">
                                PLAY NOW <span className="material-symbols-outlined text-lg">play_arrow</span>
                            </button>
                        </div>
                    </div>
                </section>

                {/* GAME CATEGORIES */}
                <div className="flex gap-2 bg-white p-1.5 rounded-xl border border-gray-100 shadow-sm overflow-x-auto no-scrollbar">
                    {['All Games', 'Slots', 'Cards', 'Live'].map((cat, idx) => (
                        <button key={cat} className={`px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${idx === 0 ? 'bg-slate-800 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>
                            {cat}
                        </button>
                    ))}
                </div>

                {/* GAME GRID */}
                <section className="grid grid-cols-2 gap-4 pb-10">
                    
                    {/* AVIATOR CARD (ACTIVE - UNIQUE HANDLER) */}
                    <div 
                        onClick={onPlayAviator} // STRICTLY BINDS TO AVIATOR
                        className="col-span-2 relative bg-[#0F1923] rounded-2xl p-4 shadow-lg cursor-pointer group active:scale-[0.98] transition-transform overflow-hidden border border-slate-700 hover:shadow-red-500/10"
                    >
                        <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-8xl text-white">flight_takeoff</span>
                        </div>
                        {/* Background Pulse */}
                        <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-red-600/20 rounded-full blur-[40px] animate-pulse"></div>

                        <div className="flex items-center gap-4 relative z-10">
                            <div className="size-16 rounded-xl bg-red-600 flex items-center justify-center shadow-lg shadow-red-600/20 text-white">
                                <span className="material-symbols-outlined text-4xl transform -rotate-12">flight_takeoff</span>
                            </div>
                            <div>
                                <h3 className="text-xl font-black text-white italic tracking-wide">AVIATOR</h3>
                                <p className="text-xs text-gray-400 font-medium">Crash Game • 100x</p>
                                <div className="mt-2 flex items-center gap-1.5">
                                    <span className="size-2 bg-green-500 rounded-full animate-pulse"></span>
                                    <span className="text-[10px] font-bold text-green-400 uppercase tracking-wide">Live Now</span>
                                </div>
                            </div>
                            <div className="ml-auto">
                                <span className="material-symbols-outlined text-gray-500 group-hover:text-white transition-colors">chevron_right</span>
                            </div>
                        </div>
                    </div>

                    {/* Win Go Small Card (Active - Points to Color Game) */}
                    <div 
                        onClick={onPlay}
                        className="relative bg-white rounded-2xl p-4 border border-gray-100 shadow-sm cursor-pointer active:scale-95 transition-transform overflow-hidden"
                    >
                        <div className="absolute top-0 right-0 bg-green-100 text-green-700 text-[8px] font-bold px-2 py-1 rounded-bl-xl">POPULAR</div>
                        <div className="size-12 rounded-xl bg-indigo-100 text-indigo-500 flex items-center justify-center mb-3">
                            <span className="material-symbols-outlined text-2xl">palette</span>
                        </div>
                        <h3 className="font-bold text-sm text-gray-800">Win Go</h3>
                        <p className="text-[10px] text-gray-400">Guess Color</p>
                    </div>

                    {/* OTHER GAMES (LOCKED / COMING SOON) */}
                    <LockedGameCard title="Bingo" subtitle="Classic" icon="dataset" color="pink" />
                    <LockedGameCard title="Lottery" subtitle="Jackpot" icon="emoji_events" color="amber" />
                    <LockedGameCard title="Slots" subtitle="Machine" icon="casino" color="blue" />
                    <LockedGameCard title="Teen Patti" subtitle="Cards" icon="style" color="indigo" />
                    <LockedGameCard title="Roulette" subtitle="Casino" icon="donut_large" color="rose" />
                </section>
            </main>
        </div>
    );
};

// Helper for Locked Cards
const LockedGameCard = ({ title, subtitle, icon, color }: any) => (
    <div className="relative bg-white rounded-2xl p-4 border border-gray-100 shadow-sm opacity-60 grayscale-[0.5] overflow-hidden pointer-events-none select-none">
        <div className="absolute top-0 right-0 bg-gray-200 text-gray-500 text-[9px] font-bold px-2 py-1 rounded-bl-xl">
            SOON
        </div>
        <div className={`size-12 rounded-xl bg-${color}-100 text-${color}-500 flex items-center justify-center mb-3`}>
            <span className="material-symbols-outlined text-2xl">{icon}</span>
        </div>
        <h3 className="font-bold text-sm text-gray-800">{title}</h3>
        <p className="text-[10px] text-gray-400">{subtitle}</p>
    </div>
);

export default Lobby;
