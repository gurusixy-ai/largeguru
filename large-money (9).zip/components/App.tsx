
import React, { useState, useEffect } from 'react';
import Header from './Header';
import TimerSection from './TimerSection';
import BettingControls from './BettingControls';
import GameRecord from './GameRecord';
import MyBets from './MyBets';
import Auth from './Auth';
import { AdminPanel } from './AdminPanel';
import SupportChat from './SupportChat';
import Profile from './Profile';
import Deposit from './Deposit';
import Withdraw from './Withdraw';
import BankActivation from './BankActivation';
import MLMNetwork from './MLMNetwork';
import DailyDashboard from './DailyDashboard';
import TaskPage from './TaskPage';
import Lobby from './Lobby';
import AviatorGame from './AviatorGame'; // Imported Aviator

import { GameMode, GameResult, UserBet, UserProfile, Transaction, AppNotification } from '../types';

// Define View Types (Added 'aviator')
type ViewState = 'home' | 'game' | 'aviator' | 'profile' | 'deposit' | 'withdraw' | 'bank-activation' | 'chat' | 'mlm' | 'daily-dashboard' | 'tasks';

// Mobile Layout Wrapper
const MobileLayout = ({ children }: { children?: React.ReactNode }) => (
    <div className="w-full max-w-md mx-auto min-h-screen bg-[#f3f4f6] dark:bg-gray-900 shadow-2xl relative border-x border-gray-200 dark:border-gray-800">
        {children}
    </div>
);

const App: React.FC = () => {
    // --- App State ---
    const [user, setUser] = useState<UserProfile | null>(null);
    const [view, setView] = useState<ViewState>('home'); 
    const [adminView, setAdminView] = useState(true);
    
    // Notifications State
    const [notifications, setNotifications] = useState<AppNotification[]>([]);
    
    // --- Game State (Color Prediction) ---
    const [gameMode, setGameMode] = useState<GameMode>('1min');
    
    // Dynamic Durations State (Loaded from LocalStorage)
    const [durations, setDurations] = useState<{ [key in GameMode]: number }>(() => {
        const saved = localStorage.getItem('ncci_durations');
        return saved ? JSON.parse(saved) : { '1min': 60, '3min': 180, '5min': 300 };
    });

    const [timeLeft, setTimeLeft] = useState(durations['1min']);
    const [currentPeriod, setCurrentPeriod] = useState(20231024001);
    const [gameHistory, setGameHistory] = useState<GameResult[]>([]);
    const [userBets, setUserBets] = useState<UserBet[]>([]);
    const [notificationPnl, setNotificationPnl] = useState<number | null>(null);
    
    // Apply Theme (Strictly Light)
    useEffect(() => {
        const root = document.documentElement;
        root.classList.remove('dark', 'premium');
        root.classList.add('light');
    }, []);

    // Load Notifications
    useEffect(() => {
        if (user) {
            const storedNotes = JSON.parse(localStorage.getItem('ncci_notifications') || '[]');
            const myNotes = storedNotes.filter((n: AppNotification) => n.userId === user.identifier);
            setNotifications(myNotes.reverse());
        }
    }, [user?.identifier, user, view]); 

    // --- Helpers (Game Logic - Unchanged) ---
    const calculateTotalPayoutForNumber = (number: number, pendingBets: UserBet[]) => {
        let totalPayout = 0;
        const numberColors = number === 0 ? ['Red', 'Violet'] : number === 5 ? ['Green', 'Violet'] : [1,3,7,9].includes(number) ? ['Green'] : ['Red'];
        const numberSize = number >= 5 ? 'Big' : 'Small';

        pendingBets.forEach(bet => {
            let multiplier = 0;
            if (bet.selection === 'Green' && numberColors.includes('Green')) multiplier = number === 5 ? 1.5 : 2;
            else if (bet.selection === 'Red' && numberColors.includes('Red')) multiplier = number === 0 ? 1.5 : 2;
            else if (bet.selection === 'Violet' && numberColors.includes('Violet')) multiplier = 4.5;
            else if (!isNaN(Number(bet.selection)) && Number(bet.selection) === number) multiplier = 9;
            else if (bet.selection === 'Big' && numberSize === 'Big') multiplier = 2;
            else if (bet.selection === 'Small' && numberSize === 'Small') multiplier = 2;

            if (multiplier > 0) {
                totalPayout += (bet.amount * multiplier);
            }
        });
        return totalPayout;
    };

    const generateResult = (periodId: string, currentBets: UserBet[]): GameResult => {
        const forced = localStorage.getItem('ncci_force_result');
        let number: number = -1;
        if (forced) {
            number = parseInt(forced);
            localStorage.removeItem('ncci_force_result');
        } else {
            const isAutoProfit = localStorage.getItem('ncci_auto_profit') === 'true';
            const pendingBets = currentBets.filter(b => b.status === 'Pending');
            if (isAutoProfit && pendingBets.length > 0) {
                let minPayout = Infinity;
                let bestNumbers: number[] = [];
                for (let n = 0; n <= 9; n++) {
                    const payout = calculateTotalPayoutForNumber(n, pendingBets);
                    if (payout < minPayout) {
                        minPayout = payout;
                        bestNumbers = [n];
                    } else if (payout === minPayout) {
                        bestNumbers.push(n);
                    }
                }
                number = bestNumbers[Math.floor(Math.random() * bestNumbers.length)];
            } else {
                number = Math.floor(Math.random() * 10);
            }
        }
        const size = number >= 5 ? 'Big' : 'Small';
        let colors: ('Green' | 'Red' | 'Violet')[] = [];
        if (number === 0) colors = ['Red', 'Violet'];
        else if (number === 5) colors = ['Green', 'Violet'];
        else if ([1, 3, 7, 9].includes(number)) colors = ['Green'];
        else colors = ['Red'];
        return { period: periodId, number, size, colors };
    };

    const processBets = (result: GameResult) => {
        let roundPnl = 0;
        let hasProcessed = false;
        const processedBets = userBets.map(bet => {
            if (bet.status !== 'Pending') return bet;
            hasProcessed = true;
            let win = false;
            let multiplier = 0; 
            if (bet.selection === 'Green' && result.colors.includes('Green')) { win = true; multiplier = result.number === 5 ? 1.5 : 2; }
            else if (bet.selection === 'Red' && result.colors.includes('Red')) { win = true; multiplier = result.number === 0 ? 1.5 : 2; }
            else if (bet.selection === 'Violet' && result.colors.includes('Violet')) { win = true; multiplier = 4.5; }
            else if (!isNaN(Number(bet.selection)) && Number(bet.selection) === result.number) { win = true; multiplier = 9; }
            else if (bet.selection === 'Big' && result.size === 'Big') { win = true; multiplier = 2; }
            else if (bet.selection === 'Small' && result.size === 'Small') { win = true; multiplier = 2; }
            if (win) {
                const grossWin = bet.amount * multiplier;
                const fee = grossWin * 0.05; 
                const netWin = grossWin - fee;
                if (user && user.referredBy) {
                    distributeReferralCommission(user.referredBy, grossWin * 0.005);
                }
                roundPnl += (netWin - bet.amount);
                return { ...bet, status: 'Won', winLoss: netWin - bet.amount, fee } as UserBet;
            } else {
                roundPnl -= bet.amount;
                return { ...bet, status: 'Lost', winLoss: -bet.amount, fee: 0 } as UserBet;
            }
        });
        if (hasProcessed) {
            setNotificationPnl(roundPnl);
            setTimeout(() => setNotificationPnl(null), 4000);
            const allBets = JSON.parse(localStorage.getItem('ncci_all_bets') || '[]');
            const updatedGlobalBets = allBets.map((gb: UserBet) => {
                const processedMatch = processedBets.find(pb => pb.id === gb.id);
                return processedMatch || gb;
            });
            localStorage.setItem('ncci_all_bets', JSON.stringify(updatedGlobalBets));
        }
        if (user) {
            let totalWinnings = 0;
            processedBets.forEach(bet => {
                if (bet.status === 'Won' && userBets.find(b => b.id === bet.id)?.status === 'Pending') {
                    totalWinnings += (bet.amount + bet.winLoss); 
                }
            });
            if (totalWinnings > 0) {
                const updatedUser = { ...user, balance: user.balance + totalWinnings };
                updateUserProfile(updatedUser);
            }
        }
        setUserBets(processedBets);
    };

    const distributeReferralCommission = (uplineCode: string, amount: number) => {
        const storedUsers = JSON.parse(localStorage.getItem('ncci_users') || '[]');
        const uplineIndex = storedUsers.findIndex((u: UserProfile) => u.referralCode === uplineCode);
        if (uplineIndex !== -1) {
            const uplineUser = storedUsers[uplineIndex];
            uplineUser.balance += amount;
            uplineUser.referralIncome = (uplineUser.referralIncome || 0) + amount;
            const refTrans: Transaction = {
                id: Math.random().toString(36).substr(2, 9),
                userId: uplineUser.identifier,
                userName: uplineUser.name,
                type: 'Referral',
                amount: parseFloat(amount.toFixed(2)),
                status: 'Success',
                timestamp: Date.now()
            };
            const storedTrans = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
            localStorage.setItem('ncci_transactions', JSON.stringify([...storedTrans, refTrans]));
            storedUsers[uplineIndex] = uplineUser;
            localStorage.setItem('ncci_users', JSON.stringify(storedUsers));
        }
    };

    const updateUserProfile = (updatedUser: UserProfile) => {
        setUser(updatedUser);
        const storedUsers = JSON.parse(localStorage.getItem('ncci_users') || '[]');
        const updatedList = storedUsers.map((u: UserProfile) => u.identifier === updatedUser.identifier ? updatedUser : u);
        localStorage.setItem('ncci_users', JSON.stringify(updatedList));
    };

    // --- Admin Duration Handler ---
    const handleDurationUpdate = (mode: GameMode, seconds: number) => {
        const updatedDurations = { ...durations, [mode]: seconds };
        setDurations(updatedDurations);
        localStorage.setItem('ncci_durations', JSON.stringify(updatedDurations));
        
        // If current mode was updated, reset timer
        if (gameMode === mode) {
            setTimeLeft(seconds);
        }
    };

    // --- Effects ---
    useEffect(() => {
        const initialHistory: GameResult[] = [];
        let tempPeriod = currentPeriod - 1;
        for (let i = 0; i < 15; i++) {
            initialHistory.push(generateResult(String(tempPeriod), []));
            tempPeriod--;
        }
        setGameHistory(initialHistory);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (!user || (user.isAdmin && adminView)) return;
        const timer = setInterval(() => {
            setTimeLeft(prev => {
                if (prev <= 0) {
                    const endingPeriod = String(currentPeriod);
                    const result = generateResult(endingPeriod, userBets);
                    setGameHistory(prevHistory => [result, ...prevHistory]);
                    processBets(result);
                    setCurrentPeriod(p => p + 1);
                    return durations[gameMode]; // Use dynamic duration
                }
                return prev - 1;
            });
        }, 1000);
        return () => clearInterval(timer);
    }, [currentPeriod, gameMode, user, userBets, adminView, durations]); // Added durations dependency

    const placeBet = (type: 'Color' | 'Number' | 'Size', value: string, amount: number) => {
        if (!user) return;
        
        // 1. Calculate Total Available
        const totalAvailable = user.balance + user.bankMoney + user.bonusMoney;
        if (totalAvailable < amount) {
            alert("Insufficient Funds! Please Deposit.");
            return;
        }

        let remaining = amount;
        let bankDed = 0;
        let balanceDed = 0;
        let bonusDed = 0;

        // 2. Priority 1: Bank Money (Deposit Wallet) - Real Time Deposit Usage
        if (user.bankMoney > 0) {
            const deduction = Math.min(user.bankMoney, remaining);
            bankDed = deduction;
            remaining -= deduction;
        }

        // 3. Priority 2: Main Balance (Winnings Wallet)
        if (remaining > 0 && user.balance > 0) {
            const deduction = Math.min(user.balance, remaining);
            balanceDed = deduction;
            remaining -= deduction;
        }

        // 4. Priority 3: Bonus Money
        if (remaining > 0 && user.bonusMoney > 0) {
            const deduction = Math.min(user.bonusMoney, remaining);
            bonusDed = deduction;
            remaining -= deduction;
        }

        if (remaining > 0) {
             alert("Insufficient funds breakdown error.");
             return;
        }

        // 5. Update User State
        const updatedUser = { ...user };
        updatedUser.bankMoney -= bankDed;
        updatedUser.balance -= balanceDed;
        updatedUser.bonusMoney -= bonusDed;
        
        if (bonusDed > 0) updatedUser.bonusWagerProgress += bonusDed;
        
        updateUserProfile(updatedUser);

        // 6. Record Bet
        const newBet: UserBet = {
            id: Math.random().toString(36).substr(2, 9),
            period: String(currentPeriod),
            selection: value,
            amount: amount,
            quantity: 1,
            winLoss: 0,
            status: 'Pending',
            fee: 0,
            userId: user.identifier, 
            userName: user.name      
        };
        const allBets = JSON.parse(localStorage.getItem('ncci_all_bets') || '[]');
        localStorage.setItem('ncci_all_bets', JSON.stringify([newBet, ...allBets]));
        setUserBets(prev => [newBet, ...prev]);
    };
    
    // --- Render Logic Based on View State ---

    if (!user) {
        return <Auth onLogin={(u) => { setUser(u); setAdminView(true); }} />;
    }

    if (user.isAdmin && adminView) {
        return (
            <AdminPanel 
                user={user}
                onLogout={() => setUser(null)} 
                currentPeriod={String(currentPeriod)} 
                onUpdatePeriod={setCurrentPeriod}
                onResetTimer={(mode) => setTimeLeft(durations[mode])}
                onSetTime={handleDurationUpdate} // Pass dynamic handler
                onHome={() => setAdminView(false)}
            />
        );
    }

    const renderContent = () => {
        switch (view) {
            case 'home':
                return (
                    <Lobby 
                        user={user} 
                        periodId={String(currentPeriod)} 
                        timeLeft={timeLeft} 
                        onPlay={() => setView('game')} // Goes to Color Game
                        onPlayAviator={() => setView('aviator')} // Goes to Aviator
                        onProfileClick={() => setView('profile')}
                        onWalletClick={() => setView('deposit')}
                        notificationsCount={notifications.filter(n => !n.read).length}
                    />
                );
            case 'aviator':
                return <AviatorGame user={user} onBack={() => setView('home')} onUpdateUser={updateUserProfile} />;
            case 'game':
                // ... Existing Color Game UI ...
                return (
                    <>
                        <Header 
                            balance={user.balance}
                            bankBalance={user.bankMoney}
                            bonusBalance={user.bonusMoney} 
                            userName={user.name} 
                            onWalletClick={() => setView('deposit')}
                            onProfileClick={() => setView('profile')}
                            onLogout={() => setUser(null)}
                            notificationPnl={notificationPnl}
                            notifications={notifications}
                        />
                        <main className="w-full p-4 flex flex-col gap-6 relative z-10 pb-32">
                            {/* Game Header & Modes */}
                            <div className="flex flex-col gap-4 bg-white dark:bg-gray-800 p-4 rounded-3xl shadow-sm border border-white/50 relative overflow-hidden">
                                <div className="flex items-center justify-between relative z-10">
                                     <div className="flex items-center gap-3">
                                         <div className="size-10 bg-gradient-to-br from-primary to-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary/30">
                                            <span className="material-symbols-outlined text-xl">casino</span>
                                         </div>
                                         <div>
                                            <h1 className="text-lg font-black text-gray-800 dark:text-white leading-tight">Large Money</h1>
                                            <p className="text-xs text-gray-500 font-bold flex items-center gap-1">
                                                <span className="material-symbols-outlined text-[12px] text-primary">location_on</span>
                                                {user.village}
                                            </p>
                                         </div>
                                     </div>
                                </div>
                                <div className="flex bg-gray-100 dark:bg-gray-900 p-1.5 rounded-xl w-full shadow-inner">
                                    {(['1min', '3min', '5min'] as GameMode[]).map((mode) => (
                                         <button 
                                            key={mode}
                                            onClick={() => { setGameMode(mode); setTimeLeft(durations[mode]); }}
                                            className={`py-2.5 rounded-lg font-bold text-xs transition-all duration-300 flex items-center justify-center gap-1 flex-1 relative
                                                ${gameMode === mode 
                                                    ? 'bg-white dark:bg-gray-700 text-primary shadow-sm' 
                                                    : 'text-gray-500 hover:bg-white/50'
                                                }`}
                                        >
                                            <span className={`material-symbols-outlined text-[16px] ${gameMode === mode ? 'animate-pulse' : ''}`}>
                                                {mode === '1min' ? 'timer' : mode === '3min' ? 'timer_3' : 'timer_5'}
                                            </span>
                                            {mode.replace('min', ' Min')}
                                        </button>
                                    ))}
                                </div>
                            </div>
                            <div className="flex flex-col gap-6">
                                <TimerSection periodId={String(currentPeriod)} timeLeft={timeLeft} />
                                <BettingControls onBet={placeBet} disabled={timeLeft <= 5} />
                                <MyBets bets={userBets} />
                                <GameRecord history={gameHistory} />
                            </div>
                        </main>
                    </>
                );
            case 'deposit': return <Deposit user={user} onBack={() => setView('home')} />;
            case 'withdraw': return <Withdraw user={user} onUpdateUser={updateUserProfile} onBack={() => setView('home')} onGoToActivation={() => setView('bank-activation')} />;
            case 'bank-activation': return <BankActivation user={user} onUpdateUser={updateUserProfile} onBack={() => setView('withdraw')} />;
            case 'chat': return <SupportChat user={user} onBack={() => setView('home')} />;
            case 'mlm': return <MLMNetwork user={user} onBack={() => setView('home')} onUpdateUser={updateUserProfile} />;
            case 'tasks': return <TaskPage user={user} onBack={() => setView('home')} onUpdateUser={updateUserProfile} />;
            case 'daily-dashboard': return <DailyDashboard user={user} bets={userBets} onBack={() => setView('home')} onUpdateUser={updateUserProfile} />;
            case 'profile': return <Profile user={user} bets={userBets} onBack={() => setView('home')} onLogout={() => setUser(null)} onDeposit={() => setView('deposit')} onWithdraw={() => setView('withdraw')} onUpdateProfile={updateUserProfile} onOpenChat={() => setView('chat')} onOpenMLM={() => setView('mlm')} onOpenDailyDashboard={() => setView('daily-dashboard')} />;
            default: return null;
        }
    };

    return (
        <MobileLayout>
            {renderContent()}
            
            {/* Admin Back Button Overlay */}
            {user.isAdmin && (
                <div className="fixed bottom-24 left-6 z-50">
                    <button onClick={() => setAdminView(true)} className="bg-gray-900 text-white px-4 py-2 rounded-full font-bold shadow-2xl flex items-center gap-2 text-xs">
                        <span className="material-symbols-outlined text-sm">admin_panel_settings</span>
                        Panel
                    </button>
                </div>
            )}

            {/* RESTORED STANDARD BOTTOM NAVIGATION (Hidden in Aviator View) */}
            {view !== 'aviator' && (
                <div className="fixed bottom-0 w-full z-50 max-w-md">
                    <div className="absolute inset-0 bg-white/90 backdrop-blur-xl border-t border-slate-200 shadow-[0_-5px_20px_rgba(0,0,0,0.05)]"></div>
                    <div className="relative flex justify-around items-center pb-4 pt-3 px-2">
                        <button 
                            onClick={() => setView('home')}
                            className={`flex flex-col items-center gap-1 group w-16 transition-all ${view === 'home' ? 'text-primary' : 'text-slate-400 hover:text-slate-600'}`}
                        >
                            <span className="material-symbols-outlined text-2xl">home</span>
                            <span className="text-[10px] font-bold">Home</span>
                        </button>
                        
                        <button 
                            onClick={() => setView('tasks')} 
                            className={`flex flex-col items-center gap-1 group w-16 transition-all ${view === 'tasks' || view === 'daily-dashboard' ? 'text-primary' : 'text-slate-400 hover:text-slate-600'}`}
                        >
                            <span className="material-symbols-outlined text-2xl">task_alt</span>
                            <span className="text-[10px] font-bold">Activity</span>
                        </button>
                        
                        <button 
                            onClick={() => setView('mlm')} 
                            className={`flex flex-col items-center gap-1 group w-16 transition-all ${view === 'mlm' ? 'text-primary' : 'text-slate-400 hover:text-slate-600'}`}
                        >
                            <span className="material-symbols-outlined text-2xl">diamond</span>
                            <span className="text-[10px] font-bold">Promotion</span>
                        </button>
                        
                        <button 
                            onClick={() => setView('deposit')} 
                            className={`flex flex-col items-center gap-1 group w-16 transition-all ${view === 'deposit' || view === 'withdraw' ? 'text-primary' : 'text-slate-400 hover:text-slate-600'}`}
                        >
                            <span className="material-symbols-outlined text-2xl">account_balance_wallet</span>
                            <span className="text-[10px] font-bold">Wallet</span>
                        </button>
                        
                        <button 
                            onClick={() => setView('profile')}
                            className={`flex flex-col items-center gap-1 group w-16 transition-all ${view === 'profile' ? 'text-primary' : 'text-slate-400 hover:text-slate-600'}`}
                        >
                            <span className="material-symbols-outlined text-2xl">person</span>
                            <span className="text-[10px] font-bold">Account</span>
                        </button>
                    </div>
                </div>
            )}
        </MobileLayout>
    );
};

export default App;
