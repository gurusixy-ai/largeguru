
import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, Transaction, UserBet, AppNotification, TaskConfig, PromotionalTask } from '../types';

interface ProfileProps {
    user: UserProfile;
    bets: UserBet[]; 
    onBack: () => void;
    onLogout: () => void;
    onDeposit: () => void;
    onWithdraw: () => void;
    onUpdateProfile: (updatedUser: UserProfile) => void;
    onOpenChat: () => void;
    onOpenMLM?: () => void;
    onOpenDailyDashboard?: () => void;
}

const Profile: React.FC<ProfileProps> = ({ user, bets: propBets, onBack, onLogout, onDeposit, onWithdraw, onUpdateProfile, onOpenChat, onOpenMLM, onOpenDailyDashboard }) => {
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [notifications, setNotifications] = useState<AppNotification[]>([]);
    const [allHistoryBets, setAllHistoryBets] = useState<UserBet[]>([]); // State for combined history
    const [activeTab, setActiveTab] = useState<'details' | 'wallet' | 'bets' | 'notifications'>('details');
    const fileInputRef = useRef<HTMLInputElement>(null);

    // ... (rest of the state variables remain same) ...
    const [previewImage, setPreviewImage] = useState<string | null>(null);
    const [isImageLoading, setIsImageLoading] = useState(false);
    const [showVerifyModal, setShowVerifyModal] = useState(false);
    const [recoveryEmail, setRecoveryEmail] = useState('');
    const [teamSize, setTeamSize] = useState(0);
    const [directsCount, setDirectsCount] = useState(0);
    const [showTaskModal, setShowTaskModal] = useState(false);
    const [promoTasks, setPromoTasks] = useState<PromotionalTask[]>([]);
    const [tasksStarted, setTasksStarted] = useState<string[]>([]);

    // Level Data Configuration (UNCHANGED)
    const LEVELS = [
        { name: "Star", team: 2, total: 2, income: "₹80 - ₹200", icon: "star", gradient: "bg-gradient-to-br from-red-500 via-red-600 to-rose-800", shadow: "shadow-red-500/40", textColor: "text-red-600", accent: "bg-red-500", darkText: "text-red-100" },
        { name: "Bronze", team: 4, total: 6, income: "₹300 - ₹500", icon: "workspace_premium", gradient: "bg-gradient-to-br from-orange-600 via-orange-700 to-amber-900", shadow: "shadow-orange-600/40", textColor: "text-orange-700", accent: "bg-orange-600", darkText: "text-orange-100" },
        { name: "Silver", team: 8, total: 14, income: "₹800 - ₹1,000", icon: "military_tech", gradient: "bg-gradient-to-br from-slate-500 via-slate-600 to-gray-800", shadow: "shadow-slate-500/40", textColor: "text-slate-600", accent: "bg-slate-500", darkText: "text-slate-200" },
        { name: "Gold", team: 16, total: 30, income: "₹2,000 - ₹3,500", icon: "monetization_on", gradient: "bg-gradient-to-br from-amber-400 via-yellow-500 to-orange-600", shadow: "shadow-amber-500/40", textColor: "text-amber-600", accent: "bg-amber-500", darkText: "text-amber-100" },
        { name: "Platinum", team: 32, total: 62, income: "₹5,00,000+", icon: "diamond", gradient: "bg-gradient-to-br from-cyan-400 via-cyan-500 to-blue-600", shadow: "shadow-cyan-400/40", textColor: "text-cyan-600", accent: "bg-cyan-500", darkText: "text-cyan-100" },
        { name: "Ruby", team: 64, total: 126, income: "₹12,000 - ₹15,000", icon: "local_fire_department", gradient: "bg-gradient-to-br from-pink-500 via-pink-600 to-rose-700", shadow: "shadow-pink-500/40", textColor: "text-pink-600", accent: "bg-pink-500", darkText: "text-pink-100" },
        { name: "Emerald", team: 128, total: 254, income: "₹25,000 - ₹35,000", icon: "emergency", gradient: "bg-gradient-to-br from-emerald-500 via-green-600 to-teal-700", shadow: "shadow-emerald-500/40", textColor: "text-emerald-600", accent: "bg-emerald-500", darkText: "text-emerald-100" },
        { name: "Sapphire", team: 256, total: 510, income: "₹50,000 - ₹70,000", icon: "water_drop", gradient: "bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800", shadow: "shadow-blue-600/40", textColor: "text-blue-700", accent: "bg-blue-600", darkText: "text-blue-200" },
        { name: "Diamond", team: 512, total: 1022, income: "₹1,00,000+", icon: "auto_awesome", gradient: "bg-gradient-to-br from-violet-600 via-purple-600 to-fuchsia-800", shadow: "shadow-violet-600/40", textColor: "text-violet-700", accent: "bg-violet-600", darkText: "text-violet-100" },
        { name: "Double Diamond", team: 1024, total: 2046, income: "₹2,50,000+", icon: "diamond", gradient: "bg-gradient-to-br from-teal-500 via-teal-600 to-emerald-800", shadow: "shadow-teal-500/40", textColor: "text-teal-700", accent: "bg-teal-500", darkText: "text-teal-100" },
        { name: "Crown", team: 2048, total: 4094, income: "₹5,00,000+", icon: "crown", gradient: "bg-gradient-to-br from-indigo-600 via-indigo-700 to-violet-900", shadow: "shadow-indigo-600/40", textColor: "text-indigo-700", accent: "bg-indigo-600", darkText: "text-indigo-200" },
        { name: "Ambassador", team: 4096, total: 8190, income: "₹10,00,000+", icon: "social_leaderboard", gradient: "bg-gradient-to-br from-gray-900 via-black to-gray-800", shadow: "shadow-gray-900/50", textColor: "text-black", accent: "bg-yellow-500", darkText: "text-gray-300" },
    ];

    useEffect(() => {
        const allTrans = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
        const userTrans = allTrans.filter((t: Transaction) => t.userId === user.identifier);
        setTransactions(userTrans.reverse());

        // Load Notifications
        const allNotes = JSON.parse(localStorage.getItem('ncci_notifications') || '[]');
        const userNotes = allNotes.filter((n: AppNotification) => n.userId === user.identifier);
        setNotifications(userNotes.reverse());
        
        // Load Promotional Tasks
        const storedPromoTasks = JSON.parse(localStorage.getItem('ncci_promo_tasks') || '[]');
        setPromoTasks(storedPromoTasks);
        
        // Load ALL BETS from LocalStorage (Includes Aviator + Color)
        const storedBets = JSON.parse(localStorage.getItem('ncci_all_bets') || '[]');
        const myBets = storedBets.filter((b: UserBet) => b.userId === user.identifier);
        // Sort by timestamp if available, else by ID (assuming recent is first)
        setAllHistoryBets(myBets);

        // Calculate Team Size
        const allUsers = JSON.parse(localStorage.getItem('ncci_users') || '[]');
        const directs = allUsers.filter((u: any) => u.referredBy === user.referralCode);
        setDirectsCount(directs.length);

        const getDownlineCount = (refCode: string) => {
            let count = 0;
            const directs = allUsers.filter((u: any) => u.referredBy === refCode);
            count += directs.length;
            directs.forEach((d: any) => {
                count += getDownlineCount(d.referralCode);
            });
            return count;
        };
        setTeamSize(getDownlineCount(user.referralCode));

    }, [user.identifier, user.lastCheckIn, user.referralCode, propBets]); // Add propBets to dep to refresh if App updates it

    // ... (keep all helper functions: handleDailyClick, handleStartPromoTask, handleClaimPromoTask, handleImageUpload, etc. exactly as they were) ...
    const handleDailyClick = () => { if (onOpenDailyDashboard) onOpenDailyDashboard(); };
    const handleStartPromoTask = (taskId: string, link: string) => { window.open(link, '_blank'); setTasksStarted(prev => [...prev, taskId]); };
    const handleClaimPromoTask = (task: PromotionalTask) => {
        const updatedUser = { ...user, bankMoney: (user.bankMoney || 0) + task.reward, completedTasks: [...(user.completedTasks || []), task.id] };
        const trans: Transaction = { id: Math.random().toString(36).substr(2, 9), userId: user.identifier, userName: user.name, type: 'Bonus', amount: task.reward, status: 'Success', timestamp: Date.now() };
        const existingTrans = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
        localStorage.setItem('ncci_transactions', JSON.stringify([...existingTrans, trans]));
        onUpdateProfile(updatedUser);
        alert(`Task Completed! ₹${task.reward} added to your Bank Wallet.`);
    };
    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => { const file = e.target.files?.[0]; if (file) { setIsImageLoading(true); const reader = new FileReader(); reader.onloadend = () => { const base64 = reader.result as string; setPreviewImage(base64); setIsImageLoading(false); }; reader.readAsDataURL(file); } };
    const confirmImageUpload = () => { if (previewImage) { const updatedUser = { ...user, profileImage: previewImage }; onUpdateProfile(updatedUser); setPreviewImage(null); } };
    const cancelImageUpload = () => { setPreviewImage(null); if (fileInputRef.current) { fileInputRef.current.value = ''; } };
    const copyReferralCode = () => { navigator.clipboard.writeText(user.referralCode); alert("Referral Code Copied!"); };
    const shareReferralLink = async () => { const link = `https://ncci.gov.in/register?ref=${user.referralCode}`; const msg = `Join NCCI Game & Earn! Use my code: ${user.referralCode}\n${link}`; if (navigator.share) { try { await navigator.share({ title: 'Join NCCI', text: msg, url: link, }); } catch (err) { console.log('Error sharing', err); } } else { navigator.clipboard.writeText(msg); alert("Referral Link & Message Copied!"); } };
    const handleVerificationSubmit = () => { if (!recoveryEmail || !recoveryEmail.includes('@')) { alert("Please enter a valid Gmail address."); return; } const updatedUser = { ...user, recoveryEmail: recoveryEmail, isCardVerified: true }; onUpdateProfile(updatedUser); setShowVerifyModal(false); alert("Account Verified Successfully! Recovery Email Linked."); };
    const handleDownloadCard = () => { alert("Downloading Digital Identity Card...\n(Saved to Gallery)"); };
    const availablePromoTasks = promoTasks.filter(t => t.active && !user.completedTasks?.includes(t.id));

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20 w-full font-display">
            {/* Header / Nav */}
            <header className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-b border-gray-100 dark:border-gray-700 p-4 sticky top-0 z-50 shadow-sm">
                <div className="w-full flex items-center justify-between">
                    <button onClick={onBack} className="flex items-center text-gray-500 hover:text-primary transition-colors gap-2">
                        <div className="size-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                            <span className="material-symbols-outlined text-sm">arrow_back</span>
                        </div>
                        <span className="font-bold text-sm">Back to Game</span>
                    </button>
                    <button onClick={onLogout} className="text-red-500 bg-red-50 hover:bg-red-100 p-2 rounded-xl transition-colors">
                        <span className="material-symbols-outlined text-xl">logout</span>
                    </button>
                </div>
            </header>

            <main className="w-full p-4 space-y-8 max-w-lg mx-auto">
                
                {/* --- DIGITAL IDENTITY CARD (SAME AS BEFORE) --- */}
                <div className="relative w-full rounded-[2rem] p-6 text-white shadow-2xl overflow-hidden bg-black group transition-all">
                    <div className="absolute inset-0 bg-[conic-gradient(at_top_right,_var(--tw-gradient-stops))] from-indigo-900 via-slate-900 to-black opacity-95"></div>
                    <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-30 mix-blend-overlay"></div>
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl"></div>
                    
                    <div className="relative z-10">
                        {/* Content same as original ... */}
                        <div className="flex justify-between items-start mb-6 border-b border-white/10 pb-4">
                            <div className="flex items-center gap-3">
                                <div className="size-10 bg-white/10 rounded-lg flex items-center justify-center border border-white/20"><span className="material-symbols-outlined text-2xl text-yellow-400">verified_user</span></div>
                                <div><h3 className="font-bold text-lg leading-none tracking-wide">DIGITAL ID</h3><p className="text-[10px] text-white/50 uppercase tracking-widest mt-1">Official Member Card</p></div>
                            </div>
                            <div className="text-right"><span className={`text-[10px] font-bold px-2 py-1 rounded border ${user.isCardVerified ? 'bg-green-500/20 border-green-500 text-green-400' : 'bg-red-500/20 border-red-500 text-red-400'}`}>{user.isCardVerified ? 'VERIFIED' : 'UNVERIFIED'}</span></div>
                        </div>
                        <div className="flex items-center gap-5 mb-6">
                            <div className="relative group/edit">
                                <div className="size-20 rounded-2xl border-2 border-white/30 bg-white/10 overflow-hidden shadow-lg">
                                    {previewImage ? (<img src={previewImage} alt="Profile" className="size-full object-cover" />) : user.profileImage ? (<img src={user.profileImage} alt="Profile" className="size-full object-cover" />) : (<div className="size-full flex items-center justify-center bg-gradient-to-br from-blue-600 to-purple-600 text-3xl font-bold">{user.name.charAt(0).toUpperCase()}</div>)}
                                </div>
                                <div onClick={() => fileInputRef.current?.click()} className="absolute -bottom-2 -right-2 bg-blue-600 p-1.5 rounded-lg shadow-md cursor-pointer border border-white/20 hover:scale-110 transition-transform"><span className="material-symbols-outlined text-xs">edit</span></div>
                                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
                            </div>
                            <div><h2 className="text-2xl font-black tracking-wide text-white drop-shadow-md">{user.name}</h2><p className="text-xs text-blue-200 font-mono mt-1 flex items-center gap-1">ID: {user.identifier}</p>{user.recoveryEmail && (<p className="text-[10px] text-white/60 mt-1 flex items-center gap-1"><span className="material-symbols-outlined text-[10px]">mark_email_read</span> {user.recoveryEmail}</p>)}</div>
                        </div>
                        <div className="grid grid-cols-2 gap-3 bg-white/5 rounded-xl p-3 border border-white/5 mb-4">
                            <div className="p-2 border-r border-white/10"><p className="text-[9px] text-white/40 uppercase font-bold tracking-wider">Village</p><p className="text-sm font-bold text-white truncate">{user.village}</p></div>
                            <div className="p-2"><p className="text-[9px] text-white/40 uppercase font-bold tracking-wider">Block</p><p className="text-sm font-bold text-white truncate">{user.block}</p></div>
                            <div className="p-2 border-r border-white/10 border-t"><p className="text-[9px] text-white/40 uppercase font-bold tracking-wider">District</p><p className="text-sm font-bold text-white truncate">{user.district}</p></div>
                            <div className="p-2 border-t border-white/10"><p className="text-[9px] text-white/40 uppercase font-bold tracking-wider">Join Date</p><p className="text-sm font-bold text-white truncate">{new Date(user.joinedAt).toLocaleDateString()}</p></div>
                        </div>
                        <div className="flex gap-3">
                            {!user.isCardVerified ? (<button onClick={() => setShowVerifyModal(true)} className="flex-1 bg-yellow-500 hover:bg-yellow-400 text-black font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-yellow-500/20"><span className="material-symbols-outlined text-lg">gpp_maybe</span> Verify Card</button>) : (<button onClick={handleDownloadCard} className="flex-1 bg-white hover:bg-gray-100 text-black font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-lg"><span className="material-symbols-outlined text-lg">download</span> Download Card</button>)}
                            {previewImage && (<div className="flex gap-2"><button onClick={confirmImageUpload} className="bg-green-600 text-white p-2.5 rounded-xl"><span className="material-symbols-outlined text-lg">check</span></button><button onClick={cancelImageUpload} className="bg-red-600 text-white p-2.5 rounded-xl"><span className="material-symbols-outlined text-lg">close</span></button></div>)}
                        </div>
                    </div>
                </div>

                {/* --- DIGITAL WALLET SECTION --- */}
                <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gradient-to-br from-green-500 to-emerald-700 rounded-3xl p-5 text-white shadow-lg relative overflow-hidden group">
                        <div className="absolute -right-6 -top-6 size-24 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700"></div>
                        <div className="relative z-10"><span className="text-[10px] font-bold uppercase tracking-widest opacity-80 flex items-center gap-1 mb-1"><span className="material-symbols-outlined text-xs">account_balance_wallet</span> Winnable</span><div className="text-2xl font-black tracking-tight">₹{user.balance.toFixed(0)}</div><button onClick={onWithdraw} className="mt-4 w-full bg-white/20 hover:bg-white/30 backdrop-blur-md py-2 rounded-xl text-xs font-bold transition-all border border-white/10 flex items-center justify-center gap-1 shadow-sm"><span className="material-symbols-outlined text-sm">arrow_upward</span> Withdraw</button></div>
                    </div>
                    <div className="bg-gradient-to-br from-blue-600 to-indigo-800 rounded-3xl p-5 text-white shadow-lg relative overflow-hidden group">
                        <div className="absolute -left-6 -bottom-6 size-24 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700"></div>
                        <div className="relative z-10"><span className="text-[10px] font-bold uppercase tracking-widest opacity-80 flex items-center gap-1 mb-1"><span className="material-symbols-outlined text-xs">lock</span> Bank Money</span><div className="text-2xl font-black tracking-tight">₹{user.bankMoney?.toFixed(0) || 0}</div><button onClick={onDeposit} className="mt-4 w-full bg-white/20 hover:bg-white/30 backdrop-blur-md py-2 rounded-xl text-xs font-bold transition-all border border-white/10 flex items-center justify-center gap-1 shadow-sm"><span className="material-symbols-outlined text-sm">add</span> Deposit</button></div>
                    </div>
                </div>

                {/* --- MENU TABS --- */}
                <div className="bg-white dark:bg-gray-800 rounded-full p-1.5 shadow-lg border border-gray-100 dark:border-gray-700 flex justify-between relative overflow-hidden">
                    {['details', 'wallet', 'bets', 'notifications'].map((tab) => (
                        <button key={tab} onClick={() => setActiveTab(tab as any)} className={`flex-1 py-3 rounded-full text-xs font-bold transition-all relative z-10 flex items-center justify-center gap-1 ${activeTab === tab ? 'text-white shadow-md' : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-700'}`}>
                            {activeTab === tab && (<div className="absolute inset-0 bg-primary rounded-full -z-10 animate-fade-in"></div>)}<span className="capitalize">{tab}</span>
                        </button>
                    ))}
                </div>

                {/* --- CONTENT AREA --- */}
                <div className="space-y-6">
                    {activeTab === 'details' && (
                        <div className="animate-slide-up space-y-4">
                            {/* ... (Previous Details Content - Careers, MLM, etc. - Kept same) ... */}
                            <button onClick={() => {if (onOpenMLM) onOpenMLM();}} className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 p-5 rounded-3xl shadow-lg shadow-emerald-500/20 flex items-center justify-between text-white relative overflow-hidden group hover:scale-[1.02] transition-all">
                                <div className="flex items-center gap-4 relative z-10"><div className="size-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center shadow-inner"><span className="material-symbols-outlined text-2xl">account_tree</span></div><div className="text-left"><h3 className="font-bold text-lg leading-none">Games Working Income</h3><p className="text-[10px] uppercase font-bold tracking-wider opacity-80 mt-1">MLM Knowledge & Dashboard</p></div></div><span className="material-symbols-outlined text-6xl opacity-20 -rotate-12 absolute -right-2 -bottom-2">group_add</span>
                            </button>
                            <div className="bg-gradient-to-r from-violet-600 to-indigo-700 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
                                <div className="absolute top-0 right-0 p-4 opacity-10"><span className="material-symbols-outlined text-9xl">share</span></div>
                                <div className="relative z-10">
                                    <div className="flex justify-between items-start mb-6"><div><h3 className="text-xl font-black mb-1">Refer & Earn</h3><p className="text-xs text-indigo-200 font-medium">Build your team, increase your income.</p></div><div className="bg-white/20 backdrop-blur-md p-2 rounded-xl" onClick={shareReferralLink}><span className="material-symbols-outlined text-2xl">qr_code_2</span></div></div>
                                    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 flex items-center justify-between mb-6"><div><p className="text-[10px] text-indigo-200 uppercase font-bold tracking-wider mb-1">Your Referral Code</p><p className="text-2xl font-mono font-black tracking-widest">{user.referralCode}</p></div><button onClick={copyReferralCode} className="bg-white text-indigo-600 p-2 rounded-lg hover:bg-indigo-50 transition-colors shadow-lg active:scale-95"><span className="material-symbols-outlined">content_copy</span></button></div>
                                    <div className="grid grid-cols-2 gap-4"><div className="bg-black/20 rounded-xl p-3 border border-white/5"><p className="text-[10px] text-indigo-200 uppercase font-bold flex items-center gap-1"><span className="material-symbols-outlined text-xs">groups</span> Total Team</p><p className="text-xl font-black mt-1">{teamSize}</p></div><div className="bg-black/20 rounded-xl p-3 border border-white/5"><p className="text-[10px] text-indigo-200 uppercase font-bold flex items-center gap-1"><span className="material-symbols-outlined text-xs">person_add</span> Direct Members</p><p className="text-xl font-black mt-1">{directsCount}</p></div></div>
                                    <button onClick={shareReferralLink} className="w-full mt-4 bg-white/20 hover:bg-white/30 backdrop-blur-md py-3 rounded-xl font-bold text-sm transition-colors border border-white/10 flex items-center justify-center gap-2"><span className="material-symbols-outlined text-lg">share</span> Invite Friends</button>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <button onClick={handleDailyClick} className="bg-gradient-to-br from-amber-300 to-yellow-500 rounded-3xl p-4 shadow-lg relative overflow-hidden text-left group transition-transform active:scale-95"><div className="relative z-10"><div className="size-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center mb-3 shadow-inner"><span className="material-symbols-outlined text-white text-xl">crown</span></div><h3 className="font-black text-white text-sm leading-tight">Daily<br/>Dashboard</h3><p className="text-[10px] text-white/80 font-bold uppercase mt-1">VIP Income & Rebate</p></div><span className="material-symbols-outlined absolute -bottom-4 -right-4 text-7xl text-white opacity-20 rotate-12 group-hover:rotate-45 transition-transform">monitoring</span></button>
                                <button onClick={onOpenChat} className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-3xl p-4 shadow-sm relative overflow-hidden text-left group transition-transform active:scale-95 hover:shadow-md"><div className="relative z-10"><div className="size-10 bg-blue-50 dark:bg-blue-900/30 rounded-full flex items-center justify-center mb-3 text-blue-600"><span className="material-symbols-outlined text-xl">headset_mic</span></div><h3 className="font-black text-gray-800 dark:text-white text-sm leading-tight">Live<br/>Support</h3><p className="text-[10px] text-gray-400 font-bold uppercase mt-1">24/7 Help</p></div></button>
                            </div>
                            {(user.bonusMoney > 0 || user.bonusWagerTarget > 0) && (<div className="bg-gray-900 rounded-3xl p-5 text-white shadow-lg relative overflow-hidden border border-gray-800"><div className="flex justify-between items-center mb-3 relative z-10"><div className="flex items-center gap-2 font-bold text-yellow-400 text-sm uppercase tracking-wider"><span className="material-symbols-outlined text-lg">star</span>Bonus Balance</div><div className="text-xl font-black">₹{user.bonusMoney}</div></div><div className="relative z-10"><div className="flex justify-between text-[10px] font-bold uppercase mb-1.5 text-gray-400"><span>Wager Required (10x)</span><span>{user.bonusWagerProgress}/{user.bonusWagerTarget}</span></div><div className="w-full bg-gray-700 rounded-full h-2 overflow-hidden shadow-inner"><div className="bg-gradient-to-r from-yellow-400 to-orange-500 h-full rounded-full transition-all duration-1000 shadow-[0_0_10px_#fbbf24]" style={{ width: `${Math.min(100, (user.bonusWagerProgress / user.bonusWagerTarget) * 100)}%` }}></div></div></div></div>)}
                            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-800">
                                <div className="flex items-center justify-between mb-6"><button onClick={() => {if (onOpenMLM) onOpenMLM();}} className="text-left group"><h3 className="font-black text-2xl text-gray-800 dark:text-white flex items-center gap-2 group-hover:text-primary transition-colors"><span className="material-symbols-outlined text-3xl text-primary">trending_up</span> Career Ladder <span className="material-symbols-outlined text-gray-300 group-hover:text-primary text-xl">open_in_new</span></h3><p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Unlock 12 Ranks & Multiply Income</p></button></div>
                                <div className="relative w-full overflow-hidden rounded-[3rem] bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-800 shadow-inner p-8"><div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.05] pointer-events-none"></div><div className="flex gap-8 overflow-x-auto pb-10 pt-4 px-2 -mx-4 no-scrollbar snap-x snap-mandatory perspective-1000">{LEVELS.map((level, index) => { const isUnlocked = teamSize >= level.total; const isNext = !isUnlocked && (index === 0 || teamSize >= LEVELS[index - 1].total); const progress = isNext ? Math.min(100, (teamSize / level.total) * 100) : isUnlocked ? 100 : 0; return (<div key={index} onClick={() => {if (onOpenMLM) onOpenMLM();}} className={`relative flex-shrink-0 w-[300px] h-[450px] rounded-[2.5rem] p-0 snap-center transition-all duration-500 transform hover:scale-[1.02] flex flex-col justify-between overflow-hidden shadow-2xl ${level.gradient} ${level.shadow} border border-white/10 group cursor-pointer`}><div className="absolute inset-0 pointer-events-none"><div className="absolute -top-20 -right-20 w-64 h-64 bg-white/20 rounded-full blur-3xl mix-blend-overlay"></div><div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-black/40 to-transparent"></div></div><div className={`relative z-10 p-7 h-full flex flex-col justify-between`}><div className="flex justify-between items-start"><div className={`size-16 rounded-2xl flex items-center justify-center font-black text-3xl shadow-[0_10px_20px_-5px_rgba(0,0,0,0.3)] bg-white border-4 border-white/20 backdrop-blur-sm relative overflow-hidden group-hover:rotate-6 duration-500`}><span className={level.textColor}>{index + 1}</span><div className={`absolute inset-0 opacity-10 ${level.accent}`}></div></div>{isUnlocked ? (<div className="size-10 bg-white/20 backdrop-blur-md border border-white/40 rounded-full flex items-center justify-center shadow-lg"><span className="material-symbols-outlined text-xl text-white">verified</span></div>) : (<div className="size-10 bg-black/40 backdrop-blur-md border border-white/10 rounded-full flex items-center justify-center shadow-lg"><span className="material-symbols-outlined text-xl text-white/80">lock</span></div>)}</div><div className="text-center mt-6 relative"><div className={`inline-flex p-5 rounded-full bg-white/10 border border-white/20 backdrop-blur-sm mb-5 shadow-lg relative z-10`}><span className={`material-symbols-outlined text-5xl drop-shadow-md text-white`}>{level.icon}</span></div><h3 className={`text-3xl font-black uppercase tracking-tight leading-none drop-shadow-md relative z-10 text-white`}>{level.name}</h3><div className={`mt-4 inline-block px-4 py-2 rounded-xl relative z-10 backdrop-blur-md shadow-lg border border-white/10 bg-black/20`}><p className={`text-[10px] font-bold uppercase tracking-[0.2em] mb-0.5 text-white/70`}>Monthly Income</p><p className={`text-xl font-black drop-shadow-sm text-white`}>{level.income}</p></div></div><div className={`mt-auto rounded-[20px] p-5 border relative overflow-hidden bg-black/20 border-white/20 backdrop-blur-lg`}><div className="flex justify-between items-end mb-3 relative z-10"><div><div className={`text-[9px] uppercase font-bold mb-0.5 text-white/70`}>Total Team</div><div className={`text-2xl font-black text-white`}>{level.total}</div></div><div className="text-right"><div className={`text-[9px] uppercase font-bold mb-0.5 text-white/70`}>Directs</div><div className={`text-2xl font-black text-white`}>{level.team}+</div></div></div><div className={`w-full h-4 rounded-full overflow-hidden p-[2px] bg-black/30`}><div className={`h-full rounded-full transition-all duration-1000 relative overflow-hidden ${progress === 100 ? 'bg-gradient-to-r from-white/80 to-white shadow-[0_0_15px_white]' : 'bg-white/40'}`} style={{ width: `${progress}%` }}></div></div></div></div></div>); })}</div></div></div>
                        </div>
                    )}

                    {activeTab === 'wallet' && (
                        <div className="bg-white dark:bg-surface-dark rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden divide-y divide-gray-100 dark:divide-gray-800 animate-slide-up">
                            {transactions.length === 0 ? (<div className="p-12 text-center text-gray-400">No transactions found</div>) : transactions.map(t => (
                                <div key={t.id} className="p-5 flex justify-between items-center hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                                    <div className="flex items-center gap-4"><div className={`size-12 rounded-2xl flex items-center justify-center shadow-sm ${t.type === 'Deposit' ? 'bg-green-50 text-green-600' : t.type === 'Referral' ? 'bg-purple-50 text-purple-600' : t.type === 'Bonus' || t.type === 'MLM_Claim' ? 'bg-yellow-50 text-yellow-600' : 'bg-red-50 text-red-600'}`}><span className="material-symbols-outlined text-2xl">{t.type === 'Deposit' ? 'add' : t.type === 'Referral' ? 'diversity_3' : t.type === 'Bonus' || t.type === 'MLM_Claim' ? 'star' : 'arrow_upward'}</span></div><div><div className="font-bold text-sm dark:text-white uppercase tracking-wide">{t.type}</div><div className="text-xs text-gray-400 mt-0.5">{new Date(t.timestamp).toLocaleDateString()}</div></div></div>
                                    <div className="text-right"><div className={`font-black text-lg ${t.type === 'Withdrawal' ? 'text-red-600' : 'text-green-600'}`}>{t.type === 'Withdrawal' ? '-' : '+'} ₹{t.amount}</div><div className={`text-[10px] font-bold uppercase tracking-wider ${t.status === 'Approved' || t.status === 'Success' ? 'text-green-500' : t.status === 'Rejected' ? 'text-red-500' : 'text-yellow-500'}`}>{t.status}</div></div>
                                </div>
                            ))}
                        </div>
                    )}
                    
                    {activeTab === 'bets' && (
                         <div className="bg-white dark:bg-surface-dark rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden animate-slide-up">
                            {allHistoryBets.length === 0 ? (<div className="p-16 text-center text-gray-400 flex flex-col items-center"><span className="material-symbols-outlined text-5xl mb-3 opacity-30">history</span><span>No betting history</span></div>) : (
                                 <div className="divide-y divide-gray-100 dark:divide-gray-800">
                                    {allHistoryBets.map(bet => (
                                        <div key={bet.id} className="p-5 flex justify-between items-center hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                                            <div>
                                                <div className="text-[10px] text-gray-400 font-bold uppercase mb-1 tracking-wider">
                                                    {bet.period.length > 8 ? 'Aviator' : `Period ${bet.period}`}
                                                </div>
                                                <div className="font-bold flex items-center gap-2">
                                                    <span className={`px-3 py-1 rounded-lg text-xs text-white font-bold shadow-sm ${
                                                        bet.selection.includes('Aviator') ? (bet.selection.includes('Cashout') ? 'bg-green-500' : 'bg-red-500') :
                                                        bet.selection === 'Green' ? 'bg-green-600' : bet.selection === 'Red' ? 'bg-red-600' : bet.selection === 'Violet' ? 'bg-purple-600' : !isNaN(Number(bet.selection)) ? 'bg-blue-600' : 'bg-orange-600'
                                                    }`}>
                                                        {bet.selection}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <div className={`font-black text-lg ${bet.status === 'Won' ? 'text-green-600' : bet.status === 'Lost' ? 'text-red-500' : 'text-yellow-600'}`}>
                                                    {bet.status === 'Won' ? `+₹${bet.winLoss}` : bet.status === 'Lost' ? `-₹${Math.abs(bet.winLoss)}` : 'Running'}
                                                </div>
                                                <div className="text-xs text-gray-400 font-bold">Bet: ₹{bet.amount}</div>
                                            </div>
                                        </div>
                                    ))}
                                 </div>
                            )}
                         </div>
                    )}

                    {activeTab === 'notifications' && (
                        <div className="bg-white dark:bg-surface-dark rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden divide-y divide-gray-100 dark:divide-gray-800 animate-slide-up">
                            {notifications.length === 0 ? (<div className="p-16 text-center text-gray-400 flex flex-col items-center"><span className="material-symbols-outlined text-5xl mb-3 opacity-30">notifications_off</span><span>No notifications</span></div>) : (notifications.map(n => (
                                <div key={n.id} className="p-5 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors relative">
                                    {!n.read && <div className="absolute top-5 right-5 size-2 rounded-full bg-red-500"></div>}
                                    <div className="flex justify-between items-start mb-2"><div className="font-bold text-gray-800 dark:text-gray-200">{n.title}</div><div className="text-[10px] text-gray-400 font-medium">{new Date(n.timestamp).toLocaleString()}</div></div>
                                    <div className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed bg-gray-50 dark:bg-gray-800 p-3 rounded-xl border border-gray-100 dark:border-gray-700">{n.message}</div>
                                    {n.image && (<div className="mt-3 rounded-xl overflow-hidden border border-gray-100 dark:border-gray-700 max-w-sm shadow-sm"><img src={n.image} className="w-full object-cover" alt="Proof" /></div>)}
                                    {n.link && (<a href={n.link} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 font-bold mt-3 inline-flex items-center gap-1 hover:underline"><span className="material-symbols-outlined text-sm">open_in_new</span> Open Link</a>)}
                                </div>
                            )))}
                        </div>
                    )}
                </div>
            </main>

            {/* VERIFICATION MODAL & TASK MODAL (unchanged) */}
            {showVerifyModal && (<div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fade-in"><div className="bg-white dark:bg-gray-800 w-full max-w-sm rounded-[2rem] p-6 shadow-2xl relative"><button onClick={() => setShowVerifyModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"><span className="material-symbols-outlined">close</span></button><div className="text-center mb-6 mt-2"><div className="size-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner"><span className="material-symbols-outlined text-4xl">gpp_good</span></div><h3 className="text-xl font-black text-gray-900 dark:text-white">Verify Account</h3><p className="text-sm text-gray-500 mt-1">Link your Google Account for recovery.</p></div><div className="space-y-4"><div><label className="block text-xs font-bold text-gray-500 uppercase mb-2">Enter Gmail Address</label><div className="flex items-center gap-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-4 py-3"><span className="material-symbols-outlined text-gray-400">mail</span><input type="email" className="bg-transparent w-full outline-none text-sm font-bold text-gray-800 dark:text-white" placeholder="yourname@gmail.com" value={recoveryEmail} onChange={(e) => setRecoveryEmail(e.target.value)} /></div></div><button onClick={handleVerificationSubmit} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg transition-transform active:scale-95">Link & Verify Card</button></div></div></div>)}
            {showTaskModal && (<div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in overflow-y-auto"><div className="bg-white dark:bg-surface-dark w-full max-w-sm rounded-[2rem] p-6 shadow-2xl slide-up-animation max-h-[85vh] overflow-y-auto border border-gray-100"><div className="text-center mb-6"><div className="size-16 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner"><span className="material-symbols-outlined text-4xl">task</span></div><h2 className="text-2xl font-black text-gray-900 dark:text-white">Earn Rewards</h2><p className="text-sm text-gray-500 mt-1 font-medium">Daily Check-in & Special Offers</p></div>{availablePromoTasks.length > 0 && (<div><h3 className="font-bold text-sm text-gray-700 mb-3 flex items-center gap-2"><span className="material-symbols-outlined text-indigo-500">rocket_launch</span>Special Offers</h3><div className="space-y-4">{availablePromoTasks.map(task => (<div key={task.id} className="bg-white border border-indigo-100 shadow-sm rounded-xl p-3 overflow-hidden">{task.image && (<img src={task.image} alt={task.title} className="w-full h-32 object-cover rounded-lg mb-3" />)}<div className="mb-2"><div className="font-bold text-gray-800 text-sm">{task.title}</div><div className="text-xs text-green-600 font-bold">Reward: ₹{task.reward}</div></div>{!tasksStarted.includes(task.id) ? (<button onClick={() => handleStartPromoTask(task.id, task.link)} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg text-xs font-bold">Start Task</button>) : (<button onClick={() => handleClaimPromoTask(task)} className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg text-xs font-bold animate-pulse">Claim Reward</button>)}</div>))}</div></div>)}{availablePromoTasks.length === 0 && (<div className="text-center py-8 text-gray-400"><span className="material-symbols-outlined text-4xl mb-2">check_circle</span><p>All promo tasks completed!</p></div>)}<div className="mt-6 pt-4 border-t border-gray-100"><button onClick={() => setShowTaskModal(false)} className="w-full py-3 rounded-xl font-bold text-gray-500 hover:bg-gray-100 transition-colors">Close</button></div></div></div>)}
        </div>
    );
};

export default Profile;
