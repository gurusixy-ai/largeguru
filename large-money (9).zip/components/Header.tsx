
import React, { useState } from 'react';
import { AppNotification } from '../types';

interface HeaderProps {
    balance: number;
    bankBalance?: number; // Added Bank Money
    bonusBalance?: number; // Added Bonus Money
    userName: string;
    onWalletClick: () => void;
    onProfileClick: () => void;
    onLogout: () => void;
    notificationPnl: number | null;
    notifications?: AppNotification[];
}

const Header: React.FC<HeaderProps> = ({ balance, bankBalance = 0, bonusBalance = 0, userName, onWalletClick, onProfileClick, onLogout, notificationPnl, notifications = [] }) => {
    const [showNotes, setShowNotes] = useState(false);
    const unreadCount = notifications.filter(n => !n.read).length;
    
    // Calculate Total Effective Balance for betting
    const totalBalance = balance + bankBalance;

    return (
        <header className="sticky top-0 z-50 bg-white/95 dark:bg-surface-dark/95 backdrop-blur-lg border-b border-[#e7ebf3] dark:border-gray-800 shadow-sm transition-all">
            <div className="px-3 h-16 flex items-center justify-between">
                
                {/* LEFT SIDE: Profile Button + Logo */}
                <div className="flex items-center gap-2">
                    <button 
                        onClick={onProfileClick} 
                        className="relative flex items-center justify-center size-10 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30 border-[2px] border-white dark:border-gray-800 ring-2 ring-indigo-100 dark:ring-gray-700 transition-transform active:scale-95 group" 
                        title="My Profile"
                    >
                        <span className="material-symbols-outlined text-[20px] group-hover:scale-110 transition-transform">person</span>
                        <span className="absolute bottom-0 right-0 size-2.5 bg-green-500 border-2 border-white dark:border-gray-900 rounded-full"></span>
                    </button>

                    <div className="hidden sm:flex items-center gap-2 text-text-main dark:text-white cursor-pointer group" onClick={() => window.location.reload()}>
                        <div>
                            <h2 className="text-sm font-black leading-none tracking-tight block">LARGE MONEY</h2>
                            <span className="text-[8px] font-bold text-primary tracking-widest uppercase">Win Go</span>
                        </div>
                    </div>
                </div>
                
                {/* RIGHT SIDE: Notifications + Wallet Breakdown */}
                <div className="flex items-center gap-2">
                    
                    {/* Wallet Display */}
                    <div className="relative group cursor-pointer" onClick={onWalletClick}>
                        <div className="flex items-center gap-2 px-2 py-1 bg-gray-100 dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 shadow-inner hover:bg-white dark:hover:bg-gray-700 transition-all duration-300">
                             
                             {/* Icon */}
                             <div className="size-8 bg-green-600 rounded-lg flex items-center justify-center text-white shadow-sm shrink-0">
                                 <span className="material-symbols-outlined text-[18px]">account_balance_wallet</span>
                             </div>

                             {/* Balance Text Column */}
                             <div className="flex flex-col leading-none pr-1">
                                 <div className="flex items-center gap-1">
                                     <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tight">Total</span>
                                     <span className="text-sm font-black text-gray-900 dark:text-white tracking-tight">
                                        ₹{totalBalance.toLocaleString('en-IN')}
                                     </span>
                                 </div>
                                 
                                 {/* Bank & Bonus Breakdown */}
                                 {(bankBalance > 0 || bonusBalance > 0) && (
                                     <div className="flex gap-1 mt-0.5">
                                        {bankBalance > 0 && (
                                            <span className="text-[9px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-1.5 py-0.5 rounded border border-blue-100 dark:border-blue-800 flex items-center gap-0.5">
                                                <span className="material-symbols-outlined text-[8px]">lock</span> {bankBalance}
                                            </span>
                                        )}
                                        {bonusBalance > 0 && (
                                            <span className="text-[9px] font-bold text-orange-600 bg-orange-50 dark:bg-orange-900/30 px-1.5 py-0.5 rounded border border-orange-100 dark:border-orange-800 flex items-center gap-0.5">
                                                <span className="material-symbols-outlined text-[8px]">star</span> {bonusBalance}
                                            </span>
                                        )}
                                     </div>
                                 )}
                             </div>
                        </div>
                        
                        {/* Live PnL Notification Bubble */}
                        {notificationPnl !== null && (
                            <div className={`absolute top-10 right-0 mt-2 px-3 py-1.5 rounded-lg text-xs font-bold shadow-xl animate-bounce flex items-center gap-1 z-50 whitespace-nowrap border-2 ${
                                notificationPnl >= 0 ? 'bg-green-50 text-green-700 border-green-200' : 'bg-red-50 text-red-700 border-red-200'
                            }`}>
                                <span className="material-symbols-outlined text-xs">{notificationPnl >= 0 ? 'trending_up' : 'trending_down'}</span>
                                <span className="text-[10px]">{notificationPnl >= 0 ? '+' : ''}₹{Math.abs(notificationPnl).toFixed(0)}</span>
                            </div>
                        )}
                    </div>

                    {/* Notification Bell */}
                    <div className="relative">
                        <button onClick={() => setShowNotes(!showNotes)} className="flex items-center justify-center size-9 rounded-full text-gray-500 hover:bg-gray-100 hover:text-primary transition-colors relative">
                            <span className="material-symbols-outlined text-[22px]">notifications</span>
                            {unreadCount > 0 && (
                                <span className="absolute top-1.5 right-1.5 size-2 bg-red-500 rounded-full border border-white animate-pulse"></span>
                            )}
                        </button>
                        
                        {showNotes && (
                            <div className="absolute top-full right-0 mt-3 w-72 bg-white dark:bg-surface-dark border border-gray-100 dark:border-gray-700 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.2)] rounded-2xl z-50 max-h-96 overflow-y-auto animate-fade-in">
                                <div className="p-4 border-b border-gray-100 dark:border-gray-700 font-bold text-sm bg-gray-50/50 dark:bg-gray-800/50 flex justify-between items-center">
                                    <span>Notifications</span>
                                    <span className="text-xs font-normal text-gray-500">Recent</span>
                                </div>
                                {notifications.length === 0 && (
                                    <div className="p-8 text-center text-gray-400 flex flex-col items-center">
                                        <span className="material-symbols-outlined text-3xl mb-2 opacity-50">notifications_off</span>
                                        <span className="text-xs">No new notifications</span>
                                    </div>
                                )}
                                {notifications.map(n => (
                                    <div key={n.id} className="p-4 border-b border-gray-50 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                                        <div className="font-bold text-sm text-gray-800 dark:text-gray-200 mb-1">{n.title}</div>
                                        <div className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">{n.message}</div>
                                        {n.image && (
                                            <div className="mt-2 rounded-lg overflow-hidden border border-gray-100 dark:border-gray-700">
                                                <img src={n.image} className="w-full object-cover" alt="Proof" />
                                            </div>
                                        )}
                                        {n.link && (
                                            <a href={n.link} target="_blank" rel="noopener noreferrer" className="text-xs text-primary font-bold mt-2 block hover:underline truncate">
                                                Open Link: {n.link}
                                            </a>
                                        )}
                                        <div className="text-[10px] text-gray-400 mt-2 text-right">{new Date(n.timestamp).toLocaleDateString()}</div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
