
import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, UserBet } from '../types';

interface AviatorGameProps {
    user: UserProfile;
    onBack: () => void;
    onUpdateUser: (updatedUser: UserProfile) => void;
}

interface BetState {
    id: 1 | 2;
    amount: number | string;
    status: 'IDLE' | 'WAITING' | 'PLACED' | 'CASHED';
    cashoutAt?: number;
    autoCashout: boolean;
    autoCashoutValue: number | string;
    autoBet: boolean;
    panelMode: 'bet' | 'auto';
    isPaid?: boolean; // New flag to track if deduction happened
}

interface FakeUserBet {
    id: string;
    name: string;
    amount: number;
    targetMultiplier: number; 
    cashedOut: boolean;
    cashedAt?: number;
    image: string;
}

// Wallet Animation Interface
interface WalletAnim {
    id: number;
    type: 'credit' | 'debit';
    amount: number;
}

// --- HELPER COMPONENT: Animated Balance Counter ---
const AnimatedBalance = ({ value }: { value: number }) => {
    const [displayValue, setDisplayValue] = useState(value);

    useEffect(() => {
        if (value === displayValue) return;

        const start = displayValue;
        const end = value;
        const duration = 800; // 800ms animation
        const startTime = performance.now();

        const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Ease-out cubic function for smooth settling
            const ease = 1 - Math.pow(1 - progress, 3);
            
            const current = start + (end - start) * ease;
            setDisplayValue(current);

            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                setDisplayValue(end); // Ensure exact final value
            }
        };

        requestAnimationFrame(animate);
    }, [value]);

    return (
        <span className="font-mono font-bold text-sm tracking-wide transition-colors duration-300 text-green-400">
            {Math.floor(displayValue).toLocaleString('en-IN')}
        </span>
    );
};

const AviatorGame: React.FC<AviatorGameProps> = ({ user, onBack, onUpdateUser }) => {
    // --- GAME ENGINE STATE ---
    const [gameState, setGameState] = useState<'WAITING' | 'FLYING' | 'CRASHED'>('WAITING');
    const [multiplier, setMultiplier] = useState(1.00);
    const [countdown, setCountdown] = useState(0);
    const [history, setHistory] = useState<number[]>([1.2, 2.4, 5.1, 1.1, 12.5, 1.05, 3.4]);
    
    // --- WALLET ANIMATION STATE ---
    const [walletAnims, setWalletAnims] = useState<WalletAnim[]>([]);
    
    // --- FAKE USER STATE ---
    const [activePlayerCount, setActivePlayerCount] = useState(1200);
    const [fakeBets, setFakeBets] = useState<FakeUserBet[]>([]);
    
    // --- BETTING STATE ---
    const [bets, setBets] = useState<{ 1: BetState; 2: BetState }>({
        1: { id: 1, amount: 10, status: 'IDLE', autoCashout: false, autoCashoutValue: 2.00, autoBet: false, panelMode: 'bet', isPaid: false },
        2: { id: 2, amount: 50, status: 'IDLE', autoCashout: false, autoCashoutValue: 1.50, autoBet: false, panelMode: 'bet', isPaid: false }
    });

    // --- REFS ---
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const requestRef = useRef<number>(0);
    const startTimeRef = useRef<number>(0);
    const crashPointRef = useRef<number>(0);
    const gridOffsetRef = useRef<number>(0);
    
    const userRef = useRef(user);

    const TAKEOFF_DURATION = 5; 

    // --- INITIALIZATION ---
    useEffect(() => {
        generateFakeData(); // Initial load
        startCountdown();
        return () => {
            if (requestRef.current) cancelAnimationFrame(requestRef.current);
        };
    }, []);

    // Sync user ref to ensure live updates access latest balance
    useEffect(() => {
        userRef.current = user;
    }, [user]);

    // --- WALLET VISUALS HELPER ---
    const triggerWalletAnim = (type: 'credit' | 'debit', amount: number) => {
        const id = Date.now();
        setWalletAnims(prev => [...prev, { id, type, amount }]);
        setTimeout(() => {
            setWalletAnims(prev => prev.filter(a => a.id !== id));
        }, 2000);
    };

    // --- CORE WALLET LOGIC ---
    const deductFunds = (amount: number): boolean => {
        const currentUser = userRef.current;
        const currentBank = currentUser.bankMoney || 0;
        const currentWin = currentUser.balance || 0;
        const totalAvailable = currentBank + currentWin;

        if (amount > totalAvailable) return false;

        let bankDed = 0;
        let winDed = 0;
        let remaining = amount;

        if (currentBank >= remaining) {
            bankDed = remaining;
            remaining = 0;
        } else {
            bankDed = currentBank;
            remaining -= currentBank;
            winDed = remaining;
        }

        const newBankMoney = Math.max(0, currentBank - bankDed);
        const newBalance = Math.max(0, currentWin - winDed);

        onUpdateUser({ 
            ...currentUser, 
            bankMoney: newBankMoney,
            balance: newBalance
        });
        
        triggerWalletAnim('debit', amount);
        return true;
    };

    const refundFunds = (amount: number) => {
        const currentUser = userRef.current;
        // Refund primarily to balance to keep it simple, or revert to bankMoney if tracking allows.
        // For UI simplicity, we add to balance (Winning Wallet) or restore proportionately.
        // Here we restore to balance to ensure user can withdraw or re-bet.
        const newBalance = (currentUser.balance || 0) + amount;
        
        onUpdateUser({ ...currentUser, balance: newBalance });
        triggerWalletAnim('credit', amount);
    };

    // --- HISTORY SAVING HELPER ---
    const saveBetResult = (amount: number, status: 'Won' | 'Lost', winLossAmount: number, crashM: number) => {
        const currentUser = userRef.current;
        const newBetRecord: UserBet = {
            id: 'av-' + Math.random().toString(36).substr(2, 9),
            period: Date.now().toString(),
            selection: `Aviator ${status === 'Won' ? 'Cashout' : 'Crash'}`,
            amount: amount,
            quantity: 1,
            winLoss: winLossAmount,
            status: status,
            fee: 0,
            userId: currentUser.identifier,
            userName: currentUser.name,
            resultColor: status === 'Won' ? 'Green' : 'Red' 
        };

        const allBets = JSON.parse(localStorage.getItem('ncci_all_bets') || '[]');
        localStorage.setItem('ncci_all_bets', JSON.stringify([newBetRecord, ...allBets]));
    };

    // --- AUTO BET & ROUND RESET LOGIC ---
    useEffect(() => {
        if (gameState === 'WAITING') {
            setBets(prev => {
                const next = { ...prev };
                let changed = false;
                ([1, 2] as const).forEach(id => {
                    // Reset Cashed bets to IDLE for next round
                    if (next[id].status === 'CASHED') {
                        next[id] = { ...next[id], status: 'IDLE', cashoutAt: undefined, isPaid: false };
                        changed = true;
                    }
                    // Trigger Auto Bet
                    if (next[id].autoBet && next[id].status === 'IDLE') {
                        next[id] = { ...next[id], status: 'WAITING', isPaid: false }; // Auto bets start as unpaid
                        changed = true;
                    }
                });
                return changed ? next : prev;
            });
        }
    }, [gameState]);

    // --- FAKE USER LOGIC ---
    const generateFakeData = () => {
        const count = Math.floor(Math.random() * (1500 - 1000 + 1) + 1000);
        setActivePlayerCount(count);
        const newFakeBets: FakeUserBet[] = [];
        const names = ['Arun', 'Vijay', 'Rahul', 'Suresh', 'Priya', 'Anjali', 'Dev', 'King', 'Rocky', 'User88', 'Winner', 'Luck', 'Sky', 'Pilot', 'Ravi', 'Amit', 'Sneha', 'Pooja', 'Karan', 'Simran'];
        
        for (let i = 0; i < 40; i++) {
            const isHighRoller = Math.random() > 0.8;
            const amt = isHighRoller ? Math.floor(Math.random() * 5000 + 500) : Math.floor(Math.random() * 400 + 10);
            const target = Math.random() > 0.7 ? (Math.random() * 10 + 2) : (Math.random() * 1.9 + 1.1);
            const name = names[Math.floor(Math.random() * names.length)] + '***' + Math.floor(Math.random()*99);
            newFakeBets.push({ id: `fake-${i}-${Date.now()}`, name: name, amount: amt, targetMultiplier: target, cashedOut: false, image: '' });
        }
        setFakeBets(newFakeBets.sort((a,b) => b.amount - a.amount)); 
    };

    // --- GAME LOOP ---
    useEffect(() => {
        if (gameState === 'FLYING') {
            startTimeRef.current = Date.now();
            const configStr = localStorage.getItem('ncci_aviator_config');
            let crashVal = 0;
            if (configStr) {
                const config = JSON.parse(configStr);
                if (config.manualCrashX) crashVal = config.manualCrashX;
                else {
                    if (Math.random() < 0.05) crashVal = 1.00; 
                    else crashVal = Math.max(1.00, (0.96 / (1 - Math.random())));
                }
            } else {
                crashVal = Math.max(1.00, (0.96 / (1 - Math.random())));
            }
            crashPointRef.current = Math.min(crashVal, 10000); 

            const animate = () => {
                const now = Date.now();
                const elapsed = (now - startTimeRef.current) / 1000;
                const nextMult = 1 + (0.06 * elapsed) + (0.06 * Math.pow(elapsed, 2));

                if (nextMult >= crashPointRef.current) {
                    crash(crashPointRef.current);
                } else {
                    setMultiplier(nextMult);
                    checkAutoCashouts(nextMult);
                    updateFakeUsers(nextMult);
                    drawGame(nextMult, elapsed, false);
                    requestRef.current = requestAnimationFrame(animate);
                }
            };
            requestRef.current = requestAnimationFrame(animate);
        } else if (gameState === 'CRASHED') {
            if (canvasRef.current) drawGame(multiplier, 0, true);
            setTimeout(() => startCountdown(), 3000);
        } else if (gameState === 'WAITING') {
            if (canvasRef.current) {
                const ctx = canvasRef.current.getContext('2d');
                if (ctx) drawWaitingScreen(ctx);
            }
        }
    }, [gameState]);

    const updateFakeUsers = (currentMult: number) => {
        setFakeBets(prev => prev.map(bet => {
            if (!bet.cashedOut && currentMult >= bet.targetMultiplier) {
                return { ...bet, cashedOut: true, cashedAt: currentMult };
            }
            return bet;
        }));
    };

    const startCountdown = () => {
        setGameState('WAITING');
        setMultiplier(1.00);
        generateFakeData(); 
        
        let timer = 5;
        setCountdown(timer);
        const interval = setInterval(() => {
            timer -= 0.1;
            setCountdown(Math.max(0, timer));
            if (timer <= 0) {
                clearInterval(interval);
                processUserBets(); // Start Round
                setGameState('FLYING');
            }
        }, 100);
    };

    const crash = (finalMult: number) => {
        setMultiplier(finalMult);
        setGameState('CRASHED');
        setHistory(prev => [finalMult, ...prev].slice(0, 20));
        
        setBets(prev => {
            const next = { ...prev };
            ([1, 2] as const).forEach(id => {
                // Reset placed bets to IDLE, ready for next round
                // We keep 'isPaid' true if they lost? No, we reset for next bet.
                if (next[id].status === 'PLACED') {
                    // Money was already deducted, just record loss
                    saveBetResult(Number(next[id].amount), 'Lost', -Number(next[id].amount), finalMult);
                    next[id].status = 'IDLE';
                    next[id].isPaid = false; 
                }
            });
            return next;
        });
    };

    // --- GAME START LOGIC (Finalizes Bets) ---
    const processUserBets = () => {
        // This function now primarily handles Auto-Bets that haven't been paid yet
        // and transitions WAITING bets to PLACED.
        
        setBets(prev => {
            const next = { ...prev };
            
            ([1, 2] as const).forEach(id => {
                if (next[id].status === 'WAITING') {
                    const amt = Number(next[id].amount);
                    
                    if (amt < 5) {
                        // Invalid amount
                        next[id].status = 'IDLE';
                        next[id].autoBet = false;
                        next[id].isPaid = false;
                        return;
                    }

                    // If NOT paid yet (Auto Bet), try deduct now
                    if (!next[id].isPaid) {
                        const success = deductFunds(amt);
                        if (success) {
                            next[id].isPaid = true;
                            next[id].status = 'PLACED';
                        } else {
                            next[id].status = 'IDLE';
                            next[id].autoBet = false; // Disable auto bet if funds run out
                            alert("Insufficient Balance for Auto Bet!");
                        }
                    } else {
                        // Already paid (Manual Bet), just advance status
                        next[id].status = 'PLACED';
                    }
                }
            });

            return next;
        });
    };

    const checkAutoCashouts = (currentMult: number) => {
        let totalWin = 0;
        let changed = false;
        
        setBets(prev => {
            const next = { ...prev };
            ([1, 2] as const).forEach(id => {
                const bet = next[id];
                if (bet.status === 'PLACED' && bet.autoCashout && currentMult >= Number(bet.autoCashoutValue)) {
                    const amount = Number(bet.amount);
                    const win = Math.floor(amount * Number(bet.autoCashoutValue));
                    totalWin += win;
                    
                    next[id] = { ...bet, status: 'CASHED', cashoutAt: Number(bet.autoCashoutValue) };
                    changed = true;
                    saveBetResult(amount, 'Won', win - amount, Number(bet.autoCashoutValue));
                }
            });
            
            // Live Update on Win
            if (changed && totalWin > 0) {
                const currentUser = userRef.current; 
                triggerWalletAnim('credit', totalWin);
                onUpdateUser({ ...currentUser, balance: (currentUser.balance || 0) + totalWin });
            }
            
            return changed ? next : prev;
        });
    };

    const placeBet = (id: 1 | 2) => {
        const amt = Number(bets[id].amount);
        if (amt < 5) {
            alert("Minimum bet is ₹5");
            return;
        }

        if (gameState === 'WAITING') {
            // MANUAL TOGGLE
            setBets(prev => {
                const currentStatus = prev[id].status;
                const next = { ...prev };

                if (currentStatus === 'IDLE') {
                    // Placing Bet: Deduct Immediately
                    const success = deductFunds(amt);
                    if (success) {
                        next[id] = { ...prev[id], status: 'WAITING', isPaid: true };
                    } else {
                        alert("Insufficient Balance!");
                    }
                } else if (currentStatus === 'WAITING') {
                    // Cancelling Bet: Refund Immediately
                    if (prev[id].isPaid) {
                        refundFunds(amt);
                    }
                    next[id] = { ...prev[id], status: 'IDLE', isPaid: false };
                }
                return next;
            });

        } else if (gameState === 'FLYING') {
            // IN-FLIGHT ACTIONS
            if (bets[id].status === 'PLACED') {
                // MANUAL CASHOUT
                const amount = Number(bets[id].amount);
                const win = Math.floor(amount * multiplier);
                const currentUser = userRef.current;
                
                // Live Update on Win
                triggerWalletAnim('credit', win);
                onUpdateUser({ ...currentUser, balance: (currentUser.balance || 0) + win });
                saveBetResult(amount, 'Won', win - amount, multiplier);

                setBets(prev => ({ ...prev, [id]: { ...prev[id], status: 'CASHED', cashoutAt: multiplier } }));
            } else if (bets[id].status === 'IDLE') {
                // Queue for next round (No deduction yet, wait for round start)
                // OR deduct now? Standard is wait for round logic for "Queued" bets, but let's deduct to be safe/consistent?
                // Actually, if we deduct now, we need to handle "Cancel" in Queue state.
                // For simplicity, let's treat Queue like WAITING - Deduct NOW.
                
                const success = deductFunds(amt);
                if (success) {
                    setBets(prev => ({ ...prev, [id]: { ...prev[id], status: 'WAITING', isPaid: true } }));
                } else {
                    alert("Insufficient Balance!");
                }
            } else if (bets[id].status === 'WAITING') {
                // Cancel Queued Bet
                if (bets[id].isPaid) refundFunds(amt);
                setBets(prev => ({ ...prev, [id]: { ...prev[id], status: 'IDLE', isPaid: false } }));
            }
        }
    };

    // --- CANVAS DRAWING (Standard Aviator Style) ---
    const drawWaitingScreen = (ctx: CanvasRenderingContext2D) => {
        const width = ctx.canvas.width;
        const height = ctx.canvas.height;
        ctx.fillStyle = '#0F1923';
        ctx.fillRect(0, 0, width, height);
        
        ctx.strokeStyle = '#1A242D';
        ctx.lineWidth = 1;
        for(let i=0; i<width; i+=40) { ctx.beginPath(); ctx.moveTo(i,0); ctx.lineTo(i,height); ctx.stroke(); }
        for(let i=0; i<height; i+=40) { ctx.beginPath(); ctx.moveTo(0,i); ctx.lineTo(width,i); ctx.stroke(); }

        const cx = width / 2;
        const cy = height / 2;
        
        ctx.font = '900 20px sans-serif';
        ctx.fillStyle = 'white';
        ctx.textAlign = 'center';
        ctx.fillText("WAITING FOR ROUND", cx, cy - 20);
        
        const barW = Math.min(200, width * 0.6);
        const barH = 6;
        ctx.fillStyle = '#1A242D';
        ctx.fillRect(cx - barW/2, cy + 10, barW, barH);
        
        const pct = Math.max(0, countdown / 5);
        ctx.fillStyle = '#F12C4C';
        ctx.fillRect(cx - barW/2, cy + 10, barW * (1 - pct), barH);
        
        ctx.font = 'bold 14px monospace';
        ctx.fillStyle = '#F12C4C';
        ctx.fillText(countdown.toFixed(1) + "s", cx, cy + 40);
    };

    const drawGame = (currentMult: number, elapsed: number, isCrashed: boolean) => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        const width = canvas.width;
        const height = canvas.height;

        ctx.fillStyle = '#0F1923';
        ctx.fillRect(0, 0, width, height);

        const speed = isCrashed ? 0 : 2 + (currentMult * 2);
        gridOffsetRef.current = (gridOffsetRef.current - speed) % 40;
        
        ctx.strokeStyle = '#1A242D';
        ctx.lineWidth = 1;
        for (let x = gridOffsetRef.current; x < width; x += 40) {
            ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
        }
        for (let y = 0; y < height; y += 40) {
            ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
        }

        const progressX = Math.min(1, elapsed / TAKEOFF_DURATION);
        const planeX = 50 + (progressX * (width - 100));
        const heightScale = Math.min(1, Math.log10(currentMult) * 1.5); 
        const planeY = height - 50 - (heightScale * (height - 100));

        if (!isCrashed) {
            ctx.beginPath();
            ctx.moveTo(50, height - 50); 
            const cpX = 50 + (planeX - 50) / 2;
            const cpY = height - 50; 
            ctx.quadraticCurveTo(cpX, cpY, planeX - 10, planeY + 5);
            ctx.strokeStyle = '#F12C4C';
            ctx.lineWidth = 4;
            ctx.stroke();
            
            ctx.lineTo(planeX, height);
            ctx.lineTo(50, height);
            ctx.closePath();
            const grad = ctx.createLinearGradient(0, 0, 0, height);
            grad.addColorStop(0, 'rgba(241, 44, 76, 0.4)');
            grad.addColorStop(1, 'rgba(241, 44, 76, 0)');
            ctx.fillStyle = grad;
            ctx.fill();

            ctx.save();
            ctx.translate(planeX, planeY);
            const tilt = Math.min(0, -0.2 * progressX);
            ctx.rotate(tilt);
            ctx.fillStyle = '#E40037';
            ctx.shadowColor = '#F12C4C';
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.moveTo(20, 0);
            ctx.lineTo(-10, 10);
            ctx.lineTo(-5, 0);
            ctx.lineTo(-10, -10);
            ctx.fill();
            ctx.restore();
        }

        if (isCrashed) {
            ctx.font = '900 32px sans-serif';
            ctx.fillStyle = '#F12C4C';
            ctx.textAlign = 'center';
            ctx.fillText("FLEW AWAY", width/2, height/2 - 20);
            
            ctx.font = 'bold 48px monospace';
            ctx.fillStyle = 'white';
            ctx.fillText(currentMult.toFixed(2) + "x", width/2, height/2 + 40);
        }
    };

    useEffect(() => {
        const handleResize = () => {
            if (canvasRef.current && canvasRef.current.parentElement) {
                canvasRef.current.width = canvasRef.current.parentElement.clientWidth;
                canvasRef.current.height = canvasRef.current.parentElement.clientHeight;
            }
        };
        window.addEventListener('resize', handleResize);
        handleResize();
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    // --- RENDER ---
    return (
        <div className="fixed inset-0 z-50 bg-[#0F1923] flex flex-col font-sans select-none overflow-hidden">
            {/* Header */}
            <div className="h-14 bg-[#141b22] px-4 flex justify-between items-center border-b border-gray-800 shrink-0 z-20 shadow-md">
                <div className="flex items-center gap-3 cursor-pointer group" onClick={onBack}>
                    <div className="bg-gray-800 p-1.5 rounded-lg group-hover:bg-gray-700 transition-colors">
                        <span className="material-symbols-outlined text-gray-400 text-lg">arrow_back</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                        <span className="material-symbols-outlined text-red-500 text-2xl animate-pulse">rocket_launch</span>
                        <span className="text-white font-black italic text-xl tracking-wider">AVIATOR</span>
                    </div>
                </div>
                
                {/* LIVE WALLET DISPLAY - UPDATED WITH SCROLLING ANIMATION */}
                <div className="relative">
                    <div className="bg-[#0F1923] pl-2 pr-4 py-1.5 rounded-full border border-green-500/20 flex items-center gap-2 shadow-inner overflow-hidden">
                        <div className="size-5 rounded-full bg-green-500 flex items-center justify-center text-black font-bold text-xs">₹</div>
                        
                        {/* Animated Counter Component */}
                        <AnimatedBalance value={user.balance + (user.bankMoney || 0)} />
                    </div>
                    
                    {/* Floating +/- Animations */}
                    {walletAnims.map(anim => (
                        <div 
                            key={anim.id}
                            className={`absolute -bottom-6 right-0 text-xs font-bold animate-[slideUp_1s_ease-out_forwards] ${anim.type === 'credit' ? 'text-green-400' : 'text-red-500'}`}
                        >
                            {anim.type === 'credit' ? '+' : '-'}₹{anim.amount}
                        </div>
                    ))}
                </div>
            </div>

            {/* History Bar */}
            <div className="h-9 bg-[#0f151b] border-b border-gray-800 flex items-center px-4 gap-2 overflow-x-auto no-scrollbar shrink-0 z-10 shadow-sm">
                <span className="material-symbols-outlined text-gray-600 text-sm">history</span>
                {history.map((val, i) => (
                    <div key={i} className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold font-mono shrink-0 border transition-all ${val >= 10 ? 'bg-pink-500/10 text-pink-500 border-pink-500/30' : val >= 2 ? 'bg-purple-500/10 text-purple-500 border-purple-500/30' : 'bg-blue-500/10 text-blue-500 border-blue-500/30'}`}>
                        {val.toFixed(2)}x
                    </div>
                ))}
            </div>

            {/* Main Layout */}
            <div className="flex-1 flex flex-col overflow-hidden">
                <div className="h-[240px] shrink-0 relative bg-[#0F1923] w-full border-b border-gray-800">
                    <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block touch-none" />
                    {gameState === 'FLYING' && (
                        <div className="absolute top-[20%] left-1/2 -translate-x-1/2 text-center pointer-events-none z-10">
                            <div className="text-5xl font-black font-mono text-white drop-shadow-[0_0_30px_rgba(241,44,76,0.4)] tracking-tighter">
                                {multiplier.toFixed(2)}x
                            </div>
                        </div>
                    )}
                </div>

                <div className="flex-1 overflow-y-auto bg-[#0F1923] relative">
                    {/* BET CONTROLS */}
                    <div className="p-3 pb-0 space-y-3">
                        {[1, 2].map((idVal) => {
                            const id = idVal as 1 | 2;
                            const bet = bets[id];
                            const isPlaced = bet.status === 'PLACED';
                            const isWaiting = bet.status === 'WAITING';
                            const isCashed = bet.status === 'CASHED';

                            return (
                                <div key={id} className={`bg-[#1A242D] rounded-xl p-3 border border-gray-700/50 shadow-lg transform-gpu ${isPlaced ? 'ring-1 ring-green-500/30' : ''}`}>
                                    {/* Tabs */}
                                    <div className="flex justify-center mb-2">
                                        <div className="bg-black/40 rounded-full p-0.5 flex gap-1">
                                            <button 
                                                onClick={() => !isPlaced && !isWaiting && setBets(p => ({...p, [id]: {...p[id], panelMode: 'bet'}}))}
                                                className={`px-4 py-1 rounded-full text-[10px] font-bold transition-all ${bet.panelMode === 'bet' ? 'bg-[#2C3E50] text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}`}
                                            >
                                                Bet
                                            </button>
                                            <button 
                                                onClick={() => !isPlaced && !isWaiting && setBets(p => ({...p, [id]: {...p[id], panelMode: 'auto'}}))}
                                                className={`px-4 py-1 rounded-full text-[10px] font-bold transition-all ${bet.panelMode === 'auto' ? 'bg-[#2C3E50] text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}`}
                                            >
                                                Auto
                                            </button>
                                        </div>
                                    </div>

                                    <div className="flex gap-2 h-14 mb-2">
                                        <div className="flex-1 flex flex-col justify-between">
                                            <div className="flex items-center bg-[#0F1923] rounded-lg border border-gray-600 h-full relative overflow-hidden group">
                                                <button onClick={() => !isPlaced && !isWaiting && setBets(p => ({...p, [id]: {...p[id], amount: Math.max(5, Number(p[id].amount) - 10)}}))} className="absolute left-0 w-10 h-full flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 text-xl font-bold z-10 bg-black/10 border-r border-white/5">-</button>
                                                <input 
                                                    type="number" 
                                                    value={bet.amount} 
                                                    onChange={(e) => setBets(p => ({...p, [id]: {...p[id], amount: e.target.value}}))} 
                                                    className="w-full h-full bg-transparent text-center font-bold text-white text-xl outline-none" 
                                                    disabled={isPlaced || isWaiting} 
                                                />
                                                <button onClick={() => !isPlaced && !isWaiting && setBets(p => ({...p, [id]: {...p[id], amount: Number(p[id].amount) + 10}}))} className="absolute right-0 w-10 h-full flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 text-xl font-bold z-10 bg-black/10 border-l border-white/5">+</button>
                                            </div>
                                        </div>

                                        <button 
                                            onClick={() => placeBet(id)} 
                                            disabled={isCashed || gameState === 'CRASHED'} 
                                            className={`w-32 rounded-xl flex flex-col items-center justify-center shadow-[0_4px_0_rgba(0,0,0,0.3)] active:shadow-none active:translate-y-1 transition-all relative overflow-hidden border-t border-white/10 ${
                                                isPlaced ? 'bg-orange-500 hover:bg-orange-600' 
                                                : isWaiting ? 'bg-red-500 hover:bg-red-600' 
                                                : 'bg-green-600 hover:bg-green-700'
                                            } ${isCashed || gameState === 'CRASHED' ? 'opacity-50 grayscale cursor-not-allowed' : ''}`}
                                        >
                                            {isPlaced ? (
                                                <>
                                                    <span className="text-[10px] font-bold text-white/90 uppercase tracking-wide mb-0.5">Cash Out</span>
                                                    <span className="text-xl font-black font-mono text-white leading-none">{(Number(bet.amount) * multiplier).toFixed(0)}</span>
                                                    <span className="text-[9px] font-mono text-white/80">{multiplier.toFixed(2)}x</span>
                                                </>
                                            ) : isWaiting ? (
                                                <>
                                                    <span className="text-[10px] font-bold text-white/90 uppercase tracking-wide mb-1">Waiting</span>
                                                    <span className="text-xs font-black text-white bg-black/20 px-3 py-0.5 rounded">CANCEL</span>
                                                </>
                                            ) : isCashed ? (
                                                <>
                                                    <span className="text-[10px] font-bold text-white/90 uppercase tracking-wide">Won</span>
                                                    <span className="text-lg font-black font-mono text-white">{(Number(bet.amount) * (bet.cashoutAt || 1)).toFixed(0)}</span>
                                                </>
                                            ) : (
                                                <>
                                                    <span className="text-lg font-black text-white leading-none mb-0.5">BET</span>
                                                    <span className="text-[10px] font-bold text-white/70 uppercase">Start Round</span>
                                                </>
                                            )}
                                        </button>
                                    </div>

                                    {/* Auto Controls Section */}
                                    {bet.panelMode === 'auto' && (
                                        <div className="mt-3 pt-3 border-t border-white/5 space-y-3 animate-fade-in">
                                            {/* Auto Bet Toggle */}
                                            <div className="flex items-center justify-between">
                                                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Auto Bet</span>
                                                <button 
                                                    onClick={() => setBets(p => ({...p, [id]: {...p[id], autoBet: !p[id].autoBet}}))}
                                                    className={`w-8 h-4 rounded-full relative transition-colors ${bet.autoBet ? 'bg-green-500' : 'bg-gray-600'}`}
                                                >
                                                    <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full shadow-sm transition-transform duration-200 ${bet.autoBet ? 'translate-x-4' : 'translate-x-0'}`} />
                                                </button>
                                            </div>

                                            {/* Auto Cashout Toggle & Input */}
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-2">
                                                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Auto Cash Out</span>
                                                    {bet.autoCashout && (
                                                        <div className="flex items-center bg-black/30 rounded px-1.5 py-0.5 border border-white/10">
                                                            <input 
                                                                type="number" 
                                                                step="0.01" 
                                                                min="1.01" 
                                                                value={bet.autoCashoutValue}
                                                                onChange={(e) => setBets(p => ({...p, [id]: {...p[id], autoCashoutValue: e.target.value}}))}
                                                                className="w-10 bg-transparent text-xs font-bold text-center text-white outline-none p-0" 
                                                            />
                                                            <span className="text-[10px] font-bold text-gray-500 ml-0.5">x</span>
                                                        </div>
                                                    )}
                                                </div>
                                                <button 
                                                    onClick={() => setBets(p => ({...p, [id]: {...p[id], autoCashout: !p[id].autoCashout}}))}
                                                    className={`w-8 h-4 rounded-full relative transition-colors ${bet.autoCashout ? 'bg-blue-500' : 'bg-gray-600'}`}
                                                >
                                                    <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full shadow-sm transition-transform duration-200 ${bet.autoCashout ? 'translate-x-4' : 'translate-x-0'}`} />
                                                </button>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>

                    {/* Live Bets Section */}
                    <div className="mt-4 bg-[#1A242D] rounded-t-2xl min-h-[300px] border-t border-gray-700">
                        <div className="flex border-b border-gray-700">
                            <div className="flex-1 py-3 text-center text-xs font-bold text-white border-b-2 border-red-500">All Bets ({activePlayerCount})</div>
                            <div className="flex-1 py-3 text-center text-xs font-bold text-gray-500">My Bets</div>
                            <div className="flex-1 py-3 text-center text-xs font-bold text-gray-500">Top</div>
                        </div>
                        <div className="flex justify-between px-4 py-2 text-[10px] font-bold text-gray-500 uppercase tracking-wider bg-black/10">
                            <span>User</span>
                            <div className="flex gap-6 pr-2"><span>Bet</span><span className="w-10 text-right">Cash Out</span></div>
                        </div>
                        <div className="px-2 pb-safe">
                            {fakeBets.map((bet) => {
                                const isLost = gameState === 'CRASHED' && !bet.cashedOut;
                                return (
                                    <div key={bet.id} className={`flex justify-between items-center px-3 py-1.5 border-b border-gray-800 last:border-0 ${bet.cashedOut ? 'bg-green-500/5' : isLost ? 'bg-red-500/5' : ''}`}>
                                        <div className="flex items-center gap-2">
                                            <div className={`size-6 rounded-full flex items-center justify-center text-[10px] font-bold ${bet.cashedOut ? 'bg-green-900 text-green-100' : isLost ? 'bg-red-900 text-red-100' : 'bg-gray-700 text-gray-300'}`}>{bet.name.charAt(0)}</div>
                                            <span className="text-xs text-gray-400 font-medium">{bet.name}</span>
                                        </div>
                                        <div className="flex items-center gap-6">
                                            <div className="flex flex-col items-end">
                                                <span className="text-xs font-mono font-bold text-white">₹{bet.amount}</span>
                                                {/* Added Status Tag */}
                                                {bet.cashedOut ? (
                                                    <span className="text-[8px] font-bold text-green-500 bg-green-500/10 px-1 rounded uppercase">Win</span>
                                                ) : isLost ? (
                                                    <span className="text-[8px] font-bold text-red-500 bg-red-500/10 px-1 rounded uppercase">Loss</span>
                                                ) : null}
                                            </div>
                                            <span className={`w-12 text-right text-xs font-mono font-bold ${bet.cashedOut ? 'text-green-500' : isLost ? 'text-red-500' : 'text-gray-600'}`}>{bet.cashedOut ? bet.cashedAt?.toFixed(2)+'x' : '-'}</span>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AviatorGame;
