import React, { useState, useEffect, useMemo, useRef } from 'react';
import { UserProfile, Transaction } from '../types';

interface MLMNetworkProps {
    user: UserProfile;
    onBack: () => void;
    onUpdateUser: (updatedUser: UserProfile) => void;
}

// Tree Data Structure
interface TreeNode {
    user: UserProfile;
    children: TreeNode[];
    totalSales: number; 
    teamSize: number;
    rank: string;
    isActive: boolean;
    level: number;
    // Added for logic
    leftCount?: number;
    rightCount?: number;
}

// Static 12 Month Data (Old Plan - kept for reference or fallback)
const DIAMOND_PLAN = [
    { month: 1, members: 2, income: 400 },
    { month: 2, members: 4, income: 800 },
    { month: 3, members: 8, income: 1600 },
    { month: 4, members: 16, income: 3200 },
    { month: 5, members: 32, income: 6400 },
    { month: 6, members: 64, income: 12800 },
    { month: 7, members: 128, income: 25600 },
    { month: 8, members: 256, income: 51200 },
    { month: 9, members: 512, income: 102400 },
    { month: 10, members: 1024, income: 204800 },
    { month: 11, members: 2048, income: 409600 },
    { month: 12, members: 4096, income: 819200 },
];

// NEW: Rank Growth Roadmap Data
const RANK_ROADMAP = [
    { id: 1, name: "Beginner", team: 2, role: "Direct Join", income: "₹80 – ₹200", gradient: "from-blue-400 to-blue-600", icon: "person" },
    { id: 2, name: "Bronze", team: 6, role: "Team Started", income: "₹300 – ₹500", gradient: "from-amber-600 to-orange-700", icon: "military_tech" },
    { id: 3, name: "Bronze Star", team: 14, role: "Network Growth", income: "₹800 – ₹1,200", gradient: "from-orange-500 to-red-500", icon: "stars" },
    { id: 4, name: "Silver", team: 30, role: "Leadership Start", income: "₹2,500 – ₹4,000", gradient: "from-slate-400 to-slate-600", icon: "verified" },
    { id: 5, name: "Silver Star", team: 62, role: "Team Management", income: "₹5,000 – ₹8,000", gradient: "from-slate-600 to-gray-700", icon: "admin_panel_settings" },
    { id: 6, name: "Gold", team: 126, role: "Mid-Level Network", income: "₹10,000 – ₹15,000", gradient: "from-yellow-400 to-yellow-600", icon: "monetization_on" },
    { id: 7, name: "Gold Star", team: 254, role: "Senior Leader", income: "₹25,000+", gradient: "from-yellow-600 to-amber-700", icon: "workspace_premium" },
    { id: 8, name: "Platinum", team: 510, role: "Large Team", income: "₹50,000+", gradient: "from-cyan-400 to-cyan-600", icon: "diamond" },
    { id: 9, name: "Diamond", team: 1022, role: "Key Leader", income: "₹1 Lakh+", gradient: "from-purple-500 to-purple-700", icon: "auto_awesome" },
    { id: 10, name: "Double Diamond", team: 2046, role: "State Level", income: "₹2.5 Lakh+", gradient: "from-teal-500 to-teal-700", icon: "domain" },
    { id: 11, name: "Crown", team: 4094, role: "Zonal Level", income: "₹5 Lakh+", gradient: "from-indigo-600 to-violet-800", icon: "crown" },
    { id: 12, name: "Ambassador", team: 8190, role: "National Level", income: "₹10 Lakh+", gradient: "from-rose-600 to-red-800", icon: "public" },
];

const MLMNetwork: React.FC<MLMNetworkProps> = ({ user, onBack, onUpdateUser }) => {
    // Tabs: Dashboard (Stats), Knowledge (Tree+Guide), Plan (Roadmap)
    const [activeTab, setActiveTab] = useState<'dashboard' | 'knowledge' | 'roadmap'>('dashboard');
    const [knowledgeSubTab, setKnowledgeSubTab] = useState<'tree' | 'guide'>('tree');
    
    const [users, setUsers] = useState<UserProfile[]>([]);
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [zoomLevel, setZoomLevel] = useState(0.8); // Start slightly zoomed out for better view
    const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
    
    // Modals & Sheets
    const [showAddMemberModal, setShowAddMemberModal] = useState(false);
    const [selectedParentId, setSelectedParentId] = useState<string | null>(null);
    const [selectedPosition, setSelectedPosition] = useState<'Left' | 'Right'>('Left');
    const [selectedNodeDetails, setSelectedNodeDetails] = useState<TreeNode | null>(null);

    // --- Data Loading ---
    useEffect(() => {
        const storedUsers = JSON.parse(localStorage.getItem('ncci_users') || '[]');
        const storedTrans = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
        setUsers(storedUsers);
        setTransactions(storedTrans);
        
        // Default expand root
        setExpandedNodes(new Set([user.identifier]));
    }, [user.identifier]);

    // --- Helper Logic (UNCHANGED) ---
    const getUserSales = (userId: string) => {
        return transactions
            .filter(t => t.userId === userId && t.type === 'Deposit' && (t.status === 'Approved' || t.status === 'Success'))
            .reduce((acc, t) => acc + t.amount, 0);
    };

    const getRank = (teamSize: number) => {
        if (teamSize >= 8190) return 'Ambassador';
        if (teamSize >= 4094) return 'Crown';
        if (teamSize >= 2046) return 'Double Diamond';
        if (teamSize >= 1022) return 'Diamond';
        if (teamSize >= 510) return 'Platinum';
        if (teamSize >= 254) return 'Gold Star';
        if (teamSize >= 126) return 'Gold';
        if (teamSize >= 62) return 'Silver Star';
        if (teamSize >= 30) return 'Silver';
        if (teamSize >= 14) return 'Bronze Star';
        if (teamSize >= 6) return 'Bronze';
        if (teamSize >= 2) return 'Beginner';
        return 'Member';
    };

    const buildTree = (rootUser: UserProfile, currentLevel: number = 1): TreeNode => {
        const directReferrals = users.filter(u => u.referredBy === rootUser.referralCode);
        const children = directReferrals.map(child => buildTree(child, currentLevel + 1));
        
        const personalSales = getUserSales(rootUser.identifier);
        const childrenSales = children.reduce((sum, child) => sum + child.totalSales, 0);
        const childrenTeam = children.reduce((sum, child) => sum + child.teamSize, 0);
        
        const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
        const isActive = (rootUser.lastActiveDeposit || 0) > thirtyDaysAgo;

        return {
            user: rootUser,
            children: children,
            totalSales: personalSales + childrenSales,
            teamSize: children.length + childrenTeam,
            rank: getRank(children.length + childrenTeam),
            isActive,
            level: currentLevel,
            leftCount: children[0] ? children[0].teamSize + 1 : 0,
            rightCount: children[1] ? children[1].teamSize + 1 : 0
        };
    };

    const treeData = useMemo(() => {
        const currentUserFull = users.find(u => u.identifier === user.identifier) || user;
        return buildTree(currentUserFull);
    }, [users, transactions, user.identifier]);

    // --- Handlers ---
    const toggleNode = (identifier: string) => {
        const newSet = new Set(expandedNodes);
        if (newSet.has(identifier)) { newSet.delete(identifier); } else { newSet.add(identifier); }
        setExpandedNodes(newSet);
    };

    const openNodeDetails = (node: TreeNode) => {
        setSelectedNodeDetails(node);
    };

    const openAddMember = (parentId: string, position: 'Left' | 'Right') => {
        setSelectedParentId(parentId);
        setSelectedPosition(position);
        setShowAddMemberModal(true);
    };

    const handleZoom = (delta: number) => {
        setZoomLevel(prev => Math.min(Math.max(0.4, prev + delta), 1.5));
    };

    const handleClaimAll = () => {
        if (!user.referralIncome || user.referralIncome <= 0) {
            alert("No referral income to claim.");
            return;
        }
        
        const amount = user.referralIncome;
        const updatedUser = {
            ...user,
            balance: user.balance + amount,
            referralIncome: 0
        };

        const trans: Transaction = {
            id: Math.random().toString(36).substr(2, 9),
            userId: user.identifier,
            userName: user.name,
            type: 'MLM_Claim',
            amount: amount,
            status: 'Success',
            timestamp: Date.now()
        };
        const existingTrans = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
        localStorage.setItem('ncci_transactions', JSON.stringify([...existingTrans, trans]));
        
        onUpdateUser(updatedUser);
        alert(`Successfully claimed ₹${amount} to Main Wallet!`);
    };

    const copyShareMessage = () => {
        const msg = `🚀 Join NCCI Game & Earn Daily Income!\n\n💰 *Income Types:*\n1. Game Winnings\n2. Direct Referral (20%)\n3. Team Level Income\n\n👉 *Join Now:*\nhttps://ncci.gov.in/register?ref=${user.referralCode}\n\nUse Code: *${user.referralCode}*`;
        navigator.clipboard.writeText(msg);
        alert("Referral Link & Message Copied!");
    };

    // --- Tree Components ---
    const TreeNodeComponent: React.FC<{ node: TreeNode }> = ({ node }) => {
        const isExpanded = expandedNodes.has(node.user.identifier);
        const hasChildren = node.children.length > 0;
        const leftChild = node.children[0];
        const rightChild = node.children[1];
        const extraChildren = node.children.slice(2);
        
        // M3 Card Styling
        const rankColors: Record<string, string> = {
            'Ambassador': 'from-yellow-400 to-amber-600',
            'Diamond': 'from-purple-500 to-indigo-600',
            'Gold': 'from-amber-300 to-yellow-500',
            'Silver': 'from-slate-300 to-slate-400',
            'Bronze': 'from-orange-300 to-orange-500',
            'Member': 'from-blue-400 to-blue-600'
        };
        const bgGradient = rankColors[node.rank] || rankColors['Member'];

        return (
            <div className="flex flex-col items-center">
                {/* Node Card */}
                <div 
                    className={`relative w-48 transition-all duration-300 transform hover:-translate-y-1 hover:z-20 group`}
                    onClick={(e) => { e.stopPropagation(); openNodeDetails(node); }}
                >
                    {/* Connection Line Up */}
                    <div className="absolute -top-4 left-1/2 w-0.5 h-4 bg-gray-300 -translate-x-1/2"></div>

                    <div className={`relative bg-white rounded-2xl p-0.5 shadow-[0_4px_20px_-5px_rgba(0,0,0,0.1)] hover:shadow-[0_8px_30px_-5px_rgba(0,0,0,0.2)] transition-shadow overflow-hidden border ${node.isActive ? 'border-green-200' : 'border-gray-100'}`}>
                        {/* Header Gradient */}
                        <div className={`h-12 bg-gradient-to-r ${bgGradient} p-2 flex justify-between items-start`}>
                            <span className="text-[9px] font-black uppercase text-white tracking-widest bg-black/20 px-1.5 py-0.5 rounded backdrop-blur-sm">{node.rank}</span>
                            <div className={`size-2.5 rounded-full border-2 border-white shadow-sm ${node.isActive ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`}></div>
                        </div>
                        
                        {/* Profile Image Float */}
                        <div className="absolute top-6 left-1/2 -translate-x-1/2">
                            <div className="size-12 rounded-full border-4 border-white bg-gray-100 shadow-md flex items-center justify-center overflow-hidden text-lg font-bold text-gray-500">
                                {node.user.profileImage ? <img src={node.user.profileImage} className="w-full h-full object-cover" alt="" /> : node.user.name.charAt(0)}
                            </div>
                        </div>

                        {/* Content */}
                        <div className="pt-8 pb-3 px-3 text-center">
                            <h4 className="text-xs font-bold text-gray-900 truncate mt-1">{node.user.name}</h4>
                            <p className="text-[9px] text-gray-400 font-mono mb-2 truncate">{node.user.identifier}</p>
                            
                            <div className="flex justify-between items-center bg-gray-50 rounded-lg p-1.5 border border-gray-100">
                                <div>
                                    <p className="text-[8px] text-gray-400 uppercase font-bold">Team</p>
                                    <p className="text-xs font-black text-gray-700">{node.teamSize}</p>
                                </div>
                                <div className="w-px h-6 bg-gray-200"></div>
                                <div>
                                    <p className="text-[8px] text-gray-400 uppercase font-bold">Earned</p>
                                    <p className="text-xs font-black text-green-600">₹{Math.floor(node.totalSales * 0.05)}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Expand/Collapse Button */}
                    {hasChildren && (
                        <button 
                            onClick={(e) => { e.stopPropagation(); toggleNode(node.user.identifier); }}
                            className="absolute -bottom-3 left-1/2 -translate-x-1/2 z-10 bg-white hover:bg-blue-50 text-gray-500 hover:text-blue-600 rounded-full border border-gray-200 shadow-sm size-6 flex items-center justify-center transition-colors"
                        >
                            <span className="material-symbols-outlined text-sm">{isExpanded ? 'remove' : 'add'}</span>
                        </button>
                    )}
                </div>

                {/* Children Render */}
                {isExpanded && (
                    <div className="flex flex-col items-center mt-8 relative animate-fade-in">
                        {/* Vertical connector from parent to horizontal bar */}
                        <div className="w-0.5 h-4 bg-gray-300 absolute -top-8 left-1/2 -translate-x-1/2"></div>
                        
                        <div className="flex justify-center gap-6 relative pt-4">
                            {/* Horizontal bar connecting children */}
                            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[calc(100%-10rem)] h-px bg-gray-300 hidden sm:block opacity-0"></div> 

                            {/* Left Branch */}
                            <div className="flex flex-col items-center relative p-2">
                                {/* Tag for Position */}
                                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white text-gray-400 text-[8px] font-bold px-1.5 rounded border border-gray-200 z-10">L</div>
                                
                                {leftChild ? (
                                    <TreeNodeComponent node={leftChild} />
                                ) : (
                                    <button onClick={() => openAddMember(node.user.referralCode, 'Left')} className="w-48 h-32 border-2 border-dashed border-gray-300 rounded-2xl flex flex-col items-center justify-center text-gray-400 hover:border-blue-400 hover:text-blue-500 hover:bg-blue-50 transition-all gap-2 bg-white/50 group">
                                        <div className="size-10 rounded-full bg-gray-100 group-hover:bg-blue-100 flex items-center justify-center transition-colors">
                                            <span className="material-symbols-outlined text-xl">add</span>
                                        </div>
                                        <span className="text-[10px] font-bold uppercase tracking-wider">Add Left</span>
                                    </button>
                                )}
                            </div>

                            {/* Right Branch */}
                            <div className="flex flex-col items-center relative p-2">
                                {/* Tag for Position */}
                                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white text-gray-400 text-[8px] font-bold px-1.5 rounded border border-gray-200 z-10">R</div>

                                {rightChild ? (
                                    <TreeNodeComponent node={rightChild} />
                                ) : (
                                    <button onClick={() => openAddMember(node.user.referralCode, 'Right')} className="w-48 h-32 border-2 border-dashed border-gray-300 rounded-2xl flex flex-col items-center justify-center text-gray-400 hover:border-blue-400 hover:text-blue-500 hover:bg-blue-50 transition-all gap-2 bg-white/50 group">
                                        <div className="size-10 rounded-full bg-gray-100 group-hover:bg-blue-100 flex items-center justify-center transition-colors">
                                            <span className="material-symbols-outlined text-xl">add</span>
                                        </div>
                                        <span className="text-[10px] font-bold uppercase tracking-wider">Add Right</span>
                                    </button>
                                )}
                            </div>
                        </div>

                        {/* Extra Children (if any logic allows more than 2) */}
                        {extraChildren.length > 0 && (
                            <div className="mt-8 pt-4 border-t border-gray-200 w-full text-center relative">
                                <span className="text-[10px] uppercase font-bold text-gray-400 bg-gray-50 px-3 py-1 rounded-full absolute -top-3 left-1/2 -translate-x-1/2">Additional</span>
                                <div className="flex flex-wrap justify-center gap-6 mt-4">
                                    {extraChildren.map(child => (<TreeNodeComponent key={child.user.identifier} node={child} />))}
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="fixed inset-0 bg-gray-50 z-50 flex flex-col font-display overflow-hidden">
            
            {/* 1. Header (Premium Glass) */}
            <header className="bg-white/80 backdrop-blur-xl border-b border-gray-200 px-4 py-3 shadow-sm z-40 flex justify-between items-center sticky top-0">
                <div className="flex items-center gap-4">
                    <button 
                        onClick={onBack} 
                        className="size-10 rounded-full bg-white border border-gray-200 text-gray-600 flex items-center justify-center hover:bg-gray-50 hover:shadow-md transition-all active:scale-95"
                    >
                        <span className="material-symbols-outlined text-xl">arrow_back</span>
                    </button>
                    <div>
                        <h1 className="text-lg font-black text-gray-900 tracking-tight">MLM Dashboard</h1>
                        <div className="flex items-center gap-1.5">
                            <span className="size-2 rounded-full bg-green-500 animate-pulse"></span>
                            <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">Live Network</p>
                        </div>
                    </div>
                </div>
                
                {/* Knowledge Button - Activates Knowledge/Tree Tab */}
                <div className="flex items-center gap-2">
                    <button 
                        onClick={() => setActiveTab('knowledge')}
                        className={`px-3 py-1.5 rounded-full text-xs font-bold border shadow-sm flex items-center gap-1 active:scale-95 transition-transform ${activeTab === 'knowledge' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-indigo-50 text-indigo-600 border-indigo-100'}`}
                    >
                        <span className="material-symbols-outlined text-sm">menu_book</span>
                        Knowledge
                    </button>
                    <div className="bg-blue-50 text-blue-700 px-3 py-1.5 rounded-full text-xs font-bold border border-blue-100 shadow-sm flex items-center gap-1">
                        <span className="material-symbols-outlined text-sm">stars</span>
                        {treeData.rank}
                    </div>
                </div>
            </header>

            {/* 2. Main Content */}
            <main className="flex-1 overflow-hidden relative bg-gray-50">
                
                {/* DASHBOARD TAB */}
                {activeTab === 'dashboard' && (
                    <div className="h-full overflow-y-auto no-scrollbar p-5 pb-32 space-y-6 max-w-lg mx-auto animate-slide-up">
                        
                        {/* Hero Stats Card with 3D Effect */}
                        <div className="relative group perspective-1000">
                            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-[2rem] blur-xl opacity-40 group-hover:opacity-60 transition-opacity"></div>
                            <div className="relative bg-gradient-to-br from-blue-600 to-indigo-800 rounded-[2rem] p-6 text-white shadow-2xl transition-transform duration-500 group-hover:rotate-x-2 border border-white/10 overflow-hidden">
                                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
                                
                                <div className="relative z-10">
                                    <div className="flex justify-between items-start mb-6">
                                        <div>
                                            <p className="text-blue-200 text-xs font-bold uppercase tracking-widest mb-1">Total Team Earnings</p>
                                            <h2 className="text-4xl font-black tracking-tight">₹{Math.floor(treeData.totalSales * 0.05).toLocaleString()}</h2>
                                        </div>
                                        <div className="bg-white/20 backdrop-blur-md p-2 rounded-xl border border-white/20 shadow-inner">
                                            <span className="material-symbols-outlined text-2xl">account_balance_wallet</span>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="bg-black/20 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                                            <p className="text-[10px] text-blue-200 uppercase font-bold">Team Size</p>
                                            <p className="text-xl font-bold">{treeData.teamSize.toLocaleString()}</p>
                                        </div>
                                        <div className="bg-black/20 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                                            <p className="text-[10px] text-blue-200 uppercase font-bold">Active Members</p>
                                            <p className="text-xl font-bold flex items-center gap-1">
                                                {treeData.children.filter(c => c.isActive).length} 
                                                <span className="text-[10px] bg-green-500 text-white px-1.5 rounded-full">Live</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* NEW: 3D Animated Rank Growth Button */}
                        <button 
                            onClick={() => setActiveTab('roadmap')}
                            className="w-full relative group perspective-1000 overflow-visible"
                        >
                            <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-[1.5rem] blur opacity-40 group-hover:opacity-60 transition-opacity animate-pulse"></div>
                            <div className="relative bg-gradient-to-r from-yellow-300 to-amber-500 p-5 rounded-[1.5rem] shadow-xl text-white flex items-center justify-between border border-white/20 group-hover:-translate-y-1 transition-transform duration-300">
                                <div className="flex items-center gap-4">
                                    <div className="size-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm border border-white/30 shadow-inner">
                                        <span className="material-symbols-outlined text-3xl drop-shadow-md">emoji_events</span>
                                    </div>
                                    <div className="text-left">
                                        <h3 className="text-lg font-black tracking-tight drop-shadow-sm">Rank Growth Plan</h3>
                                        <p className="text-[10px] font-bold uppercase tracking-widest opacity-90">View Income Roadmap</p>
                                    </div>
                                </div>
                                <div className="bg-white/20 p-2 rounded-full backdrop-blur-sm">
                                    <span className="material-symbols-outlined text-white">arrow_forward</span>
                                </div>
                            </div>
                        </button>

                        {/* Button to Open Knowledge Tree */}
                        <button 
                            onClick={() => setActiveTab('knowledge')}
                            className="w-full bg-white border border-indigo-100 rounded-[1.5rem] p-4 flex items-center justify-between shadow-sm group active:scale-95 transition-all"
                        >
                            <div className="flex items-center gap-3">
                                <div className="size-10 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center">
                                    <span className="material-symbols-outlined">hub</span>
                                </div>
                                <div className="text-left">
                                    <h3 className="font-bold text-gray-800 text-sm">Team Visualization</h3>
                                    <p className="text-[10px] text-gray-500">View & Track your Network Tree</p>
                                </div>
                            </div>
                            <span className="material-symbols-outlined text-gray-400 group-hover:text-indigo-600 transition-colors">arrow_forward_ios</span>
                        </button>

                        {/* Actions Grid */}
                        <div className="grid grid-cols-2 gap-4">
                            <button 
                                onClick={handleClaimAll}
                                className={`p-5 rounded-[1.5rem] shadow-sm border transition-all active:scale-95 text-left relative overflow-hidden group ${user.referralIncome > 0 ? 'bg-white border-purple-100 hover:border-purple-300 hover:shadow-purple-100' : 'bg-gray-100 border-transparent opacity-80'}`}
                            >
                                <div className="size-10 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform shadow-inner">
                                    <span className="material-symbols-outlined">payments</span>
                                </div>
                                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Unclaimed</p>
                                <h3 className="text-xl font-black text-gray-800">₹{user.referralIncome || 0}</h3>
                                {user.referralIncome > 0 && <div className="absolute bottom-0 left-0 w-full h-1 bg-purple-500"></div>}
                            </button>

                            <button 
                                onClick={copyShareMessage}
                                className="p-5 rounded-[1.5rem] bg-white shadow-sm border border-blue-100 hover:border-blue-300 hover:shadow-blue-100 transition-all active:scale-95 text-left relative overflow-hidden group"
                            >
                                <div className="size-10 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform shadow-inner">
                                    <span className="material-symbols-outlined">share</span>
                                </div>
                                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Invite</p>
                                <h3 className="text-xl font-black text-gray-800">Share Link</h3>
                                <div className="absolute bottom-0 left-0 w-full h-1 bg-blue-500"></div>
                            </button>
                        </div>
                    </div>
                )}

                {/* KNOWLEDGE TAB (TREE VISUALIZATION + TRACKING) */}
                {activeTab === 'knowledge' && (
                    <div className="h-full flex flex-col relative animate-fade-in bg-slate-50">
                        {/* 1. Tracking Stats Header */}
                        <div className="bg-white/90 backdrop-blur-md p-4 shadow-sm border-b border-gray-200 z-20">
                            <div className="flex justify-between items-center mb-3">
                                <h2 className="text-sm font-black text-gray-800 flex items-center gap-2">
                                    <span className="material-symbols-outlined text-primary">monitoring</span> Team Tracking
                                </h2>
                                {/* View Toggle */}
                                <div className="bg-gray-100 p-1 rounded-lg flex">
                                    <button 
                                        onClick={() => setKnowledgeSubTab('tree')}
                                        className={`px-3 py-1 rounded-md text-[10px] font-bold transition-all ${knowledgeSubTab === 'tree' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'}`}
                                    >
                                        Network
                                    </button>
                                    <button 
                                        onClick={() => setKnowledgeSubTab('guide')}
                                        className={`px-3 py-1 rounded-md text-[10px] font-bold transition-all ${knowledgeSubTab === 'guide' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'}`}
                                    >
                                        Guide
                                    </button>
                                </div>
                            </div>
                            
                            {/* Stats Grid */}
                            <div className="grid grid-cols-4 gap-2">
                                <div className="bg-blue-50 p-2 rounded-xl border border-blue-100 text-center">
                                    <p className="text-[8px] font-bold uppercase text-blue-400">Total</p>
                                    <p className="text-sm font-black text-blue-700">{treeData.teamSize}</p>
                                </div>
                                <div className="bg-purple-50 p-2 rounded-xl border border-purple-100 text-center">
                                    <p className="text-[8px] font-bold uppercase text-purple-400">Directs</p>
                                    <p className="text-sm font-black text-purple-700">{treeData.children.length}</p>
                                </div>
                                <div className="bg-orange-50 p-2 rounded-xl border border-orange-100 text-center">
                                    <p className="text-[8px] font-bold uppercase text-orange-400">Left</p>
                                    <p className="text-sm font-black text-orange-700">{treeData.leftCount}</p>
                                </div>
                                <div className="bg-emerald-50 p-2 rounded-xl border border-emerald-100 text-center">
                                    <p className="text-[8px] font-bold uppercase text-emerald-400">Right</p>
                                    <p className="text-sm font-black text-emerald-700">{treeData.rightCount}</p>
                                </div>
                            </div>
                        </div>

                        {/* 2. Main Content Area */}
                        <div className="flex-1 overflow-hidden relative">
                            
                            {/* SUB-TAB: TREE VIEW */}
                            {knowledgeSubTab === 'tree' && (
                                <div className="h-full w-full overflow-auto cursor-grab active:cursor-grabbing p-10 flex justify-center items-start custom-scrollbar">
                                    {/* Zoom Controls Overlay */}
                                    <div className="absolute top-4 right-4 flex flex-col gap-2 z-10 pointer-events-none">
                                        <button onClick={() => handleZoom(0.1)} className="pointer-events-auto size-10 bg-white shadow-lg rounded-full flex items-center justify-center text-gray-600 hover:text-blue-600 active:scale-90 transition-transform">
                                            <span className="material-symbols-outlined">add</span>
                                        </button>
                                        <button onClick={() => handleZoom(-0.1)} className="pointer-events-auto size-10 bg-white shadow-lg rounded-full flex items-center justify-center text-gray-600 hover:text-blue-600 active:scale-90 transition-transform">
                                            <span className="material-symbols-outlined">remove</span>
                                        </button>
                                    </div>

                                    <div 
                                        className="origin-top transition-transform duration-300 ease-out min-w-max min-h-max pb-32"
                                        style={{ transform: `scale(${zoomLevel})` }}
                                    >
                                        <TreeNodeComponent node={treeData} />
                                    </div>
                                </div>
                            )}

                            {/* SUB-TAB: GUIDE VIEW (Text Content) */}
                            {knowledgeSubTab === 'guide' && (
                                <div className="h-full overflow-y-auto p-6 pb-32 max-w-lg mx-auto">
                                    {/* Section 1: Overview */}
                                    <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 mb-4">
                                        <h3 className="font-bold text-gray-800 flex items-center gap-2 mb-3">
                                            <span className="material-symbols-outlined text-indigo-500">hub</span> MLM System Overview
                                        </h3>
                                        <p className="text-sm text-gray-600 leading-relaxed">
                                            This is a <span className="font-bold text-gray-800">Binary MLM System</span>. Every user starts with two main branches: a <span className="font-bold text-blue-600">Left Team</span> and a <span className="font-bold text-blue-600">Right Team</span>. As new members join via referral links, the network automatically expands downwards.
                                        </p>
                                    </div>

                                    {/* Section 2: Team Network */}
                                    <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 mb-4">
                                        <h3 className="font-bold text-gray-800 flex items-center gap-2 mb-3">
                                            <span className="material-symbols-outlined text-green-500">group_work</span> My Team Network
                                        </h3>
                                        <p className="text-sm text-gray-600 leading-relaxed">
                                            Your "Network View" shows your entire downline. In the Tree View, you are the <span className="font-bold">Root</span> node. Every card represents a user. You can click the <span className="bg-gray-100 px-1 rounded border">+</span> icon to expand branches and view deeper levels.
                                        </p>
                                    </div>

                                    {/* Section 3: Left/Right Logic */}
                                    <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 mb-4">
                                        <h3 className="font-bold text-gray-800 flex items-center gap-2 mb-3">
                                            <span className="material-symbols-outlined text-orange-500">alt_route</span> Left & Right Logic
                                        </h3>
                                        <p className="text-sm text-gray-600 leading-relaxed mb-2">
                                            When you add a new member, you choose their position:
                                        </p>
                                        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-1">
                                            <li><span className="font-bold">Left Leg:</span> Member joins the first available spot on the left.</li>
                                            <li><span className="font-bold">Right Leg:</span> Member joins the first available spot on the right.</li>
                                        </ul>
                                    </div>

                                    {/* Section 5: Rules */}
                                    <div className="bg-red-50 rounded-2xl p-5 border border-red-100">
                                        <h3 className="font-bold text-red-800 flex items-center gap-2 mb-3">
                                            <span className="material-symbols-outlined">gpp_maybe</span> Important Rules
                                        </h3>
                                        <ul className="space-y-2 text-sm text-red-700">
                                            <li className="flex gap-2"><span className="material-symbols-outlined text-sm mt-0.5">check_circle</span> Knowledge page is for viewing structure & tracking.</li>
                                            <li className="flex gap-2"><span className="material-symbols-outlined text-sm mt-0.5">check_circle</span> Income/Commission is calculated automatically.</li>
                                            <li className="flex gap-2"><span className="material-symbols-outlined text-sm mt-0.5">check_circle</span> Once placed, a user cannot be moved.</li>
                                        </ul>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* NEW: ROADMAP / GROWTH PLAN PAGE */}
                {activeTab === 'roadmap' && (
                    <div className="h-full overflow-y-auto no-scrollbar p-5 pb-32 animate-slide-up bg-slate-50 relative">
                        {/* Page Header */}
                        <div className="text-center mb-8">
                            <div className="inline-flex size-16 rounded-full bg-gradient-to-tr from-yellow-400 to-orange-500 items-center justify-center shadow-lg mb-3 ring-4 ring-yellow-100">
                                <span className="material-symbols-outlined text-3xl text-white">emoji_events</span>
                            </div>
                            <h2 className="text-2xl font-black text-gray-900 tracking-tight">Income Roadmap</h2>
                            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Visualize Your Growth</p>
                        </div>

                        {/* Timeline */}
                        <div className="relative space-y-4 max-w-sm mx-auto">
                            {/* Connector Line */}
                            <div className="absolute left-8 top-4 bottom-4 w-1 bg-gray-200 rounded-full"></div>

                            {RANK_ROADMAP.map((rank, index) => {
                                const isAchieved = treeData.teamSize >= rank.team;
                                const isCurrent = isAchieved && (index === RANK_ROADMAP.length - 1 || treeData.teamSize < RANK_ROADMAP[index + 1].team);
                                
                                return (
                                    <div key={rank.id} className={`relative pl-20 transition-all duration-500 ${isCurrent ? 'scale-105 z-10' : 'opacity-80 grayscale-[0.5]'}`}>
                                        {/* Timeline Node */}
                                        <div className={`absolute left-5 top-1/2 -translate-y-1/2 size-7 rounded-full border-4 border-white shadow-md z-10 flex items-center justify-center transition-colors ${isAchieved ? 'bg-green-500' : 'bg-gray-300'}`}>
                                            {isAchieved && <span className="material-symbols-outlined text-[10px] text-white font-bold">check</span>}
                                        </div>

                                        {/* Card */}
                                        <div className={`rounded-2xl p-4 shadow-lg border border-white/50 relative overflow-hidden bg-white ${isCurrent ? 'ring-2 ring-primary ring-offset-2' : ''}`}>
                                            {isCurrent && (
                                                <div className="absolute top-0 right-0 bg-primary text-white text-[9px] font-bold px-2 py-1 rounded-bl-xl shadow-sm z-20 flex items-center gap-1">
                                                    <span className="material-symbols-outlined text-[10px] animate-pulse">my_location</span> YOU ARE HERE
                                                </div>
                                            )}
                                            
                                            {/* Background Gradient */}
                                            <div className={`absolute inset-0 bg-gradient-to-r ${rank.gradient} opacity-10`}></div>
                                            
                                            <div className="relative z-10 flex justify-between items-center">
                                                <div className="flex items-center gap-3">
                                                    <div className={`size-10 rounded-xl bg-gradient-to-br ${rank.gradient} flex items-center justify-center text-white shadow-md`}>
                                                        <span className="material-symbols-outlined text-lg">{rank.icon}</span>
                                                    </div>
                                                    <div>
                                                        <h3 className="font-black text-gray-800 text-sm">{rank.name}</h3>
                                                        <p className="text-[10px] text-gray-500 font-bold uppercase">{rank.role}</p>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between items-center">
                                                <div className="bg-gray-50 px-2 py-1 rounded-lg border border-gray-200">
                                                    <p className="text-[8px] text-gray-400 font-bold uppercase">Team Size</p>
                                                    <p className="text-xs font-black text-gray-800">{rank.team.toLocaleString()}</p>
                                                </div>
                                                <div className="text-right">
                                                    <p className="text-[8px] text-gray-400 font-bold uppercase">Est. Income</p>
                                                    <p className="text-sm font-black text-green-600">{rank.income}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>

                        {/* Explanation & Disclaimer */}
                        <div className="mt-10 bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                            <div className="flex items-start gap-3 mb-4">
                                <span className="material-symbols-outlined text-blue-500 text-2xl">tips_and_updates</span>
                                <div>
                                    <h4 className="font-bold text-gray-800 text-sm">Growth Insight</h4>
                                    <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                                        As your team grows, your Rank and potential income increase exponentially. This chart visualizes the power of consistency and team building.
                                    </p>
                                </div>
                            </div>
                            <div className="bg-yellow-50 border border-yellow-100 rounded-xl p-3 flex gap-2 items-start">
                                <span className="material-symbols-outlined text-yellow-600 text-sm mt-0.5">warning</span>
                                <p className="text-[10px] text-yellow-700 font-medium leading-relaxed">
                                    <span className="font-bold">Disclaimer:</span> Income figures are estimated based on active team performance and are not guaranteed. Actual earnings depend on real-time sales and commissions.
                                </p>
                            </div>
                        </div>
                    </div>
                )}

            </main>

            {/* 3. Bottom Navigation */}
            <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-xl border-t border-gray-200 pb-safe pt-2 px-6 shadow-[0_-10px_40px_rgba(0,0,0,0.05)] z-50">
                <div className="flex justify-between items-center max-w-md mx-auto relative h-16">
                    
                    {/* Dashboard Tab */}
                    <button onClick={() => setActiveTab('dashboard')} className={`flex flex-col items-center gap-1 transition-all w-16 ${activeTab === 'dashboard' ? 'text-blue-600 -translate-y-1' : 'text-gray-400 hover:text-gray-600'}`}>
                        <span className={`material-symbols-outlined text-2xl ${activeTab === 'dashboard' && 'font-filled'}`}>dashboard</span>
                        <span className="text-[10px] font-bold">Home</span>
                    </button>

                    {/* Floating Center Action Button */}
                    <div className="relative -top-6">
                        <button 
                            onClick={copyShareMessage}
                            className="size-16 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/40 flex items-center justify-center transform transition-transform active:scale-95 hover:scale-105 border-4 border-gray-50"
                        >
                            <span className="material-symbols-outlined text-3xl">add_link</span>
                        </button>
                        <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[10px] font-black text-blue-600 whitespace-nowrap bg-blue-50 px-2 py-0.5 rounded-full">GET ₹500</span>
                    </div>

                    {/* Knowledge/Tree Tab */}
                    <button onClick={() => setActiveTab('knowledge')} className={`flex flex-col items-center gap-1 transition-all w-16 ${activeTab === 'knowledge' ? 'text-blue-600 -translate-y-1' : 'text-gray-400 hover:text-gray-600'}`}>
                        <span className={`material-symbols-outlined text-2xl ${activeTab === 'knowledge' && 'font-filled'}`}>account_tree</span>
                        <span className="text-[10px] font-bold">Tree</span>
                    </button>

                    {/* Plan / Roadmap Tab */}
                    <button onClick={() => setActiveTab('roadmap')} className={`flex flex-col items-center gap-1 transition-all w-16 ${activeTab === 'roadmap' ? 'text-blue-600 -translate-y-1' : 'text-gray-400 hover:text-gray-600'}`}>
                        <span className={`material-symbols-outlined text-2xl ${activeTab === 'roadmap' && 'font-filled'}`}>map</span>
                        <span className="text-[10px] font-bold">Roadmap</span>
                    </button>
                </div>
            </div>

            {/* 4. Node Details Bottom Sheet (READ ONLY PROFILE PREVIEW) */}
            {selectedNodeDetails && (
                <div className="fixed inset-0 z-[60] flex items-end justify-center">
                    <div className="absolute inset-0 bg-black/40 backdrop-blur-sm animate-fade-in" onClick={() => setSelectedNodeDetails(null)}></div>
                    <div className="bg-white w-full max-w-md rounded-t-[2rem] p-6 shadow-2xl relative animate-slide-up z-10 max-h-[85vh] overflow-y-auto">
                        <div className="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mb-6"></div>
                        
                        {/* --- DIGITAL IDENTITY CARD FOR DOWNLINE --- */}
                        <div className="relative w-full rounded-[2rem] p-5 text-white shadow-xl overflow-hidden bg-black mb-6">
                            {/* Card Background */}
                            <div className="absolute inset-0 bg-[conic-gradient(at_top_right,_var(--tw-gradient-stops))] from-indigo-900 via-slate-900 to-black opacity-95"></div>
                            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-30 mix-blend-overlay"></div>
                            
                            <div className="relative z-10">
                                {/* Header */}
                                <div className="flex justify-between items-start mb-4 border-b border-white/10 pb-3">
                                    <div className="flex items-center gap-2">
                                        <span className="material-symbols-outlined text-xl text-yellow-400">badge</span>
                                        <h3 className="font-bold text-sm tracking-wide uppercase">Member Profile (View Only)</h3>
                                    </div>
                                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded border ${selectedNodeDetails.user.isCardVerified ? 'bg-green-500/20 border-green-500 text-green-400' : 'bg-red-500/20 border-red-500 text-red-400'}`}>
                                        {selectedNodeDetails.user.isCardVerified ? 'VERIFIED' : 'UNVERIFIED'}
                                    </span>
                                </div>

                                {/* Main Details */}
                                <div className="flex items-center gap-4 mb-4">
                                    <div className="size-16 rounded-xl bg-white/10 border-2 border-white/20 overflow-hidden flex items-center justify-center text-2xl font-bold text-white shadow-md">
                                        {selectedNodeDetails.user.profileImage ? (
                                            <img src={selectedNodeDetails.user.profileImage} alt="" className="w-full h-full object-cover" />
                                        ) : (
                                            selectedNodeDetails.user.name.charAt(0)
                                        )}
                                    </div>
                                    <div>
                                        <h2 className="text-xl font-bold text-white">{selectedNodeDetails.user.name}</h2>
                                        <p className="text-xs text-blue-200 font-mono">ID: {selectedNodeDetails.user.identifier}</p>
                                        <div className="flex gap-2 mt-1">
                                            <span className="text-[9px] bg-blue-600/30 text-blue-200 px-1.5 py-0.5 rounded border border-blue-500/30 uppercase">{selectedNodeDetails.rank}</span>
                                            <span className={`text-[9px] px-1.5 py-0.5 rounded border uppercase ${selectedNodeDetails.isActive ? 'bg-green-500/20 border-green-500/30 text-green-300' : 'bg-red-500/20 border-red-500/30 text-red-300'}`}>
                                                {selectedNodeDetails.isActive ? 'Active' : 'Inactive'}
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                {/* Full Info Grid (The requested feature) */}
                                <div className="grid grid-cols-2 gap-2 bg-white/5 rounded-xl p-3 border border-white/5">
                                    <div className="p-1.5 border-b border-r border-white/10">
                                        <p className="text-[8px] text-white/40 uppercase font-bold tracking-wider">Village</p>
                                        <p className="text-xs font-bold text-white truncate">{selectedNodeDetails.user.village}</p>
                                    </div>
                                    <div className="p-1.5 border-b border-white/10">
                                        <p className="text-[8px] text-white/40 uppercase font-bold tracking-wider">Block</p>
                                        <p className="text-xs font-bold text-white truncate">{selectedNodeDetails.user.block}</p>
                                    </div>
                                    <div className="p-1.5 border-r border-white/10">
                                        <p className="text-[8px] text-white/40 uppercase font-bold tracking-wider">District</p>
                                        <p className="text-xs font-bold text-white truncate">{selectedNodeDetails.user.district}</p>
                                    </div>
                                    <div className="p-1.5">
                                        <p className="text-[8px] text-white/40 uppercase font-bold tracking-wider">Joined</p>
                                        <p className="text-xs font-bold text-white truncate">{new Date(selectedNodeDetails.user.joinedAt).toLocaleDateString()}</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Stats Grid */}
                        <div className="grid grid-cols-2 gap-4 mb-6">
                            <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 text-center">
                                <p className="text-xs text-gray-400 font-bold uppercase mb-1">Total Team</p>
                                <p className="text-2xl font-black text-gray-800">{selectedNodeDetails.teamSize}</p>
                            </div>
                            <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 text-center">
                                <p className="text-xs text-gray-400 font-bold uppercase mb-1">Directs</p>
                                <p className="text-2xl font-black text-gray-800">{selectedNodeDetails.children.length}</p>
                            </div>
                            <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 text-center col-span-2">
                                <p className="text-xs text-gray-400 font-bold uppercase mb-1">Total Business Volume</p>
                                <p className="text-3xl font-black text-blue-600">₹{selectedNodeDetails.totalSales.toLocaleString()}</p>
                            </div>
                        </div>

                        <div className="space-y-3">
                            <button onClick={() => {openAddMember(selectedNodeDetails!.user.referralCode, 'Left'); setSelectedNodeDetails(null)}} className="w-full py-3.5 rounded-xl border border-gray-200 font-bold text-gray-600 hover:bg-gray-50 flex items-center justify-center gap-2">
                                <span className="material-symbols-outlined">add</span> Add Member to Left
                            </button>
                            <button onClick={() => {openAddMember(selectedNodeDetails!.user.referralCode, 'Right'); setSelectedNodeDetails(null)}} className="w-full py-3.5 rounded-xl border border-gray-200 font-bold text-gray-600 hover:bg-gray-50 flex items-center justify-center gap-2">
                                <span className="material-symbols-outlined">add</span> Add Member to Right
                            </button>
                            <button onClick={() => setSelectedNodeDetails(null)} className="w-full py-3.5 rounded-xl bg-gray-900 text-white font-bold shadow-lg mt-2">
                                Close Details
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Modal for Adding Members (Link Copy) */}
            {showAddMemberModal && (
                <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
                    <div className="bg-white w-full max-w-sm rounded-[2rem] p-6 shadow-2xl relative overflow-hidden animate-scale-up">
                        <button onClick={() => setShowAddMemberModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 bg-gray-50 p-2 rounded-full"><span className="material-symbols-outlined text-lg">close</span></button>
                        
                        <div className="text-center mb-6 mt-2">
                            <div className="size-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner ring-4 ring-blue-50/50">
                                <span className="material-symbols-outlined text-3xl">person_add</span>
                            </div>
                            <h3 className="text-xl font-black text-gray-900">Grow Your Team</h3>
                            <p className="text-sm text-gray-500 mt-1">Add member to <span className="font-bold text-blue-600">{selectedPosition} Leg</span></p>
                        </div>

                        <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 mb-6">
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Registration Link</p>
                            <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl p-3 shadow-sm">
                                <span className="text-xs text-gray-600 truncate flex-1 font-mono select-all">
                                    ncci.gov.in/reg?ref={selectedParentId}&pos={selectedPosition.charAt(0)}
                                </span>
                                <button 
                                    onClick={() => {
                                        navigator.clipboard.writeText(`https://ncci.gov.in/register?ref=${selectedParentId}&pos=${selectedPosition === 'Left' ? 'L' : 'R'}`); 
                                        alert("Link Copied!");
                                    }} 
                                    className="text-blue-600 hover:bg-blue-50 p-2 rounded-lg transition-colors"
                                >
                                    <span className="material-symbols-outlined text-lg">content_copy</span>
                                </button>
                            </div>
                        </div>

                        <button onClick={() => setShowAddMemberModal(false)} className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-blue-500/30 transition-transform active:scale-95">
                            Done
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default MLMNetwork;