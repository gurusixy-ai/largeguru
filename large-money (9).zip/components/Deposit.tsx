import React, { useState } from 'react';
import { UserProfile, Transaction } from '../types';

interface DepositProps {
    user: UserProfile;
    onBack: () => void;
}

const Deposit: React.FC<DepositProps> = ({ user, onBack }) => {
    const [amount, setAmount] = useState('');
    const [utr, setUtr] = useState('');
    
    // Config
    const adminUpi = localStorage.getItem('ncci_upi') || '8810572406@ptyes';
    const adminQr = localStorage.getItem('ncci_qr') || 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=8810572406@ptyes';

    // --- BONUS LOGIC CALCULATION ---
    const streakDay = user.depositStreak?.currentDay || 1;
    const isFirstTime = user.isFirstDeposit !== false; 
    
    // Calculate Bonus Percentage
    // Rule: First Deposit (Referred: 12%, Direct: 8%)
    // Rule: Subsequent -> Streak Day + 2 (Base 3%)
    const bonusPercent = isFirstTime 
        ? (user.referredBy ? 12 : 8)
        : Math.min(30, 2 + streakDay); // Day 1 = 3%, Day 2 = 4%
    
    // Check if entered amount is valid for bonus (Min 100)
    const currentAmount = Number(amount);
    const isEligibleForBonus = currentAmount >= 100;
    const bonusAmount = isEligibleForBonus ? Math.floor(currentAmount * (bonusPercent / 100)) : 0;
    const totalCredit = currentAmount + bonusAmount;

    const handleAppPayment = (app: 'gpay' | 'phonepe' | 'paytm' | 'any') => {
        if (!amount || Number(amount) < 50) {
            alert("Please enter a valid amount first (Min ₹50)");
            return;
        }

        const params = `pa=${adminUpi}&pn=NCCI Game&am=${amount}&cu=INR`;
        let url = `upi://pay?${params}`;

        if (app === 'gpay') url = `tez://upi/pay?${params}`;
        if (app === 'phonepe') url = `phonepe://pay?${params}`;
        if (app === 'paytm') url = `paytmmp://pay?${params}`;

        window.location.href = url;
    };

    const handleSubmit = () => {
        if (!amount || !utr) {
            alert("Please fill Amount and UTR.");
            return;
        }
        if (Number(amount) < 50) {
            alert("Minimum Deposit is ₹50");
            return;
        }

        const trans: Transaction = {
            id: Math.random().toString(36).substr(2, 9),
            userId: user.identifier,
            userName: user.name,
            type: 'Deposit',
            amount: Number(amount),
            bonusAmount: bonusAmount, // Attach Calculated Bonus
            appliedBonusDesc: isEligibleForBonus ? (isFirstTime ? 'First Deposit Bonus' : `Day ${streakDay} Streak Bonus`) : undefined,
            status: 'Pending',
            timestamp: Date.now(),
            utr: utr
        };

        const existing = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
        localStorage.setItem('ncci_transactions', JSON.stringify([...existing, trans]));

        alert(`Deposit Request Submitted! Bonus of ₹${bonusAmount} pending approval.`);
        onBack();
    };

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20 w-full">
            {/* Header with Gradient */}
            <header className="bg-gradient-to-r from-blue-600 to-indigo-700 p-4 pb-16 sticky top-0 z-50 shadow-lg">
                <div className="w-full flex items-center gap-3 text-white">
                    <button onClick={onBack} className="hover:bg-white/20 p-2 rounded-full transition-colors">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </button>
                    <h1 className="font-bold text-xl tracking-wide">Add Funds</h1>
                    <div className="ml-auto bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-medium border border-white/30 flex items-center gap-1">
                        <span className="material-symbols-outlined text-sm">lock</span> Secure
                    </div>
                </div>
            </header>

            <main className="w-full px-4 -mt-10 relative z-10 animate-fade-in space-y-6">
                
                {/* Admin QR Card - Enhanced */}
                <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-xl overflow-hidden">
                    <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 p-1">
                        <div className="bg-white dark:bg-gray-800 rounded-[22px] p-6 text-center">
                            <div className="inline-block p-3 rounded-full bg-blue-50 text-blue-600 mb-4">
                                <span className="material-symbols-outlined text-3xl">qr_code_scanner</span>
                            </div>
                            <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-1">Scan & Pay</h2>
                            <p className="text-sm text-gray-500 mb-6">Use any UPI App to deposit funds instantly</p>
                            
                            <div className="mx-auto w-60 h-60 bg-white p-3 rounded-2xl shadow-lg border border-gray-100 flex items-center justify-center relative group">
                                <img src={adminQr} alt="Admin QR" className="w-full h-full object-contain" />
                                <div className="absolute inset-0 bg-black/5 group-hover:bg-transparent transition-colors rounded-xl pointer-events-none" />
                            </div>

                            <div 
                                onClick={() => {navigator.clipboard.writeText(adminUpi); alert("UPI ID Copied")}}
                                className="mt-6 mx-auto max-w-xs bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-3 flex items-center justify-between cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-all active:scale-95 group"
                            >
                                <div className="flex flex-col items-start overflow-hidden text-left">
                                    <span className="text-[10px] uppercase text-gray-400 font-bold tracking-wider">Merchant UPI ID</span>
                                    <span className="text-sm font-bold text-gray-800 dark:text-white truncate w-full font-mono">{adminUpi}</span>
                                </div>
                                <span className="material-symbols-outlined text-primary group-hover:scale-110 transition-transform">content_copy</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Payment Form */}
                <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-lg p-6 space-y-6">
                    <div>
                        <div className="flex justify-between items-center mb-3">
                            <label className="flex items-center gap-2 text-sm font-bold text-gray-700 dark:text-gray-300">
                                <span className="material-symbols-outlined text-primary text-lg">payments</span>
                                Deposit Amount
                            </label>
                            {/* LIVE BONUS BADGE */}
                            <div className="bg-gradient-to-r from-orange-500 to-red-600 text-white px-2 py-1 rounded-lg text-[10px] font-bold animate-pulse shadow-md">
                                Today Bonus: {bonusPercent}%
                            </div>
                        </div>

                        <div className="relative group">
                            <span className="absolute left-5 top-1/2 -translate-y-1/2 text-2xl font-bold text-gray-400 group-focus-within:text-primary transition-colors">₹</span>
                            <input 
                                type="number" 
                                className="w-full bg-gray-50 dark:bg-gray-700 border-2 border-gray-100 dark:border-gray-600 rounded-2xl py-4 pl-10 pr-4 font-bold text-2xl outline-none focus:border-primary focus:bg-white dark:focus:bg-gray-800 transition-all" 
                                placeholder="500"
                                value={amount}
                                onChange={e => setAmount(e.target.value)}
                            />
                            {/* BONUS TOOLTIP */}
                            {currentAmount > 0 && (
                                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-right">
                                    <div className="text-[10px] text-gray-400 font-bold uppercase">You Get</div>
                                    <div className={`text-sm font-black ${isEligibleForBonus ? 'text-green-500' : 'text-gray-500'}`}>
                                        ₹{totalCredit}
                                    </div>
                                </div>
                            )}
                        </div>
                        
                        {!isEligibleForBonus && currentAmount > 0 && (
                            <p className="text-[10px] text-red-500 mt-1 ml-2 font-bold">* Min ₹100 required for {bonusPercent}% bonus</p>
                        )}
                        
                        {/* Preset Amounts */}
                        <div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar pb-1">
                            {[100, 500, 1000, 5000].map(amt => (
                                <button 
                                    key={amt}
                                    onClick={() => setAmount(String(amt))}
                                    className="flex-1 min-w-[70px] py-2 rounded-xl border border-gray-200 dark:border-gray-600 text-sm font-bold text-gray-600 dark:text-gray-300 hover:bg-primary hover:text-white hover:border-primary transition-colors"
                                >
                                    ₹{amt}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Quick Pay Grid */}
                    <div>
                        <label className="text-xs font-bold text-gray-400 uppercase mb-3 block tracking-wider">Pay via App</label>
                        <div className="grid grid-cols-2 gap-3">
                            <button 
                                onClick={() => handleAppPayment('gpay')}
                                className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 bg-white shadow-sm hover:shadow-md hover:border-blue-200 transition-all group"
                            >
                                <div className="size-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
                                    <span className="font-bold text-lg">G</span>
                                </div>
                                <span className="font-bold text-gray-700">Google Pay</span>
                            </button>
                            <button 
                                onClick={() => handleAppPayment('phonepe')}
                                className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 bg-white shadow-sm hover:shadow-md hover:border-purple-200 transition-all group"
                            >
                                <div className="size-10 rounded-full bg-purple-50 flex items-center justify-center text-purple-600 group-hover:scale-110 transition-transform">
                                    <span className="font-bold text-lg">Pe</span>
                                </div>
                                <span className="font-bold text-gray-700">PhonePe</span>
                            </button>
                            <button 
                                onClick={() => handleAppPayment('paytm')}
                                className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 bg-white shadow-sm hover:shadow-md hover:border-cyan-200 transition-all group"
                            >
                                <div className="size-10 rounded-full bg-cyan-50 flex items-center justify-center text-cyan-600 group-hover:scale-110 transition-transform">
                                    <span className="font-bold text-lg">P</span>
                                </div>
                                <span className="font-bold text-gray-700">Paytm</span>
                            </button>
                             <button 
                                onClick={() => handleAppPayment('any')}
                                className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 bg-white shadow-sm hover:shadow-md hover:border-orange-200 transition-all group"
                            >
                                <div className="size-10 rounded-full bg-orange-50 flex items-center justify-center text-orange-600 group-hover:scale-110 transition-transform">
                                    <span className="material-symbols-outlined">api</span>
                                </div>
                                <span className="font-bold text-gray-700">Other UPI</span>
                            </button>
                        </div>
                    </div>

                    {/* UTR Section */}
                    <div className="bg-yellow-50 dark:bg-yellow-900/10 rounded-2xl p-4 border border-yellow-100 dark:border-yellow-900/30">
                        <label className="block text-xs font-bold text-yellow-700 dark:text-yellow-500 uppercase mb-2">UTR / Reference No. (Required)</label>
                        <input 
                            type="text" 
                            className="w-full bg-white dark:bg-gray-700 border border-yellow-200 dark:border-yellow-800 rounded-xl p-3 font-mono text-sm outline-none focus:ring-2 focus:ring-yellow-400 transition-all placeholder:text-gray-300" 
                            placeholder="Enter 12-digit UTR"
                            value={utr}
                            onChange={e => setUtr(e.target.value)}
                        />
                        <p className="text-[10px] text-yellow-600 mt-2 flex items-center gap-1">
                            <span className="material-symbols-outlined text-xs">info</span>
                            Must enter correct UTR for verification.
                        </p>
                    </div>

                    <button 
                        onClick={handleSubmit} 
                        className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold py-4 rounded-2xl shadow-lg shadow-green-500/30 transition-transform active:scale-95 flex items-center justify-center gap-2 text-lg"
                    >
                        <span className="material-symbols-outlined">check_circle</span>
                        Submit Deposit
                    </button>
                </div>
            </main>
        </div>
    );
};

export default Deposit;