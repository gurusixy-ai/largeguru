import React, { useState, useEffect, useRef } from 'react';
import { UserProfile } from '../types';

interface SupportChatProps {
    user: UserProfile;
    onBack?: () => void; // Optional back button for page mode
}

const SupportChat: React.FC<SupportChatProps> = ({ user, onBack }) => {
    const [message, setMessage] = useState('');
    const [chatHistory, setChatHistory] = useState<any[]>([]);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const loadChat = () => {
            const stored = JSON.parse(localStorage.getItem(`ncci_chat_${user.identifier}`) || '[]');
            setChatHistory(stored);
        };

        // Initial Load
        loadChat();

        // Poll for new messages from Admin
        const interval = setInterval(loadChat, 2000);
        return () => clearInterval(interval);
    }, [user.identifier]);

    useEffect(() => {
        scrollToBottom();
    }, [chatHistory]);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    const sendMessage = () => {
        if (!message.trim()) return;
        
        // Read fresh data to prevent overwriting
        const currentMsgs = JSON.parse(localStorage.getItem(`ncci_chat_${user.identifier}`) || '[]');
        
        const newMsg = {
            id: Date.now(),
            text: message,
            sender: 'User',
            timestamp: Date.now()
        };
        
        const updated = [...currentMsgs, newMsg];
        localStorage.setItem(`ncci_chat_${user.identifier}`, JSON.stringify(updated));
        setChatHistory(updated);
        setMessage('');
    };

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = reader.result as string;
            
            // Read fresh data
            const currentMsgs = JSON.parse(localStorage.getItem(`ncci_chat_${user.identifier}`) || '[]');
            
            const newMsg = {
                id: Date.now(),
                text: 'Shared an image',
                image: base64String,
                sender: 'User',
                timestamp: Date.now()
            };
            
            const updated = [...currentMsgs, newMsg];
            localStorage.setItem(`ncci_chat_${user.identifier}`, JSON.stringify(updated));
            setChatHistory(updated);
        };
        reader.readAsDataURL(file);
    };

    return (
        // Changed to fixed inset-0 z-[60] to overlay the bottom navigation bar (which is z-50)
        // This ensures the chat input is visible and accessible.
        <div className="fixed inset-0 z-[60] flex flex-col bg-gray-50 dark:bg-gray-900 animate-fade-in">
            <header className="bg-primary p-4 flex items-center gap-3 text-white shadow-md z-10 sticky top-0">
                {onBack && (
                    <button onClick={onBack} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </button>
                )}
                <div className="flex items-center gap-3 flex-1">
                    <div className="size-10 rounded-full bg-white/20 flex items-center justify-center border border-white/30">
                        <span className="material-symbols-outlined">support_agent</span>
                    </div>
                    <div>
                        <h1 className="font-bold leading-none text-lg">NCCI Support</h1>
                        <span className="text-xs opacity-80 flex items-center gap-1">
                            <span className="size-2 bg-green-400 rounded-full animate-pulse"></span> Online
                        </span>
                    </div>
                </div>
            </header>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar bg-gray-100 dark:bg-gray-800">
                {chatHistory.length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full text-gray-400 text-sm opacity-60">
                        <div className="size-20 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center mb-3">
                            <span className="material-symbols-outlined text-4xl">chat</span>
                        </div>
                        <p>Start a conversation with Support Admin.</p>
                    </div>
                )}
                
                {/* Date Separator Example (Optional enhancement for visuals) */}
                <div className="text-center text-[10px] text-gray-400 uppercase tracking-widest my-2">Today</div>

                {chatHistory.map((msg: any) => (
                    <div key={msg.id} className={`flex ${msg.sender === 'User' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] rounded-2xl p-3 text-sm shadow-md relative ${
                            msg.sender === 'User' 
                                ? 'bg-gradient-to-br from-primary to-indigo-600 text-white rounded-br-none' 
                                : 'bg-white dark:bg-gray-700 dark:text-white text-gray-800 border border-gray-200 dark:border-gray-600 rounded-bl-none'
                        }`}>
                            {msg.image ? (
                                <div>
                                    <img src={msg.image} alt="Attachment" className="rounded-lg max-w-full mb-1 border border-white/20" />
                                    {msg.text !== 'Shared an image' && <span className="opacity-90 text-xs block mt-1">{msg.text}</span>}
                                </div>
                            ) : (
                                msg.text
                            )}
                            <div className={`text-[9px] mt-1 text-right font-medium ${msg.sender === 'User' ? 'text-white/70' : 'text-gray-400'}`}>
                                {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </div>
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </div>

            {/* Input Area - Now strictly at bottom of this fixed container */}
            <div className="p-3 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 flex gap-2 items-center safe-area-bottom">
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleFileUpload} 
                />
                <button 
                    onClick={() => fileInputRef.current?.click()} 
                    className="size-10 flex items-center justify-center text-gray-500 hover:text-primary transition-colors rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                    <span className="material-symbols-outlined text-2xl">add_photo_alternate</span>
                </button>
                
                <div className="flex-1 relative">
                    <input 
                        type="text" 
                        className="w-full bg-gray-100 dark:bg-gray-800 border-none rounded-full pl-5 pr-10 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/50 transition-all font-medium text-gray-800 dark:text-white"
                        placeholder="Type a message..."
                        value={message}
                        onChange={e => setMessage(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && sendMessage()}
                    />
                    <button className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-1">
                        <span className="material-symbols-outlined text-lg">sentiment_satisfied</span>
                    </button>
                </div>
                
                <button 
                    onClick={sendMessage} 
                    disabled={!message.trim()}
                    className={`size-12 rounded-full flex items-center justify-center shadow-lg transition-all active:scale-95 ${message.trim() ? 'bg-primary text-white hover:bg-primary-dark cursor-pointer' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}
                >
                    <span className="material-symbols-outlined text-xl">send</span>
                </button>
            </div>
        </div>
    );
};

export default SupportChat;