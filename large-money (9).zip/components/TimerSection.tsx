import React from 'react';

interface TimerSectionProps {
    periodId: string;
    timeLeft: number; // in seconds
}

const TimerSection: React.FC<TimerSectionProps> = ({ periodId, timeLeft }) => {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    
    // Split digits for animation/display
    const m1 = Math.floor(minutes / 10);
    const m2 = minutes % 10;
    const s1 = Math.floor(seconds / 10);
    const s2 = seconds % 10;

    return (
        <div className="relative overflow-hidden rounded-[2rem] p-8 text-white shadow-[0_20px_40px_-10px_rgba(63,81,181,0.5)] bg-gradient-to-br from-[#304ffe] via-[#4f46e5] to-[#7c4dff] border border-white/20">
            {/* Decorative Background Elements */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/4 blur-3xl mix-blend-overlay"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-black/20 rounded-full translate-y-1/2 -translate-x-1/4 blur-2xl mix-blend-overlay"></div>
            
            {/* Grid Pattern */}
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>

            <div className="flex flex-col md:flex-row justify-between items-center gap-8 relative z-10">
                {/* Period Info */}
                <div className="flex flex-col gap-2 text-center md:text-left w-full md:w-auto">
                    <div className="flex items-center gap-2 justify-center md:justify-start bg-black/20 w-fit mx-auto md:mx-0 px-3 py-1 rounded-lg backdrop-blur-sm border border-white/10">
                        <span className="material-symbols-outlined text-[18px] text-yellow-300">tag</span>
                        <span className="text-xs font-bold uppercase tracking-widest text-white/90">Current Period</span>
                    </div>
                    <div className="text-5xl font-black tracking-tighter font-mono text-transparent bg-clip-text bg-gradient-to-b from-white to-blue-100 drop-shadow-sm mt-1">
                        {periodId}
                    </div>
                    <div className="mt-2 inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-xl text-xs font-bold w-fit mx-auto md:mx-0 border border-white/20 shadow-lg group cursor-default hover:bg-white/20 transition-colors">
                        <span className="material-symbols-outlined text-[18px] text-green-400 group-hover:scale-110 transition-transform">verified_user</span>
                        <span>Fairness Verified</span>
                    </div>
                </div>
                
                {/* Timer Display */}
                <div className="flex flex-col items-center gap-4 bg-white/5 p-4 rounded-3xl border border-white/10 backdrop-blur-sm">
                    <span className="text-xs font-bold text-blue-100 uppercase tracking-[0.3em]">Time Remaining</span>
                    <div className="flex gap-3 items-center">
                        {/* Minute Cards */}
                        <div className="flex gap-1.5">
                            <DigitCard digit={m1} />
                            <DigitCard digit={m2} />
                        </div>
                        
                        {/* Separator */}
                        <div className="flex flex-col gap-3 justify-center h-20 px-1">
                            <div className="w-2 h-2 bg-white rounded-full shadow-[0_0_10px_white]"></div>
                            <div className="w-2 h-2 bg-white rounded-full shadow-[0_0_10px_white]"></div>
                        </div>

                        {/* Second Cards - Highlighted */}
                        <div className="flex gap-1.5">
                            <DigitCard digit={s1} active />
                            <DigitCard digit={s2} active />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const DigitCard = ({ digit, active = false }: { digit: number, active?: boolean }) => (
    <div className={`relative w-14 h-20 md:w-16 md:h-24 rounded-xl flex items-center justify-center text-4xl md:text-5xl font-black font-mono shadow-xl overflow-hidden
        ${active 
            ? 'bg-white text-[#304ffe] transform scale-105' 
            : 'bg-[#1a237e]/50 text-white border border-white/10'
        }`}>
        {/* Glossy Reflection */}
        <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent"></div>
        <span className="relative z-10 drop-shadow-md">{digit}</span>
        {active && <div className="absolute inset-0 bg-white/50 blur-xl opacity-20 animate-pulse"></div>}
    </div>
);

export default TimerSection;