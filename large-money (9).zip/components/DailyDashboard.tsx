import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, UserBet, Transaction } from '../types';

interface DailyDashboardProps {
    user: UserProfile;
    bets: UserBet[];
    onBack: () => void;
    onUpdateUser: (updatedUser: UserProfile) => void;
}

// 12 VIP LEVELS CONFIGURATION (Fixed Rules)
const VIP_LEVELS = [
    { 
        id: 1, name: 'VIP 1', exp: 3000, levelReward: 60, monthly: 30, rebate: 0.05, 
        gradient: 'from-blue-500 to-indigo-600', icon: 'military_tech', badge: 'Member' 
    },
    { 
        id: 2, name: 'VIP 2', exp: 30000, levelReward: 180, monthly: 90, rebate: 0.10, 
        gradient: 'from-cyan-500 to-blue-600', icon: 'workspace_premium', badge: 'Elite' 
    },
    { 
        id: 3, name: 'VIP 3', exp: 400000, levelReward: 690, monthly: 290, rebate: 0.15, 
        gradient: 'from-teal-500 to-emerald-600', icon: 'verified', badge: 'Pro' 
    },
    { 
        id: 4, name: 'VIP 4', exp: 4000000, levelReward: 1690, monthly: 690, rebate: 0.20, 
        gradient: 'from-green-500 to-emerald-700', icon: 'local_police', badge: 'Master' 
    },
    { 
        id: 5, name: 'VIP 5', exp: 20000000, levelReward: 6900, monthly: 1690, rebate: 0.25, 
        gradient: 'from-yellow-500 to-orange-600', icon: 'stars', badge: 'Grand' 
    },
    { 
        id: 6, name: 'VIP 6', exp: 80000000, levelReward: 16900, monthly: 6900, rebate: 0.30, 
        gradient: 'from-orange-500 to-red-600', icon: 'hotel_class', badge: 'Epic' 
    },
    { 
        id: 7, name: 'VIP 7', exp: 300000000, levelReward: 69000, monthly: 16900, rebate: 0.35, 
        gradient: 'from-red-600 to-rose-700', icon: 'diamond', badge: 'Legend' 
    },
    { 
        id: 8, name: 'VIP 8', exp: 1000000000, levelReward: 169000, monthly: 69000, rebate: 0.40, 
        gradient: 'from-purple-600 to-fuchsia-700', icon: 'approval_delegation', badge: 'Mythic' 
    },
    { 
        id: 9, name: 'VIP 9', exp: 5000000000, levelReward: 690000, monthly: 169000, rebate: 0.45, 
        gradient: 'from-violet-600 to-purple-900', icon: 'diversity_3', badge: 'Supreme' 
    },
    { 
        id: 10, name: 'VIP 10', exp: 10000000000, levelReward: 1690000, monthly: 690000, rebate: 0.50, 
        gradient: 'from-gray-800 to-black', icon: 'crown', badge: 'Ultimate' 
    },
    { 
        id: 11, name: 'VIP 10 GOLD', exp: 25000000000, levelReward: 0, monthly: 690000, rebate: 0.50, 
        gradient: 'from-yellow-300 via-amber-400 to-yellow-600', icon: 'solar_power', badge: 'Prestige', darkText: true 
    },
    { 
        id: 12, name: 'VIP 10 KING', exp: 50000000000, levelReward: 0, monthly: 690000, rebate: 0.50, 
        gradient: 'from-rose-500 via-red-600 to-fuchsia-700', icon: 'stadia_controller', badge: 'King' 
    }
];

const DailyDashboard: React.FC<DailyDashboardProps> = ({ user, bets, onBack, onUpdateUser }) => {
    // State
    const [currentExp, setCurrentExp] = useState(0);
    const [currentVipLevel, setCurrentVipLevel] = useState(0); // 0 = No VIP
    const [rebateStats, setRebateStats] = useState({ todayVolume: 0, todayRebate: 0, totalRebate: 0 });
    const [claimData, setClaimData] = useState<any>({});
    
    // Deposit Bonus Page State
    const [showDepositBonusPage, setShowDepositBonusPage] = useState(false);
    
    const scrollRef = useRef<HTMLDivElement>(null);

    // Initial Load & Calculations
    useEffect(() => {
        // 1. Calculate EXP (Lifetime Bets)
        const allGlobalBets = JSON.parse(localStorage.getItem('ncci_all_bets') || '[]');
        const userGlobalBets = allGlobalBets.filter((b: UserBet) => b.userId === user.identifier);
        
        const totalBetAmount = userGlobalBets.reduce((acc: number, bet: UserBet) => acc + bet.amount, 0);
        setCurrentExp(totalBetAmount);

        // 2. Determine Current Level
        let levelIdx = 0;
        VIP_LEVELS.forEach((lvl, idx) => {
            if (totalBetAmount >= lvl.exp) {
                levelIdx = idx + 1;
            }
        });
        setCurrentVipLevel(levelIdx);

        // 3. Rebate Calculation (Today)
        const totalVolume = Math.floor(totalBetAmount * 0.1); 
        const currentRebateRate = levelIdx > 0 ? VIP_LEVELS[levelIdx - 1].rebate : 0;
        const calculatedRebate = Math.floor(totalVolume * (currentRebateRate / 100));
        
        setRebateStats({
            todayVolume: totalVolume,
            todayRebate: calculatedRebate,
            totalRebate: Math.floor(totalBetAmount * 0.005) 
        });

        // 4. Load Claims
        const storedClaims = JSON.parse(localStorage.getItem(`ncci_vip_claims_${user.identifier}`) || '{}');
        setClaimData(storedClaims);

        // Scroll
        if (scrollRef.current && levelIdx > 0) {
            const cardWidth = 320; 
            scrollRef.current.scrollTo({ left: (levelIdx - 1) * cardWidth, behavior: 'smooth' });
        }

    }, [user.identifier, bets]);

    const handleMonthlyClaim = () => {
        const now = Date.now();
        const lastClaim = claimData.monthlyLastClaim || 0;
        const lastDate = new Date(lastClaim);
        const currDate = new Date();

        if (lastDate.getMonth() === currDate.getMonth() && lastDate.getFullYear() === currDate.getFullYear()) {
            alert("Monthly Salary already claimed for this month.");
            return;
        }

        if (currentVipLevel === 0) {
            alert("You must be at least VIP 1 to claim Monthly Salary.");
            return;
        }

        const currentVip = VIP_LEVELS[currentVipLevel - 1];
        processClaim(`Monthly Salary (${currentVip.name})`, currentVip.monthly, 'monthlyLastClaim');
    };

    const handleLevelUpClaim = (levelIndex: number) => {
        const level = VIP_LEVELS[levelIndex];
        const claimKey = `levelReward_${level.id}`;
        
        if (claimData[claimKey]) return; // Already claimed
        
        if (currentExp < level.exp) {
            alert(`You need ${level.exp - currentExp} more EXP to unlock this reward.`);
            return;
        }

        processClaim(`Level Up Bonus (${level.name})`, level.levelReward, claimKey);
    };

    const processClaim = (type: string, amount: number, storageKey: string) => {
        if (amount <= 0) return;

        // UPDATED: Credit to bankMoney (Deposit Wallet) as requested
        const updatedUser = { ...user, bankMoney: (user.bankMoney || 0) + amount };
        
        const trans: Transaction = {
            id: 'VIP-' + Math.random().toString(36).substr(2, 9),
            userId: user.identifier,
            userName: user.name,
            type: 'Bonus',
            amount: amount,
            status: 'Success',
            timestamp: Date.now()
        };

        const existingTrans = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
        localStorage.setItem('ncci_transactions', JSON.stringify([...existingTrans, trans]));

        const newClaimData = { ...claimData, [storageKey]: Date.now() };
        localStorage.setItem(`ncci_vip_claims_${user.identifier}`, JSON.stringify(newClaimData));
        setClaimData(newClaimData);

        onUpdateUser(updatedUser);
        alert(`Successfully Claimed ${type}: ₹${amount} (Added to Deposit Wallet)`);
    };

    const nextLevel = currentVipLevel < VIP_LEVELS.length ? VIP_LEVELS[currentVipLevel] : VIP_LEVELS[VIP_LEVELS.length - 1];
    const progress = Math.min(100, Math.max(0, ((currentExp - (currentVipLevel > 0 ? VIP_LEVELS[currentVipLevel-1].exp : 0)) / (nextLevel.exp - (currentVipLevel > 0 ? VIP_LEVELS[currentVipLevel-1].exp : 0))) * 100));
    const isMax = currentVipLevel >= VIP_LEVELS.length;
    const progressDisplay = isMax ? 100 : progress;

    // --- NEW: Daily Deposit Bonus Logic ---
    const streakDay = user.depositStreak?.currentDay || 1;
    // If first deposit, bonus is fixed (8% or 12%), otherwise streak (3% + (day-1)%)
    // But logic here is mainly for display
    const isFirstTime = user.isFirstDeposit !== false; // Default true if undefined
    const displayBonusPercent = isFirstTime 
        ? (user.referredBy ? 12 : 8)
        : Math.min(30, 2 + streakDay); // Day 1 = 3%, Day 2 = 4%

    const isTodayDeposited = user.depositStreak?.lastDepositDate 
        ? new Date(user.depositStreak.lastDepositDate).setHours(0,0,0,0) === new Date().setHours(0,0,0,0)
        : false;

    return (
        <div className="min-h-screen bg-gray-900 font-display pb-20 text-white relative">
            {/* Header */}
            <header className="bg-gray-800/80 backdrop-blur-md border-b border-gray-700 p-4 sticky top-0 z-50 shadow-md flex justify-between items-center">
                <button onClick={onBack} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
                    <span className="material-symbols-outlined">arrow_back</span>
                    <span className="text-sm font-bold">Back</span>
                </button>
                <h1 className="font-black text-lg tracking-wider bg-gradient-to-r from-yellow-300 to-amber-500 bg-clip-text text-transparent">VIP DASHBOARD</h1>
                <div className="size-8"></div>
            </header>

            <main className="space-y-8 p-0 pt-6">
                
                {/* SECTION 1: VIP CARD SLIDER */}
                <div className="w-full overflow-x-auto no-scrollbar snap-x px-6 pb-8 flex gap-5" ref={scrollRef}>
                    {VIP_LEVELS.map((vip, index) => {
                        const isUnlocked = currentExp >= vip.exp;
                        const isCurrent = currentVipLevel === index + 1;
                        const isLocked = !isUnlocked;

                        return (
                            <div key={vip.id} className="snap-center shrink-0 w-[340px] perspective-1000">
                                <div className={`relative aspect-[1.58] rounded-[24px] p-6 overflow-hidden shadow-2xl transition-transform duration-500 hover:scale-[1.02] bg-gradient-to-br ${vip.gradient} border border-white/10 group`}>
                                    
                                    {/* Background Texture */}
                                    <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 mix-blend-overlay"></div>
                                    <div className="absolute -top-12 -right-12 size-48 bg-white/20 rounded-full blur-3xl group-hover:bg-white/30 transition-all"></div>

                                    {/* Status Badge */}
                                    <div className="absolute top-4 right-4">
                                        {isCurrent && <span className="bg-white/20 backdrop-blur-md border border-white/30 text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg flex items-center gap-1"><span className="size-2 bg-green-400 rounded-full animate-pulse"></span> Current</span>}
                                        {isLocked && <span className="bg-black/40 backdrop-blur-md border border-white/10 text-white/70 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest flex items-center gap-1"><span className="material-symbols-outlined text-xs">lock</span> Locked</span>}
                                        {!isCurrent && isUnlocked && <span className="bg-green-500/20 backdrop-blur-md border border-green-400/50 text-green-300 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest flex items-center gap-1"><span className="material-symbols-outlined text-xs">check_circle</span> Achieved</span>}
                                    </div>

                                    {/* Card Content */}
                                    <div className={`relative z-10 flex flex-col h-full justify-between ${vip.darkText ? 'text-gray-900' : 'text-white'}`}>
                                        {/* Content... same as before */}
                                        <div className="flex items-start gap-4">
                                            <div className={`size-14 rounded-2xl flex items-center justify-center shadow-lg text-3xl font-bold bg-white/20 backdrop-blur-sm border border-white/20`}>
                                                <span className="material-symbols-outlined text-4xl drop-shadow-md">{vip.icon}</span>
                                            </div>
                                            <div>
                                                <h2 className="text-2xl font-black italic tracking-tighter uppercase">{vip.name}</h2>
                                                <p className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-80">{vip.badge} Identity</p>
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-3 mt-2">
                                            <div className="bg-black/20 backdrop-blur-sm rounded-xl p-2 border border-white/5">
                                                <p className="text-[9px] font-bold uppercase opacity-60">Level Up Bonus</p>
                                                <p className="text-lg font-black">₹{vip.levelReward > 0 ? vip.levelReward.toLocaleString() : 'N/A'}</p>
                                            </div>
                                            <div className="bg-black/20 backdrop-blur-sm rounded-xl p-2 border border-white/5">
                                                <p className="text-[9px] font-bold uppercase opacity-60">Monthly Salary</p>
                                                <p className="text-lg font-black">₹{vip.monthly.toLocaleString()}</p>
                                            </div>
                                        </div>
                                        <div className="flex justify-between items-end border-t border-white/10 pt-3 mt-1">
                                            <div>
                                                <p className="text-[9px] font-bold uppercase opacity-60">Rebate Rate</p>
                                                <p className="text-xl font-black">{vip.rebate.toFixed(2)}%</p>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-[9px] font-bold uppercase opacity-60">Required EXP</p>
                                                <p className="text-sm font-mono font-bold tracking-wide">{vip.exp.toLocaleString()}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>

                {/* SECTION 2: PROGRESS BAR (Unchanged) */}
                <div className="px-6">
                    <div className="bg-gray-800 rounded-2xl p-5 border border-gray-700 shadow-lg relative overflow-hidden">
                        <div className="flex justify-between items-end mb-2 relative z-10">
                            <div>
                                <p className="text-xs text-gray-400 font-bold uppercase mb-1">Current EXP</p>
                                <p className="text-2xl font-black text-white">{currentExp.toLocaleString()}</p>
                            </div>
                            <div className="text-right">
                                <p className="text-[10px] text-gray-500 font-bold uppercase mb-1">Target: {nextLevel.name}</p>
                                <p className="text-sm font-mono text-yellow-500">{nextLevel.exp.toLocaleString()}</p>
                            </div>
                        </div>
                        <div className="w-full h-3 bg-gray-700 rounded-full overflow-hidden shadow-inner relative z-10">
                            <div className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 transition-all duration-1000 relative" style={{ width: `${progressDisplay}%` }}>
                                <div className="absolute inset-0 bg-white/30 animate-pulse"></div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* SECTION 3: ACTION BUTTONS */}
                <div className="px-6 pb-20 space-y-6">
                    
                    {/* Claims Grid */}
                    <div className="grid grid-cols-2 gap-4">
                        {/* MODIFIED: Opens Daily Deposit Bonus Page */}
                        <button 
                            onClick={() => setShowDepositBonusPage(true)}
                            className="bg-gradient-to-br from-emerald-600 to-green-700 p-4 rounded-2xl shadow-lg relative overflow-hidden group active:scale-95 transition-all text-left border border-green-500/30"
                        >
                            <div className="relative z-10">
                                <div className="size-8 bg-white/20 rounded-full flex items-center justify-center mb-2"><span className="material-symbols-outlined text-lg">calendar_month</span></div>
                                <h3 className="font-bold text-sm">Daily Bonus</h3>
                                <p className="text-[10px] opacity-80 mt-1">Check Streak</p>
                            </div>
                            <span className="material-symbols-outlined absolute -bottom-2 -right-2 text-6xl opacity-10">touch_app</span>
                        </button>

                        <button 
                            onClick={handleMonthlyClaim}
                            className="bg-gradient-to-br from-violet-600 to-purple-700 p-4 rounded-2xl shadow-lg relative overflow-hidden group active:scale-95 transition-all text-left border border-purple-500/30"
                        >
                            <div className="relative z-10">
                                <div className="size-8 bg-white/20 rounded-full flex items-center justify-center mb-2"><span className="material-symbols-outlined text-lg">savings</span></div>
                                <h3 className="font-bold text-sm">Monthly Salary</h3>
                                <p className="text-[10px] opacity-80 mt-1">Claim 1st of Month</p>
                            </div>
                            <span className="material-symbols-outlined absolute -bottom-2 -right-2 text-6xl opacity-10">payments</span>
                        </button>
                    </div>

                    {/* Rebate Dashboard (Unchanged) */}
                    <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-100 dark:border-gray-700 shadow-lg">
                        <div className="flex justify-between items-center mb-4 pb-4 border-b border-gray-700">
                            <h3 className="font-bold text-gray-200 flex items-center gap-2"><span className="material-symbols-outlined text-blue-400">percent</span> Rebate Dashboard</h3>
                            <span className="text-xs bg-blue-900/30 text-blue-300 px-2 py-1 rounded border border-blue-800">Rate: {(currentVipLevel > 0 ? VIP_LEVELS[currentVipLevel-1].rebate : 0).toFixed(2)}%</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-center">
                            <div>
                                <p className="text-[10px] text-gray-500 uppercase font-bold">Today Bet</p>
                                <p className="text-sm font-black text-white mt-1">₹{rebateStats.todayVolume.toLocaleString()}</p>
                            </div>
                            <div className="border-x border-gray-700">
                                <p className="text-[10px] text-gray-500 uppercase font-bold">Today Rebate</p>
                                <p className="text-sm font-black text-green-400 mt-1">₹{rebateStats.todayRebate}</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-gray-500 uppercase font-bold">Total Earned</p>
                                <p className="text-sm font-black text-yellow-400 mt-1">₹{rebateStats.totalRebate.toLocaleString()}</p>
                            </div>
                        </div>
                    </div>
                    
                    {/* Level Up Rewards List (Restored from previous turn implementation if missing) */}
                    <div className="bg-gray-800 rounded-2xl p-5 border border-gray-700">
                        <h3 className="font-bold text-gray-200 mb-4 flex items-center gap-2"><span className="material-symbols-outlined text-yellow-500">trophy</span> Level Rewards</h3>
                        <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                            {VIP_LEVELS.filter(l => l.levelReward > 0).map((lvl) => {
                                const isUnlocked = currentExp >= lvl.exp;
                                const isClaimed = claimData[`levelReward_${lvl.id}`];
                                
                                return (
                                    <div key={lvl.id} className="flex justify-between items-center bg-gray-900/50 p-3 rounded-xl border border-gray-700/50">
                                        <div className="flex items-center gap-3">
                                            <div className={`size-8 rounded-full flex items-center justify-center text-xs font-bold ${isUnlocked ? 'bg-green-900/30 text-green-500' : 'bg-gray-700 text-gray-500'}`}>
                                                {isUnlocked ? <span className="material-symbols-outlined text-sm">lock_open</span> : <span className="material-symbols-outlined text-sm">lock</span>}
                                            </div>
                                            <div>
                                                <div className="text-xs font-bold text-white">{lvl.name} Reward</div>
                                                <div className="text-[10px] text-gray-500">₹{lvl.levelReward.toLocaleString()} Cash</div>
                                            </div>
                                        </div>
                                        <button 
                                            onClick={() => handleLevelUpClaim(lvl.id - 1)}
                                            disabled={!isUnlocked || isClaimed}
                                            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase transition-all ${
                                                isClaimed ? 'bg-gray-700 text-gray-400 cursor-default' :
                                                isUnlocked ? 'bg-yellow-500 text-black hover:bg-yellow-400 shadow-lg shadow-yellow-500/20' :
                                                'bg-gray-800 text-gray-600 border border-gray-700 cursor-not-allowed'
                                            }`}
                                        >
                                            {isClaimed ? 'Claimed' : isUnlocked ? 'Claim' : 'Locked'}
                                        </button>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </main>

            {/* NEW: DAILY DEPOSIT BONUS PAGE OVERLAY */}
            {showDepositBonusPage && (
                <div className="fixed inset-0 z-[100] bg-gray-900 overflow-y-auto animate-fade-in">
                    {/* Page Header */}
                    <div className="bg-gradient-to-r from-orange-500 to-red-600 p-6 pt-8 pb-10 rounded-b-[2.5rem] shadow-2xl relative overflow-hidden">
                        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 mix-blend-overlay"></div>
                        <button onClick={() => setShowDepositBonusPage(false)} className="absolute top-4 left-4 size-10 bg-white/20 rounded-full flex items-center justify-center text-white hover:bg-white/30 transition-colors z-20">
                            <span className="material-symbols-outlined">arrow_back</span>
                        </button>
                        
                        <div className="relative z-10 text-center">
                            <div className="inline-flex items-center gap-2 bg-black/20 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/20 mb-4">
                                <span className="material-symbols-outlined text-yellow-300 text-sm animate-pulse">star</span>
                                <span className="text-xs font-bold uppercase tracking-widest text-white">Daily Deposit Bonus</span>
                            </div>
                            <h2 className="text-3xl font-black text-white leading-tight drop-shadow-md">
                                Keep The Streak<br/>Alive!
                            </h2>
                            <p className="text-white/80 text-sm mt-2 font-medium">Deposit min ₹100 daily to increase bonus</p>
                        </div>
                    </div>

                    <div className="px-4 -mt-6 relative z-10 space-y-6 pb-20">
                        {/* 1. Today's Status Card */}
                        <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-xl border border-gray-100 dark:border-gray-700">
                            <div className="flex justify-between items-center mb-4">
                                <div>
                                    <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Today's Bonus</p>
                                    <div className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-red-600">
                                        {displayBonusPercent}%
                                    </div>
                                </div>
                                <div className={`px-4 py-2 rounded-xl text-xs font-bold uppercase border ${isTodayDeposited ? 'bg-green-100 text-green-700 border-green-200' : 'bg-red-50 text-red-600 border-red-100'}`}>
                                    {isTodayDeposited ? 'Claimed' : 'Pending'}
                                </div>
                            </div>
                            
                            {!isTodayDeposited && (
                                <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-3 text-center border border-dashed border-gray-300 dark:border-gray-700">
                                    <p className="text-xs text-gray-500 font-bold">Deposit ₹100 now to unlock {displayBonusPercent}% Extra</p>
                                </div>
                            )}
                        </div>

                        {/* 2. 30-Day Streak Progress */}
                        <div className="bg-gray-800 rounded-3xl p-6 shadow-lg border border-gray-700 relative overflow-hidden">
                            <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                                <span className="material-symbols-outlined text-yellow-500">trophy</span> 30-Day Streak
                            </h3>
                            
                            {/* Days Grid */}
                            <div className="flex justify-between items-end mb-2 px-1">
                                <span className="text-xs font-bold text-gray-400">Day 1</span>
                                <span className="text-2xl font-black text-yellow-500">Day {streakDay}</span>
                                <span className="text-xs font-bold text-gray-400">Day 30</span>
                            </div>

                            {/* Progress Bar Container */}
                            <div className="h-6 w-full bg-gray-900 rounded-full border border-gray-600 p-1 relative">
                                <div 
                                    className="h-full rounded-full bg-gradient-to-r from-yellow-400 to-orange-600 shadow-[0_0_15px_rgba(251,191,36,0.6)] transition-all duration-1000 relative"
                                    style={{ width: `${(streakDay / 30) * 100}%` }}
                                >
                                    <div className="absolute inset-0 bg-white/30 animate-pulse"></div>
                                </div>
                                {/* Markers */}
                                <div className="absolute top-0 bottom-0 left-[33%] w-px bg-white/20"></div>
                                <div className="absolute top-0 bottom-0 left-[66%] w-px bg-white/20"></div>
                            </div>

                            <p className="text-[10px] text-gray-400 mt-4 text-center leading-relaxed">
                                Bonus increases by <span className="text-white font-bold">+1% daily</span>. Streak resets if you miss a day or after Day 30 completion.
                            </p>
                        </div>

                        {/* 3. Bonus Calculator Info */}
                        <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
                            <div className="relative z-10">
                                <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                                    <span className="material-symbols-outlined">calculate</span> Bonus Example
                                </h3>
                                <div className="space-y-3">
                                    <div className="flex justify-between text-sm">
                                        <span className="opacity-80">If you deposit:</span>
                                        <span className="font-bold">₹1,000</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="opacity-80">Today's Bonus ({displayBonusPercent}%):</span>
                                        <span className="font-bold text-green-300">+ ₹{1000 * (displayBonusPercent/100)}</span>
                                    </div>
                                    <div className="h-px bg-white/20 my-2"></div>
                                    <div className="flex justify-between text-lg font-black">
                                        <span>Total Credit:</span>
                                        <span>₹{1000 + (1000 * (displayBonusPercent/100))}</span>
                                    </div>
                                </div>
                            </div>
                            <span className="material-symbols-outlined absolute -bottom-6 -right-6 text-9xl opacity-10 rotate-12">savings</span>
                        </div>

                        {/* 4. Referral & Team Info */}
                        <div className="grid grid-cols-2 gap-4">
                            <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm">
                                <div className="size-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                                    <span className="material-symbols-outlined">person_add</span>
                                </div>
                                <h4 className="font-bold text-gray-800 dark:text-white text-xs uppercase mb-1">First Deposit</h4>
                                <p className="text-[10px] text-gray-500 leading-tight">
                                    Direct: <span className="font-bold text-blue-600">8%</span><br/>
                                    Referral: <span className="font-bold text-blue-600">12%</span>
                                </p>
                            </div>
                            <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm">
                                <div className="size-10 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center mb-3">
                                    <span className="material-symbols-outlined">groups</span>
                                </div>
                                <h4 className="font-bold text-gray-800 dark:text-white text-xs uppercase mb-1">Team Bonus</h4>
                                <p className="text-[10px] text-gray-500 leading-tight">
                                    Body: <span className="font-bold text-purple-600">5%</span><br/>
                                    Ongoing: <span className="font-bold text-purple-600">3%</span>
                                </p>
                            </div>
                        </div>

                        <div className="pt-4 text-center">
                            <p className="text-[10px] text-gray-500 font-medium">
                                * Minimum deposit ₹100 required to maintain streak.
                            </p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DailyDashboard;