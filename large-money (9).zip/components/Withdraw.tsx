import React, { useState } from 'react';
import { UserProfile, Transaction } from '../types';

interface WithdrawProps {
    user: UserProfile;
    onUpdateUser: (updatedUser: UserProfile) => void;
    onBack: () => void;
    onGoToActivation: () => void;
}

const Withdraw: React.FC<WithdrawProps> = ({ user, onUpdateUser, onBack, onGoToActivation }) => {
    const [amount, setAmount] = useState('');

    // CHECK ACTIVATION STATUS
    if (!user.withdrawalActive || !user.bankDetails) {
        return (
            <div className="min-h-screen bg-background-light dark:bg-background-dark pb-10 flex flex-col items-center justify-center p-6 text-center w-full">
                <div className="size-20 bg-red-100 rounded-full flex items-center justify-center mb-6 animate-bounce">
                    <span className="material-symbols-outlined text-4xl text-red-500">lock</span>
                </div>
                <h2 className="text-2xl font-bold text-gray-800 mb-2">Wallet Not Activated</h2>
                <p className="text-gray-500 mb-8 max-w-xs mx-auto">To withdraw funds, you must first activate your wallet by verifying your bank details and QR Code.</p>
                
                <button 
                    onClick={onGoToActivation}
                    className="w-full max-w-xs bg-primary hover:bg-primary-dark text-white font-bold py-4 rounded-xl shadow-xl flex items-center justify-center gap-2"
                >
                    Activate Wallet Now
                    <span className="material-symbols-outlined">arrow_forward</span>
                </button>
                
                <button onClick={onBack} className="mt-6 text-gray-400 font-bold text-sm">Cancel</button>
            </div>
        );
    }

    const handleSubmit = () => {
        const numAmount = Number(amount);

        if (!amount || numAmount < 100) {
            alert("Minimum Withdrawal Limit is ₹100");
            return;
        }
        if (numAmount > user.balance) {
            alert("Insufficient Winning Balance.");
            return;
        }

        const trans: Transaction = {
            id: Math.random().toString(36).substr(2, 9),
            userId: user.identifier,
            userName: user.name,
            type: 'Withdrawal',
            amount: numAmount,
            status: 'Pending',
            timestamp: Date.now(),
            upiId: user.bankDetails?.upiId,
            userQrCode: user.bankDetails?.qrCodeImage,
            bankDetailsSnapshot: JSON.stringify(user.bankDetails) // Snapshot current details
        };

        const existing = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
        localStorage.setItem('ncci_transactions', JSON.stringify([...existing, trans]));

        // Deduct Immediately
        const updatedUser = { ...user, balance: user.balance - numAmount };
        onUpdateUser(updatedUser);

        alert("Withdrawal Request Submitted!");
        onBack();
    };

    return (
        <div className="min-h-screen bg-background-light dark:bg-background-dark pb-10 w-full">
            <header className="bg-white dark:bg-surface-dark border-b border-gray-200 dark:border-gray-800 p-4 sticky top-0 z-50">
                <div className="w-full flex items-center gap-3">
                    <button onClick={onBack} className="text-gray-500 hover:text-primary">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </button>
                    <h1 className="font-bold text-lg text-gray-900 dark:text-white">Withdraw Funds</h1>
                </div>
            </header>

            <main className="w-full p-4 animate-fade-in space-y-6">
                
                {/* Available Balance Card */}
                <div className="bg-gradient-to-r from-green-500 to-emerald-700 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
                    <div className="relative z-10">
                        <p className="text-xs font-bold uppercase opacity-80 mb-1">Withdrawable Balance</p>
                        <h2 className="text-3xl font-bold">₹{user.balance.toFixed(2)}</h2>
                    </div>
                    <span className="material-symbols-outlined absolute -bottom-4 -right-4 text-9xl opacity-20">account_balance_wallet</span>
                </div>

                {/* Bank Details Summary */}
                <div className="bg-white dark:bg-surface-dark p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-sm font-bold text-gray-500 uppercase">Receiving Account</h3>
                        <div className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-xs font-bold flex items-center gap-1">
                            <span className="material-symbols-outlined text-sm">check_circle</span> Verified
                        </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                        <div className="size-16 rounded-lg bg-gray-50 border border-gray-200 overflow-hidden">
                            <img src={user.bankDetails.qrCodeImage} className="w-full h-full object-cover" alt="QR" />
                        </div>
                        <div className="text-sm">
                            <div className="font-bold text-gray-900 dark:text-white">{user.bankDetails.bankName}</div>
                            <div className="text-gray-500">{user.bankDetails.accountNumber}</div>
                            <div className="text-xs text-gray-400 mt-1">{user.bankDetails.accountHolder}</div>
                        </div>
                    </div>
                </div>

                {/* Withdrawal Form */}
                <div className="bg-white dark:bg-surface-dark p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 space-y-4">
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Withdrawal Amount</label>
                        <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-gray-400">₹</span>
                            <input 
                                type="number" 
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 pl-8 pr-4 font-bold text-lg outline-none focus:border-primary" 
                                placeholder="Min 100"
                                value={amount}
                                onChange={e => setAmount(e.target.value)}
                            />
                        </div>
                        <p className="text-xs text-right mt-2 text-gray-400">Max Withdrawal: ₹50,000</p>
                    </div>

                    <button onClick={handleSubmit} className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-4 rounded-xl shadow-lg mt-2 transition-transform active:scale-95">
                        Submit Request
                    </button>
                </div>
            </main>
        </div>
    );
};

export default Withdraw;