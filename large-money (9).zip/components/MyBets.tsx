import React, { useState } from 'react';
import { UserBet } from '../types';

interface MyBetsProps {
    bets: UserBet[];
}

const MyBets: React.FC<MyBetsProps> = ({ bets }) => {
    const [activeTab, setActiveTab] = useState<'history' | 'pending'>('history');

    const displayedBets = activeTab === 'history' 
        ? bets.filter(b => b.status !== 'Pending') 
        : bets.filter(b => b.status === 'Pending');

    // Sort by period descending
    displayedBets.sort((a, b) => Number(b.period) - Number(a.period));

    return (
        <div className="bg-white dark:bg-gray-800 rounded-[2rem] border border-gray-100 dark:border-gray-700 shadow-[0_8px_30px_rgb(0,0,0,0.04)] overflow-hidden flex-1 min-h-[400px]">
            {/* Custom Tab Bar */}
            <div className="flex p-2 gap-2 bg-gray-50/50 dark:bg-gray-800/50 border-b border-gray-100 dark:border-gray-700">
                <button 
                    onClick={() => setActiveTab('history')}
                    className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${
                        activeTab === 'history' 
                        ? 'bg-white dark:bg-gray-700 text-primary shadow-sm ring-1 ring-gray-200 dark:ring-gray-600' 
                        : 'text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                >
                    My History
                </button>
                <button 
                    onClick={() => setActiveTab('pending')}
                    className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${
                        activeTab === 'pending' 
                        ? 'bg-white dark:bg-gray-700 text-primary shadow-sm ring-1 ring-gray-200 dark:ring-gray-600' 
                        : 'text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                >
                    Pending Bets
                </button>
            </div>
            
            <div className="p-0 overflow-x-auto">
                {displayedBets.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                        <div className="size-24 bg-gray-50 dark:bg-gray-800 rounded-full flex items-center justify-center mb-4">
                            <span className="material-symbols-outlined text-4xl opacity-30">receipt_long</span>
                        </div>
                        <p className="font-bold text-sm opacity-60">No {activeTab} bets available</p>
                    </div>
                ) : (
                    <table className="w-full text-left text-sm whitespace-nowrap">
                        <thead className="bg-gray-50 dark:bg-gray-800/50 text-xs uppercase text-gray-400 font-bold tracking-wider">
                            <tr>
                                <th className="px-6 py-5">Period</th>
                                <th className="px-6 py-5">Selection</th>
                                <th className="px-6 py-5 text-right">Amount</th>
                                {activeTab === 'history' && <th className="px-6 py-5 text-right">Result</th>}
                                <th className="px-6 py-5 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-gray-800 font-medium">
                            {displayedBets.map((bet) => (
                                <tr key={bet.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                                    <td className="px-6 py-5 font-mono text-gray-600 dark:text-gray-300">
                                        <span className="text-gray-300 mr-1 text-xs">#</span>{bet.period}
                                    </td>
                                    <td className="px-6 py-5">
                                        <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wide border shadow-sm
                                            ${bet.selection === 'Green' ? 'bg-green-50 text-green-700 border-green-200' : 
                                              bet.selection === 'Red' ? 'bg-red-50 text-red-700 border-red-200' :
                                              bet.selection === 'Violet' ? 'bg-purple-50 text-purple-700 border-purple-200' :
                                              !isNaN(Number(bet.selection)) ? 'bg-blue-50 text-blue-700 border-blue-200' :
                                              'bg-orange-50 text-orange-700 border-orange-200'
                                            }`}>
                                            {bet.selection}
                                        </span>
                                    </td>
                                    <td className="px-6 py-5 text-right text-gray-800 font-bold">₹{bet.amount}</td>
                                    {activeTab === 'history' && (
                                        <td className={`px-6 py-5 text-right font-bold ${bet.winLoss >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                                            {bet.winLoss >= 0 ? '+' : '-'}₹{Math.abs(bet.winLoss)}
                                        </td>
                                    )}
                                    <td className="px-6 py-5 text-center">
                                        {bet.status === 'Won' && (
                                            <div className="inline-flex items-center justify-center gap-1.5 bg-green-100 text-green-700 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide">
                                                <span className="material-symbols-outlined text-sm">check</span> Won
                                            </div>
                                        )}
                                        {bet.status === 'Lost' && (
                                            <div className="inline-flex items-center justify-center gap-1.5 bg-gray-100 text-gray-500 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide">
                                                <span className="material-symbols-outlined text-sm">close</span> Lost
                                            </div>
                                        )}
                                        {bet.status === 'Pending' && (
                                            <div className="inline-flex items-center justify-center gap-1.5 bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide">
                                                <span className="material-symbols-outlined text-sm animate-spin">progress_activity</span> Wait
                                            </div>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
};

export default MyBets;