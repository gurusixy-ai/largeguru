import React from 'react';
import { GameResult } from '../types';

interface GameRecordProps {
    history: GameResult[];
}

const GameRecord: React.FC<GameRecordProps> = ({ history }) => {
    return (
        <div className="bg-white dark:bg-gray-800 rounded-[2rem] border border-gray-100 dark:border-gray-700 shadow-[0_8px_30px_rgb(0,0,0,0.04)] h-full flex flex-col overflow-hidden relative">
            <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center bg-white dark:bg-gray-800 relative z-20">
                <h3 className="font-bold text-gray-800 dark:text-white flex items-center gap-3 text-lg">
                    <div className="size-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center shadow-sm">
                        <span className="material-symbols-outlined text-xl">history</span>
                    </div>
                    Game Record
                </h3>
            </div>
            
            <div className="flex-1 overflow-auto max-h-[600px] lg:max-h-[calc(100vh-250px)] no-scrollbar bg-white dark:bg-gray-800 relative z-10">
                <table className="w-full text-left text-sm">
                    <thead className="sticky top-0 bg-gray-50 dark:bg-gray-700 z-10 shadow-sm text-xs uppercase text-gray-500 font-bold tracking-wider">
                        <tr>
                            <th className="px-6 py-4">Period</th>
                            <th className="px-6 py-4 text-center">Number</th>
                            <th className="px-6 py-4 text-center">Size</th>
                            <th className="px-6 py-4 text-right">Result</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-gray-700 font-mono text-sm">
                        {history.map((record, index) => (
                            <tr key={record.period} className={`transition-colors hover:bg-gray-50 dark:hover:bg-gray-700/50 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}`}>
                                <td className="px-6 py-4 font-bold text-gray-700 dark:text-gray-300">
                                    <span className="opacity-40 text-xs mr-1 font-sans">#</span>{record.period.slice(-4)}
                                </td>
                                <td className="px-6 py-4 text-center">
                                    <span className={`inline-flex items-center justify-center text-xl font-black bg-clip-text text-transparent drop-shadow-sm ${
                                        record.colors.length > 1 
                                        ? 'bg-gradient-to-r from-red-500 to-purple-600' 
                                        : record.colors[0] === 'Green' ? 'bg-gradient-to-r from-green-500 to-green-600' : 'bg-gradient-to-r from-red-500 to-red-600'
                                    }`}>
                                        {record.number}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-center">
                                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide shadow-sm ${record.size === 'Big' ? 'bg-orange-100 text-orange-700 border border-orange-200' : 'bg-blue-100 text-blue-700 border border-blue-200'}`}>
                                        {record.size}
                                    </span>
                                </td>
                                <td className="px-6 py-4 flex justify-end gap-1.5 items-center">
                                    {record.colors.map((color, idx) => (
                                        <div 
                                            key={idx} 
                                            className={`size-4 rounded-full shadow-inner ring-2 ring-white dark:ring-gray-800 ${
                                                color === 'Green' ? 'bg-gradient-to-br from-green-400 to-green-600' : 
                                                color === 'Red' ? 'bg-gradient-to-br from-red-400 to-red-600' : 'bg-gradient-to-br from-purple-400 to-purple-600'
                                            }`}
                                        ></div>
                                    ))}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default GameRecord;