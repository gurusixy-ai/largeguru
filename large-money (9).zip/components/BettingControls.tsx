import React, { useState } from 'react';

interface BettingControlsProps {
    onBet: (type: 'Color' | 'Number' | 'Size', value: string, amount: number) => void;
    disabled: boolean;
}

const BettingControls: React.FC<BettingControlsProps> = ({ onBet, disabled }) => {
    const [selectedBet, setSelectedBet] = useState<{type: 'Color' | 'Number' | 'Size', value: string} | null>(null);
    const [amount, setAmount] = useState(10);
    const [quantity, setQuantity] = useState(1);
    
    const AMOUNTS = [1, 10, 100, 500, 1000];

    const openBetModal = (type: 'Color' | 'Number' | 'Size', value: string) => {
        if (!disabled) {
            setSelectedBet({ type, value });
            setAmount(10);
            setQuantity(1);
        }
    };

    const confirmBet = () => {
        if (selectedBet) {
            onBet(selectedBet.type, selectedBet.value, amount * quantity);
            setSelectedBet(null);
        }
    };

    return (
        <>
            <div className="bg-white dark:bg-gray-800 rounded-[2.5rem] p-6 md:p-8 shadow-[0_10px_40px_-15px_rgba(0,0,0,0.1)] border border-gray-100 dark:border-gray-700 relative overflow-hidden">
                {disabled && (
                    <div className="absolute inset-0 z-20 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md flex flex-col items-center justify-center gap-4 transition-all duration-300">
                        <div className="relative">
                            <div className="size-20 rounded-full border-[6px] border-gray-200 border-t-primary animate-spin"></div>
                            <div className="absolute inset-0 flex items-center justify-center font-bold text-primary text-xs">WAIT</div>
                        </div>
                        <div className="bg-gray-900 text-white px-8 py-3 rounded-full font-bold shadow-2xl tracking-wide">
                            RESULTS PROCESSING...
                        </div>
                    </div>
                )}

                <div className="flex flex-col gap-10">
                    {/* 3D Color Action Buttons */}
                    <div>
                         <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4 ml-2">Join Color</h3>
                        <div className="grid grid-cols-3 gap-4 md:gap-8">
                            <button 
                                onClick={() => openBetModal('Color', 'Green')}
                                className="group relative h-20 md:h-24 rounded-2xl transition-all active:scale-95 active:translate-y-1"
                            >
                                <div className="absolute inset-0 bg-[#1b5e20] rounded-2xl transform translate-y-2 translate-x-0"></div>
                                <div className="absolute inset-0 bg-gradient-to-br from-[#4ade80] to-[#16a34a] rounded-2xl shadow-lg shadow-green-500/30 flex items-center justify-center border-t border-white/30">
                                    <div className="text-center">
                                        <span className="material-symbols-outlined text-3xl text-white drop-shadow-md block mb-1">grass</span>
                                        <span className="text-white font-black uppercase text-sm md:text-lg tracking-wider drop-shadow-md">Green</span>
                                    </div>
                                </div>
                                <div className="absolute inset-0 bg-white/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                            </button>

                            <button 
                                onClick={() => openBetModal('Color', 'Violet')}
                                className="group relative h-20 md:h-24 rounded-2xl transition-all active:scale-95 active:translate-y-1"
                            >
                                <div className="absolute inset-0 bg-[#4a148c] rounded-2xl transform translate-y-2 translate-x-0"></div>
                                <div className="absolute inset-0 bg-gradient-to-br from-[#d8b4fe] to-[#9333ea] rounded-2xl shadow-lg shadow-purple-500/30 flex items-center justify-center border-t border-white/30">
                                    <div className="text-center">
                                        <span className="material-symbols-outlined text-3xl text-white drop-shadow-md block mb-1">local_florist</span>
                                        <span className="text-white font-black uppercase text-sm md:text-lg tracking-wider drop-shadow-md">Violet</span>
                                    </div>
                                </div>
                                <div className="absolute inset-0 bg-white/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                            </button>

                            <button 
                                onClick={() => openBetModal('Color', 'Red')}
                                className="group relative h-20 md:h-24 rounded-2xl transition-all active:scale-95 active:translate-y-1"
                            >
                                <div className="absolute inset-0 bg-[#b71c1c] rounded-2xl transform translate-y-2 translate-x-0"></div>
                                <div className="absolute inset-0 bg-gradient-to-br from-[#f87171] to-[#dc2626] rounded-2xl shadow-lg shadow-red-500/30 flex items-center justify-center border-t border-white/30">
                                    <div className="text-center">
                                        <span className="material-symbols-outlined text-3xl text-white drop-shadow-md block mb-1">local_fire_department</span>
                                        <span className="text-white font-black uppercase text-sm md:text-lg tracking-wider drop-shadow-md">Red</span>
                                    </div>
                                </div>
                                <div className="absolute inset-0 bg-white/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                            </button>
                        </div>
                    </div>

                    {/* Number Grid - Glassmorphism Container */}
                    <div className="bg-gray-100/50 dark:bg-gray-900/50 p-6 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-inner">
                         <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4 ml-1">Select Number</h3>
                         <div className="grid grid-cols-5 md:grid-cols-10 gap-3 md:gap-4">
                            {[0,1,2,3,4,5,6,7,8,9].map(num => {
                                // Determine Gradient
                                let gradient = 'from-blue-400 to-blue-600 shadow-blue-500/30'; 
                                if (num === 0) gradient = 'from-pink-500 via-red-500 to-purple-600 shadow-purple-500/30';
                                else if (num === 5) gradient = 'from-emerald-400 via-green-500 to-purple-600 shadow-green-500/30';
                                else if ([1,3,7,9].includes(num)) gradient = 'from-emerald-400 to-green-600 shadow-green-500/30';
                                else gradient = 'from-red-400 to-red-600 shadow-red-500/30';

                                return (
                                    <button 
                                        key={num}
                                        onClick={() => openBetModal('Number', String(num))} 
                                        className={`group relative h-14 md:h-16 rounded-xl transition-all active:scale-90`}
                                    >
                                        <div className="absolute inset-0 bg-gray-300 dark:bg-gray-900 rounded-xl transform translate-y-1"></div>
                                        <div className={`absolute inset-0 bg-gradient-to-br ${gradient} rounded-xl shadow-md flex items-center justify-center border-t border-white/40`}>
                                            <span className="text-2xl font-black text-white drop-shadow-md">{num}</span>
                                        </div>
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Size Actions - Big Tactile Buttons */}
                    <div className="grid grid-cols-2 gap-6">
                        <button 
                            onClick={() => openBetModal('Size', 'Big')}
                            className="group relative h-16 rounded-2xl active:scale-[0.98] transition-all"
                        >
                            <div className="absolute inset-0 bg-yellow-600 rounded-2xl transform translate-y-1.5"></div>
                            <div className="absolute inset-0 bg-gradient-to-r from-amber-300 to-orange-500 rounded-2xl shadow-lg shadow-orange-500/30 flex items-center justify-center border-t border-white/40">
                                <span className="font-black text-2xl text-white uppercase tracking-[0.2em] drop-shadow-md">Big</span>
                            </div>
                        </button>
                        
                        <button 
                            onClick={() => openBetModal('Size', 'Small')}
                            className="group relative h-16 rounded-2xl active:scale-[0.98] transition-all"
                        >
                            <div className="absolute inset-0 bg-blue-700 rounded-2xl transform translate-y-1.5"></div>
                            <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-600 rounded-2xl shadow-lg shadow-blue-500/30 flex items-center justify-center border-t border-white/40">
                                <span className="font-black text-2xl text-white uppercase tracking-[0.2em] drop-shadow-md">Small</span>
                            </div>
                        </button>
                    </div>
                </div>
            </div>

            {/* Betting Modal - CENTERED CARD STYLE */}
            {selectedBet && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
                    <div className="bg-white dark:bg-gray-900 w-[95%] max-w-md rounded-[2rem] p-0 shadow-2xl overflow-hidden border border-gray-100 dark:border-gray-800 transform transition-all scale-100">
                         
                         {/* Modal Header */}
                         <div className={`p-8 text-center text-white relative overflow-hidden ${
                            selectedBet.type === 'Color' 
                                ? selectedBet.value === 'Green' ? 'bg-gradient-to-br from-green-500 to-green-700' : selectedBet.value === 'Red' ? 'bg-gradient-to-br from-red-500 to-red-700' : 'bg-gradient-to-br from-purple-500 to-purple-700'
                                : 'bg-gradient-to-br from-blue-600 to-indigo-700'
                        }`}>
                            <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/20 rounded-full blur-3xl"></div>
                            <div className="absolute top-10 left-0 w-20 h-20 bg-black/10 rounded-full blur-xl"></div>
                            
                            <h3 className="text-xs font-bold opacity-80 uppercase tracking-[0.2em] mb-2 relative z-10">Confirm Selection</h3>
                            <h2 className="text-5xl font-black drop-shadow-lg relative z-10">{selectedBet.value}</h2>
                         </div>

                        <div className="p-6 space-y-6">
                            {/* Amount Selector */}
                            <div>
                                <label className="text-xs font-bold text-gray-400 uppercase tracking-wide mb-3 block ml-1">Bet Amount</label>
                                <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
                                    {AMOUNTS.map(amt => (
                                        <button 
                                            key={amt}
                                            onClick={() => setAmount(amt)}
                                            className={`flex-1 min-w-[70px] py-3 rounded-xl text-sm font-bold border-2 transition-all shadow-sm
                                                ${amount === amt 
                                                    ? 'bg-primary/10 border-primary text-primary scale-105' 
                                                    : 'bg-gray-50 border-gray-100 text-gray-500 hover:bg-gray-100'}`}
                                        >
                                            ₹{amt}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Quantity Selector */}
                            <div>
                                <label className="text-xs font-bold text-gray-400 uppercase tracking-wide mb-3 block ml-1">Multiplier</label>
                                <div className="flex items-center gap-4 bg-gray-50 p-2 rounded-2xl border border-gray-100">
                                    <button 
                                        onClick={() => setQuantity(q => Math.max(1, q - 1))}
                                        className="size-12 rounded-xl bg-white shadow-sm border border-gray-200 flex items-center justify-center text-2xl font-bold hover:text-primary transition-colors active:scale-95"
                                    >-</button>
                                    <div className="flex-1 flex flex-col items-center">
                                        <span className="text-xs text-gray-400 font-bold uppercase">Quantity</span>
                                        <span className="font-mono font-bold text-3xl text-gray-800">{quantity}</span>
                                    </div>
                                    <button 
                                        onClick={() => setQuantity(q => q + 1)}
                                        className="size-12 rounded-xl bg-primary text-white shadow-lg shadow-primary/30 flex items-center justify-center text-2xl font-bold hover:bg-primary-dark transition-colors active:scale-95"
                                    >+</button>
                                </div>
                            </div>

                            {/* Summary Card */}
                            <div className="flex justify-between items-center p-5 bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl border border-gray-200 shadow-inner">
                                <span className="text-gray-500 font-bold uppercase text-xs">Total Bet Amount</span>
                                <span className="text-4xl font-black text-primary">₹{amount * quantity}</span>
                            </div>

                            {/* Actions */}
                            <div className="grid grid-cols-2 gap-4 pt-2">
                                <button 
                                    onClick={() => setSelectedBet(null)}
                                    className="py-4 rounded-2xl font-bold text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors"
                                >
                                    Cancel
                                </button>
                                <button 
                                    onClick={confirmBet}
                                    className="py-4 rounded-2xl font-bold bg-gradient-to-r from-primary to-blue-700 text-white shadow-xl shadow-primary/30 hover:scale-[1.02] transition-transform active:scale-95"
                                >
                                    Place Bet
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export default BettingControls;