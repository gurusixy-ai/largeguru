
import React, { useState, useEffect, useRef } from 'react';
import { Transaction, UserProfile, UserBet, AppNotification, AdminConfig, AdminTask, AviatorAdminConfig, AdminProfitMode } from '../types';

interface AdminPanelProps {
    user: UserProfile; 
    onLogout: () => void;
    currentPeriod: string;
    onUpdatePeriod: (newPeriod: number) => void;
    onResetTimer: (mode: '1min' | '3min' | '5min') => void;
    onSetTime: (mode: '1min' | '3min' | '5min', seconds: number) => void;
    onHome: () => void; 
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ user, onLogout, currentPeriod, onUpdatePeriod, onResetTimer, onSetTime, onHome }) => {
    // Determine initial tab based on permissions
    const getInitialTab = () => {
        if (user.adminRole === 'super') return 'dashboard';
        if (user.permissions && user.permissions.length > 0) {
            if (user.permissions.includes('dashboard')) return 'dashboard';
            // Map legacy 'game' permission to color_control as default
            if (user.permissions.includes('game')) return 'color_control';
            return user.permissions[0] as any;
        }
        return 'dashboard';
    };

    const [activeTab, setActiveTab] = useState<'dashboard' | 'color_control' | 'aviator_control' | 'users' | 'finance' | 'settings' | 'chat' | 'admins' | 'notifications' | 'tasks' | 'mlm'>(getInitialTab());
    const [users, setUsers] = useState<UserProfile[]>([]);
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [allBets, setAllBets] = useState<UserBet[]>([]);
    const [stats, setStats] = useState({
        totalDeposits: 0,
        totalWithdrawals: 0,
        totalBets: 0,
        totalPayouts: 0,
        houseProfit: 0,
        houseLoss: 0,
        pendingWithdrawals: 0,
        pendingDeposits: 0,
        userWalletHoldings: 0,
        activeUsers: 0
    });
    
    const [showSidebar, setShowSidebar] = useState(false);
    
    // Search & User Management States
    const [userSearch, setUserSearch] = useState('');
    const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null); 
    const [editMode, setEditMode] = useState(false);
    const [editedUser, setEditedUser] = useState<Partial<UserProfile>>({});
    const [showBonusModal, setShowBonusModal] = useState(false);
    const [showCreateUserModal, setShowCreateUserModal] = useState(false);
    const [newUser, setNewUser] = useState({ name: '', identifier: '', password: '', referralCode: '' });
    
    // MLM Management States
    const [mlmSearch, setMlmSearch] = useState('');
    const [mlmTargetUser, setMlmTargetUser] = useState<UserProfile | null>(null);
    const [newUplineCode, setNewUplineCode] = useState('');

    // Bonus Input
    const [bonusAmount, setBonusAmount] = useState('');

    // Finance States
    const [financeFilter, setFinanceFilter] = useState<'All' | 'Deposit' | 'Withdrawal'>('Deposit');
    // NEW: State for Payment Modal
    const [processingTransaction, setProcessingTransaction] = useState<Transaction | null>(null);

    // Game Control States
    const [autoProfitMode, setAutoProfitMode] = useState(false);
    const [manualResult, setManualResult] = useState('');
    const [forcedResultData, setForcedResultData] = useState<string | null>(null);
    
    // Timer Control State
    const [editTimerMode, setEditTimerMode] = useState<'1min' | '3min' | '5min'>('1min');
    const [customTime, setCustomTime] = useState('');
    
    // --- AVIATOR CONTROLS ---
    const [avProfitMode, setAvProfitMode] = useState<AdminProfitMode>('NONE');
    const [avManualCrash, setAvManualCrash] = useState<string>('');
    const [avHouseEdge, setAvHouseEdge] = useState<number>(7.5);
    
    // Prediction State
    const [prediction, setPrediction] = useState<{number: number | string, color: string, size: string, payout: number}>({
        number: '?', color: '?', size: '?', payout: 0
    });

    // Notification Center States
    const [notifTitle, setNotifTitle] = useState('');
    const [notifMessage, setNotifMessage] = useState('');
    const [notifLink, setNotifLink] = useState('');
    const [notifImage, setNotifImage] = useState('');
    const [notifTarget, setNotifTarget] = useState('all');
    
    // --- DAILY TASK WORK CREATION STATE ---
    const [adminTasks, setAdminTasks] = useState<AdminTask[]>([]);
    const [newTask, setNewTask] = useState<Partial<AdminTask>>({
        title: '',
        description: '',
        link: '',
        reward: 0,
        rewardDest: 'bankMoney', // Default
        type: 'onetime',
        image: ''
    });
    const [expiryInput, setExpiryInput] = useState('');
    const taskImageRef = useRef<HTMLInputElement>(null);

    // Proof Upload
    const [proofingTransactionId, setProofingTransactionId] = useState<string | null>(null);
    
    // Settings State
    const [adminUpi, setAdminUpi] = useState('');
    const [adminQr, setAdminQr] = useState('');
    const qrInputRef = useRef<HTMLInputElement>(null);

    // OTP Settings State
    const [otpService, setOtpService] = useState<'mock' | 'sms' | 'whatsapp' | 'email'>('mock');
    const [smsApiKey, setSmsApiKey] = useState('');
    const [whatsappApiKey, setWhatsappApiKey] = useState('');
    const [whatsappInstanceId, setWhatsappInstanceId] = useState('');
    const [gmailUser, setGmailUser] = useState('');
    const [gmailPass, setGmailPass] = useState('');

    // Chat Logic
    const [chatListDetails, setChatListDetails] = useState<any[]>([]);
    const [activeChatUser, setActiveChatUser] = useState<string | null>(null);
    const [chatHistory, setChatHistory] = useState<any[]>([]);
    const [chatMessage, setChatMessage] = useState('');
    const chatEndRef = useRef<HTMLDivElement>(null);
    const chatFileRef = useRef<HTMLInputElement>(null);
    
    // View Large QR
    const [viewQr, setViewQr] = useState<string | null>(null);

    // Guest Admin Management State
    const [newAdminId, setNewAdminId] = useState('');
    const [newAdminPass, setNewAdminPass] = useState('');
    const [newAdminName, setNewAdminName] = useState('');
    const [selectedPermissions, setSelectedPermissions] = useState<string[]>(['dashboard']);
    const [showNewAdminPass, setShowNewAdminPass] = useState(false);

    // Available Permissions for Guest Admins
    const AVAILABLE_PERMISSIONS = [
        { id: 'dashboard', label: 'Dashboard' },
        { id: 'users', label: 'User Management & MLM' },
        { id: 'finance', label: 'Finance & Transactions' },
        { id: 'game', label: 'Game Control (Aviator/Color)' },
        { id: 'settings', label: 'Settings & Tasks' },
        { id: 'notifications', label: 'Notifications' },
        { id: 'chat', label: 'Support Chat' }
    ];

    useEffect(() => {
        const loadData = () => {
            const storedUsers = JSON.parse(localStorage.getItem('ncci_users') || '[]');
            const storedTrans = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
            const storedBets = JSON.parse(localStorage.getItem('ncci_all_bets') || '[]');
            const storedForce = localStorage.getItem('ncci_force_result');
            
            setUsers(storedUsers);
            setTransactions(storedTrans.sort((a: Transaction, b: Transaction) => b.timestamp - a.timestamp));
            setAllBets(storedBets);
            setForcedResultData(storedForce);

            // Calculate Comprehensive Stats
            let dep = 0, wit = 0, penDep = 0, penWit = 0;
            storedTrans.forEach((t: Transaction) => {
                if (t.type === 'Deposit') {
                    if (t.status === 'Approved' || t.status === 'Success') dep += t.amount;
                    if (t.status === 'Pending') penDep += 1;
                }
                if (t.type === 'Withdrawal') {
                    if (t.status === 'Approved' || t.status === 'Success') wit += t.amount;
                    if (t.status === 'Pending') penWit += 1;
                }
            });

            let betVol = 0, payouts = 0, profit = 0;
            storedBets.forEach((b: UserBet) => {
                if (b.status === 'Pending') return;
                betVol += b.amount;
                // House Profit = -(User Win/Loss)
                profit += (-1 * b.winLoss);
                
                if (b.status === 'Won') {
                    // Total Payout = Bet returned + Profit
                    payouts += (b.amount + b.winLoss);
                }
            });

            const holdings = storedUsers.reduce((acc: number, u: UserProfile) => acc + (u.balance || 0) + (u.bankMoney || 0), 0);
            const activeCount = storedUsers.filter((u: UserProfile) => !u.isAdmin).length;

            setStats({
                totalDeposits: dep,
                totalWithdrawals: wit,
                totalBets: betVol,
                totalPayouts: payouts,
                houseProfit: profit,
                houseLoss: -profit,
                pendingDeposits: penDep,
                pendingWithdrawals: penWit,
                userWalletHoldings: holdings,
                activeUsers: activeCount
            });
            
            // --- LIVE PREDICTION LOGIC (Color Prediction Only) ---
            if (activeTab === 'color_control') {
                calculateLivePrediction(storedBets, storedForce);
            }
            
            // --- CHAT SCANNING LOGIC ---
            if (activeTab === 'chat') {
                const keys = Object.keys(localStorage);
                const chatKeys = keys.filter(k => k.startsWith('ncci_chat_'));
                
                const detailedList = chatKeys.map(key => {
                    const userId = key.replace('ncci_chat_', '');
                    const msgs = JSON.parse(localStorage.getItem(key) || '[]');
                    const lastMsg = msgs.length > 0 ? msgs[msgs.length - 1] : null;
                    const userObj = storedUsers.find((u: UserProfile) => u.identifier === userId);
                    
                    return {
                        userId,
                        name: userObj ? userObj.name : 'Unknown User',
                        lastMessage: lastMsg ? (lastMsg.image ? '📷 Photo' : lastMsg.text) : 'No messages',
                        timestamp: lastMsg ? lastMsg.timestamp : 0,
                        unread: lastMsg && lastMsg.sender === 'User'
                    };
                }).sort((a, b) => b.timestamp - a.timestamp);

                setChatListDetails(detailedList);

                if (activeChatUser) {
                    const activeMsgs = JSON.parse(localStorage.getItem(`ncci_chat_${activeChatUser}`) || '[]');
                    setChatHistory(activeMsgs);
                }
            }
        };
        loadData();
        
        // Load Settings
        setAdminUpi(localStorage.getItem('ncci_upi') || '8810572406@ptyes');
        setAdminQr(localStorage.getItem('ncci_qr') || 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=8810572406@ptyes');
        
        // Load Game Logic
        const apMode = localStorage.getItem('ncci_auto_profit') === 'true';
        setAutoProfitMode(apMode);

        // Load Aviator Config
        const avConfigStr = localStorage.getItem('ncci_aviator_config');
        if (avConfigStr) {
            const avConfig = JSON.parse(avConfigStr);
            setAvProfitMode(avConfig.profitMode || 'NONE');
            if (avConfig.manualCrashX) setAvManualCrash(avConfig.manualCrashX.toString());
            setAvHouseEdge(avConfig.houseEdgeTarget || 7.5);
        }

        // Load OTP Config
        const storedConfig = JSON.parse(localStorage.getItem('ncci_admin_config') || '{}');
        if (storedConfig.otpService) setOtpService(storedConfig.otpService);
        if (storedConfig.smsApiKey) setSmsApiKey(storedConfig.smsApiKey);
        if (storedConfig.whatsappApiKey) setWhatsappApiKey(storedConfig.whatsappApiKey);
        if (storedConfig.whatsappInstanceId) setWhatsappInstanceId(storedConfig.whatsappInstanceId);
        if (storedConfig.gmailUser) setGmailUser(storedConfig.gmailUser);
        if (storedConfig.gmailPass) setGmailPass(storedConfig.gmailPass);

        // Load Tasks
        const storedTasks = JSON.parse(localStorage.getItem('ncci_admin_tasks') || '[]');
        setAdminTasks(storedTasks);

        const interval = setInterval(loadData, 2000);
        return () => clearInterval(interval);
    }, [activeChatUser, activeTab, currentPeriod]);

    // Scroll to bottom when chat history changes
    useEffect(() => {
        if (activeTab === 'chat' && activeChatUser) {
            chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }
    }, [chatHistory, activeChatUser, activeTab]);

    // --- AVIATOR CONFIG HANDLER ---
    const saveAviatorConfig = () => {
        const payload: AviatorAdminConfig = {
            profitMode: avProfitMode,
            manualCrashX: avManualCrash ? parseFloat(avManualCrash) : null,
            houseEdgeTarget: avHouseEdge,
            updatedAt: Date.now(),
            lastUpdatedBy: user.name
        };
        console.log("ADMIN CONFIG EMIT:", { game: "AVIATOR", scope: "ADMIN_CONTROL", version: "v3.4.1", config: payload });
        localStorage.setItem('ncci_aviator_config', JSON.stringify(payload));
        alert(`Aviator Configuration Saved! Mode: ${avProfitMode}`);
        if (avManualCrash) setAvManualCrash('');
    };

    const handleAuditLog = () => {
        const config = localStorage.getItem('ncci_aviator_config');
        alert("Action Snapshot Generator:\n\n" + (config || "No configuration saved."));
    };

    // --- PREDICTION ALGORITHM ---
    const calculateLivePrediction = (bets: UserBet[], forced: string | null) => {
        if (forced) {
            const n = parseInt(forced);
            const size = n >= 5 ? 'Big' : 'Small';
            const color = [1,3,7,9].includes(n) ? 'Green' : [2,4,6,8].includes(n) ? 'Red' : n === 0 ? 'Violet/Red' : 'Violet/Green';
            setPrediction({ number: n, color, size, payout: 0 });
            return;
        }
        const apMode = localStorage.getItem('ncci_auto_profit') === 'true';
        if (!apMode) {
            setPrediction({ number: 'RANDOM', color: '?', size: '?', payout: 0 });
            return;
        }
        const pendingBets = bets.filter(b => b.status === 'Pending' && b.period === currentPeriod);
        let minPayout = Infinity;
        let bestNumber = -1;
        for (let n = 0; n <= 9; n++) {
            let totalPayout = 0;
            const numberColors = n === 0 ? ['Red', 'Violet'] : n === 5 ? ['Green', 'Violet'] : [1,3,7,9].includes(n) ? ['Green'] : ['Red'];
            const numberSize = n >= 5 ? 'Big' : 'Small';
            pendingBets.forEach(bet => {
                let multiplier = 0;
                if (bet.selection === 'Green' && numberColors.includes('Green')) multiplier = n === 5 ? 1.5 : 2;
                else if (bet.selection === 'Red' && numberColors.includes('Red')) multiplier = n === 0 ? 1.5 : 2;
                else if (bet.selection === 'Violet' && numberColors.includes('Violet')) multiplier = 4.5;
                else if (!isNaN(Number(bet.selection)) && Number(bet.selection) === n) multiplier = 9;
                else if (bet.selection === 'Big' && numberSize === 'Big') multiplier = 2;
                else if (bet.selection === 'Small' && numberSize === 'Small') multiplier = 2;
                if (multiplier > 0) totalPayout += (bet.amount * multiplier);
            });
            if (totalPayout < minPayout) {
                minPayout = totalPayout;
                bestNumber = n;
            }
        }
        if (bestNumber !== -1) {
            const size = bestNumber >= 5 ? 'Big' : 'Small';
            const color = [1,3,7,9].includes(bestNumber) ? 'Green' : [2,4,6,8].includes(bestNumber) ? 'Red' : bestNumber === 0 ? 'Violet/Red' : 'Violet/Green';
            setPrediction({ number: bestNumber, color, size, payout: minPayout });
        } else {
            setPrediction({ number: 'WAIT', color: '-', size: '-', payout: 0 });
        }
    };

    const hasPermission = (tab: string) => {
        if (user.adminRole === 'super') return true;
        if (tab === 'color_control' || tab === 'aviator_control') {
            return user.permissions?.includes('game');
        }
        return user.permissions?.includes(tab);
    };

    // --- TRANSACTION HANDLING ---
    const handleTransaction = (id: string, status: 'Approved' | 'Rejected', proofImage?: string) => {
        const trans = transactions.find(t => t.id === id);
        if (!trans) return;

        const updatedTrans = transactions.map(t => t.id === id ? { ...t, status, adminProofImage: proofImage } : t);
        setTransactions(updatedTrans);
        localStorage.setItem('ncci_transactions', JSON.stringify(updatedTrans));

        const updatedUsers = users.map(u => {
            if (u.identifier === trans.userId) {
                if (status === 'Approved' && trans.type === 'Deposit') {
                    const newActiveTimestamp = trans.amount >= 100 ? Date.now() : u.lastActiveDeposit;
                    let newDepositStreak = u.depositStreak || { currentDay: 0, lastDepositDate: 0 };
                    
                    if (trans.amount >= 100) {
                        const now = Date.now();
                        const oneDay = 24 * 60 * 60 * 1000;
                        const lastDate = newDepositStreak.lastDepositDate;
                        const daysDiff = Math.floor((now - lastDate) / oneDay);
                        if (lastDate === 0) newDepositStreak = { currentDay: 1, lastDepositDate: now };
                        else if (daysDiff <= 1) {
                            const isNewDay = new Date(now).getDate() !== new Date(lastDate).getDate();
                            if (isNewDay) newDepositStreak = { currentDay: Math.min(30, newDepositStreak.currentDay + 1), lastDepositDate: now };
                            else newDepositStreak = { ...newDepositStreak, lastDepositDate: now };
                        } else newDepositStreak = { currentDay: 1, lastDepositDate: now };
                    }
                    
                    const bonusToAdd = trans.bonusAmount || 0;
                    const totalToAdd = trans.amount + bonusToAdd;
                    return { 
                        ...u, 
                        bankMoney: (u.bankMoney || 0) + totalToAdd, 
                        lastActiveDeposit: newActiveTimestamp, 
                        depositStreak: newDepositStreak, 
                        isFirstDeposit: false 
                    };
                } else if (status === 'Rejected' && trans.type === 'Withdrawal') {
                    return { ...u, balance: u.balance + trans.amount };
                }
            }
            return u;
        });

        setUsers(updatedUsers);
        localStorage.setItem('ncci_users', JSON.stringify(updatedUsers));

        if (status === 'Approved') {
            const msg = trans.type === 'Withdrawal' 
                ? 'Your withdrawal request has been approved by Admin.' 
                : `Deposit of ₹${trans.amount} approved.${trans.bonusAmount ? ` Bonus ₹${trans.bonusAmount} credited!` : ''}`;
            createNotification(trans.userId, `${trans.type} Approved`, msg, proofImage);
        } else {
            const msg = trans.type === 'Withdrawal' 
                ? 'Your withdrawal request was rejected. Funds refunded to wallet.'
                : 'Your deposit request was rejected. Please contact support.';
            createNotification(trans.userId, `${trans.type} Rejected`, msg);
        }
        setProofingTransactionId(null);
        setProcessingTransaction(null);
    };

    const handleAdminPayment = (app: 'gpay' | 'phonepe' | 'paytm', upiId: string, amount: number, name: string) => {
        if (!upiId) {
            alert("No UPI ID found for this user.");
            return;
        }
        const params = `pa=${upiId}&pn=${encodeURIComponent(name)}&am=${amount}&cu=INR&tn=Withdrawal`;
        let url = `upi://pay?${params}`;
        if (app === 'gpay') url = `tez://upi/pay?${params}`;
        if (app === 'phonepe') url = `phonepe://pay?${params}`;
        if (app === 'paytm') url = `paytmmp://pay?${params}`;
        window.location.href = url;
    };

    const handleProofUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file && proofingTransactionId) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64 = reader.result as string;
                handleTransaction(proofingTransactionId, 'Approved', base64);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSaveUser = () => {
        if (!selectedUser) return;
        if (editedUser.identifier && editedUser.identifier !== selectedUser.identifier) {
            if (users.find(u => u.identifier === editedUser.identifier)) {
                alert("User ID already exists!");
                return;
            }
        }
        const updatedUsers = users.map(u => u.identifier === selectedUser.identifier ? { ...u, ...editedUser } : u);
        setUsers(updatedUsers);
        localStorage.setItem('ncci_users', JSON.stringify(updatedUsers));
        setSelectedUser(null);
        setEditMode(false);
        setEditedUser({});
        alert("User Profile Updated Successfully");
    };

    const handleDeleteUser = (userId: string) => {
        if (confirm("CRITICAL WARNING: Are you sure you want to delete this user?\n\nThis will remove their login access, wallet balance, and team structure position permanently.")) {
            const updatedUsers = users.filter(u => u.identifier !== userId);
            setUsers(updatedUsers);
            localStorage.setItem('ncci_users', JSON.stringify(updatedUsers));
            alert("User deleted successfully.");
        }
    };

    const calculateUserDeposits = (userId: string) => {
        return transactions
            .filter(t => t.userId === userId && t.type === 'Deposit' && (t.status === 'Approved' || t.status === 'Success'))
            .reduce((sum, t) => sum + t.amount, 0);
    };

    const handleCreateUser = () => {
        if (!newUser.identifier || !newUser.password || !newUser.name) {
            alert("Please fill all required fields");
            return;
        }
        if (users.find(u => u.identifier === newUser.identifier)) {
            alert("User ID already exists");
            return;
        }
        const userObj: UserProfile = {
            name: newUser.name,
            identifier: newUser.identifier,
            password: newUser.password,
            village: 'Admin Created', block: 'N/A', district: 'N/A',
            balance: 0, bankMoney: 0, bonusMoney: 0, bonusWagerTarget: 0, bonusWagerProgress: 0,
            isAdmin: false, isBlocked: false,
            referralCode: newUser.referralCode || 'MANUAL' + Math.floor(Math.random() * 1000),
            referralIncome: 0, withdrawalActive: true, mlmWallet: 0,
            joinedAt: Date.now(), lastActiveDeposit: 0
        };
        const updatedUsers = [...users, userObj];
        setUsers(updatedUsers);
        localStorage.setItem('ncci_users', JSON.stringify(updatedUsers));
        alert("User Created Successfully");
        setShowCreateUserModal(false);
        setNewUser({ name: '', identifier: '', password: '', referralCode: '' });
    };

    const createNotification = (userId: string, title: string, message: string, image?: string, link?: string) => {
        const newNote: AppNotification = { id: Date.now().toString() + Math.random(), userId, title, message, image, link, timestamp: Date.now(), read: false };
        const allNotes = JSON.parse(localStorage.getItem('ncci_notifications') || '[]');
        localStorage.setItem('ncci_notifications', JSON.stringify([...allNotes, newNote]));
    };

    const handleMlmSearch = () => {
        const target = users.find(u => u.identifier === mlmSearch || u.name.toLowerCase().includes(mlmSearch.toLowerCase()));
        if (target) {
            setMlmTargetUser(target);
            setNewUplineCode(target.referredBy || '');
        } else {
            alert("User not found");
            setMlmTargetUser(null);
        }
    };

    const handleUpdateUpline = () => {
        if (!mlmTargetUser) return;
        if (!users.find(u => u.referralCode === newUplineCode) && newUplineCode !== '') {
            alert("Invalid Upline Referral Code");
            return;
        }
        if (newUplineCode === mlmTargetUser.referralCode) {
            alert("User cannot refer themselves!");
            return;
        }
        const updatedUsers = users.map(u => u.identifier === mlmTargetUser.identifier ? { ...u, referredBy: newUplineCode } : u);
        setUsers(updatedUsers);
        localStorage.setItem('ncci_users', JSON.stringify(updatedUsers));
        setMlmTargetUser({ ...mlmTargetUser, referredBy: newUplineCode });
        alert("Upline Updated Successfully!");
    };

    const handleNotifImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => { const file = e.target.files?.[0]; if (file) { const reader = new FileReader(); reader.onloadend = () => { setNotifImage(reader.result as string); }; reader.readAsDataURL(file); } };
    const handleTaskImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => { const file = e.target.files?.[0]; if (file) { const reader = new FileReader(); reader.onloadend = () => { setNewTask(prev => ({...prev, image: reader.result as string})); }; reader.readAsDataURL(file); } };
    
    const handleCreateTask = () => { 
        if (!newTask.title || !newTask.link || !newTask.reward || !newTask.description) { 
            alert("Please fill Title, Link, Reward and Description."); 
            return; 
        } 
        const task: AdminTask = { 
            id: 'TASK-' + Date.now(), 
            title: newTask.title || '', 
            description: newTask.description || '', 
            link: newTask.link || '', 
            reward: Number(newTask.reward), 
            rewardDest: newTask.rewardDest || 'bankMoney', 
            image: newTask.image || '', 
            type: newTask.type || 'onetime', 
            active: true, 
            createdAt: Date.now(), 
            expiresAt: expiryInput ? new Date(expiryInput).getTime() : undefined 
        }; 
        const updated = [task, ...adminTasks]; 
        setAdminTasks(updated); 
        localStorage.setItem('ncci_admin_tasks', JSON.stringify(updated)); 
        setNewTask({ title: '', description: '', link: '', reward: 0, rewardDest: 'bankMoney', type: 'onetime', image: '' }); 
        setExpiryInput(''); 
        alert("Daily Task Created Successfully!"); 
    };

    const handleDeleteTask = (id: string) => { if(confirm("Are you sure you want to delete this task?")) { const updated = adminTasks.filter(t => t.id !== id); setAdminTasks(updated); localStorage.setItem('ncci_admin_tasks', JSON.stringify(updated)); } };
    const sendBroadcastNotification = () => { if (!notifTitle || !notifMessage) { alert("Title and Message are required"); return; } let targetUsers: UserProfile[] = []; if (notifTarget === 'all') { targetUsers = users.filter(u => !u.isAdmin); } else { const u = users.find(u => u.identifier === notifTarget); if (u) targetUsers = [u]; } if (targetUsers.length === 0) { alert("No users found to send notification."); return; } targetUsers.forEach(u => { createNotification(u.identifier, notifTitle, notifMessage, notifImage, notifLink); }); alert(`Notification sent successfully to ${targetUsers.length} users!`); setNotifTitle(''); setNotifMessage(''); setNotifLink(''); setNotifImage(''); setNotifTarget('all'); };
    const handleGiveBonus = () => { if (!selectedUser || !bonusAmount) return; const amount = Number(bonusAmount); const updatedUsers = users.map(u => { if (u.identifier === selectedUser.identifier) { return { ...u, bonusMoney: (u.bonusMoney || 0) + amount, bonusWagerTarget: (u.bonusWagerTarget || 0) + (amount * 10), }; } return u; }); setUsers(updatedUsers); localStorage.setItem('ncci_users', JSON.stringify(updatedUsers)); createNotification(selectedUser.identifier, 'Bonus Received', `Admin has credited ₹${amount} Bonus! Wager 10x to unlock.`); alert("Bonus Added"); setBonusAmount(''); setShowBonusModal(false); };
    const setForceResult = () => { if(!manualResult) return; localStorage.setItem('ncci_force_result', manualResult); setForcedResultData(manualResult); alert(`Next Result Forced to: ${manualResult}`); setManualResult(''); };
    const cancelForceResult = () => { localStorage.removeItem('ncci_force_result'); setForcedResultData(null); alert("Forced result cancelled. Game will revert to Auto/Random logic."); };
    const handleLiveTimeChange = (seconds: number) => { onSetTime(editTimerMode, seconds); alert(`${editTimerMode} Timer updated to ${seconds} seconds.`); };
    const handleCustomTimeSubmit = () => { const s = Number(customTime); if (!isNaN(s) && s > 0) { handleLiveTimeChange(s); setCustomTime(''); } };
    const handleQrCodeUpload = (e: React.ChangeEvent<HTMLInputElement>) => { const file = e.target.files?.[0]; if (file) { const reader = new FileReader(); reader.onloadend = () => { const base64 = reader.result as string; setAdminQr(base64); }; reader.readAsDataURL(file); } };
    const saveSettings = () => { 
        localStorage.setItem('ncci_upi', adminUpi); 
        localStorage.setItem('ncci_qr', adminQr); 
        const config: AdminConfig = { 
            upiId: adminUpi, 
            qrCode: adminQr, 
            otpService, 
            smsApiKey, 
            whatsappApiKey, 
            whatsappInstanceId, 
            gmailUser, 
            gmailPass 
        }; 
        localStorage.setItem('ncci_admin_config', JSON.stringify(config)); 
        alert("All Settings & Service Configurations Updated!"); 
    };
    const endChat = () => { if(!activeChatUser) return; localStorage.removeItem(`ncci_chat_${activeChatUser}`); setActiveChatUser(null); setChatListDetails(prev => prev.filter(c => c.userId !== activeChatUser)); };
    const sendAdminMessage = () => { if (!activeChatUser || !chatMessage.trim()) return; const currentMsgs = JSON.parse(localStorage.getItem(`ncci_chat_${activeChatUser}`) || '[]'); const newMsg = { id: Date.now(), text: chatMessage, sender: 'Admin', timestamp: Date.now(), read: true }; const updated = [...currentMsgs, newMsg]; localStorage.setItem(`ncci_chat_${activeChatUser}`, JSON.stringify(updated)); setChatHistory(updated); setChatMessage(''); };
    const handleAdminChatImage = (e: React.ChangeEvent<HTMLInputElement>) => { const file = e.target.files?.[0]; if (!file || !activeChatUser) return; const reader = new FileReader(); reader.onloadend = () => { const base64 = reader.result as string; const currentMsgs = JSON.parse(localStorage.getItem(`ncci_chat_${activeChatUser}`) || '[]'); const newMsg = { id: Date.now(), text: 'Image Sent', image: base64, sender: 'Admin', timestamp: Date.now(), read: true }; const updated = [...currentMsgs, newMsg]; localStorage.setItem(`ncci_chat_${activeChatUser}`, JSON.stringify(updated)); setChatHistory(updated); }; reader.readAsDataURL(file); e.target.value = ''; };
    
    const handleCreateAdmin = () => { 
        if (!newAdminId || !newAdminPass || !newAdminName) { 
            alert("Please fill all fields for new Admin"); 
            return; 
        } 
        if (users.find(u => u.identifier === newAdminId)) { 
            alert("User ID already exists!"); 
            return; 
        } 
        const newAdmin: UserProfile = { 
            name: newAdminName, identifier: newAdminId, password: newAdminPass, 
            village: 'N/A', block: 'N/A', district: 'N/A', 
            balance: 0, bankMoney: 0, bonusMoney: 0, bonusWagerTarget: 0, bonusWagerProgress: 0, 
            isAdmin: true, adminRole: 'guest', permissions: selectedPermissions, 
            isBlocked: false, referralCode: 'ADMIN-' + Math.floor(Math.random()*1000), 
            referralIncome: 0, withdrawalActive: true, mlmWallet: 0, 
            joinedAt: Date.now(), lastActiveDeposit: 0 
        }; 
        const updatedUsers = [...users, newAdmin]; 
        setUsers(updatedUsers); 
        localStorage.setItem('ncci_users', JSON.stringify(updatedUsers)); 
        alert(`Guest Admin '${newAdminName}' Created Successfully!`); 
        setNewAdminId(''); setNewAdminPass(''); setNewAdminName(''); setSelectedPermissions(['dashboard']); 
    };
    
    const handleDeleteAdmin = (id: string) => { if (confirm("Are you sure you want to delete this Guest Admin?")) { const updatedUsers = users.filter(u => u.identifier !== id); setUsers(updatedUsers); localStorage.setItem('ncci_users', JSON.stringify(updatedUsers)); } };
    const togglePermission = (perm: string) => { if (selectedPermissions.includes(perm)) { setSelectedPermissions(selectedPermissions.filter(p => p !== perm)); } else { setSelectedPermissions([...selectedPermissions, perm]); } };

    const cardClass = "bg-white border border-gray-100 p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow";
    const inputClass = "w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-gray-900 transition-all text-sm font-medium";
    const labelClass = "block text-xs font-bold text-gray-500 uppercase mb-2 tracking-wide";
    const sidebarClass = "bg-white border-r border-gray-100 shadow-xl";

    return (
        <div className="min-h-screen bg-gray-50/50 font-display flex flex-col md:flex-row transition-colors duration-300">
            {/* Sidebar Overlay for Mobile */}
            {showSidebar && <div className="fixed inset-0 bg-black/50 z-[60] md:hidden animate-fade-in backdrop-blur-sm" onClick={() => setShowSidebar(false)} />}

            {/* Mobile Header */}
            <div className="md:hidden bg-white p-4 flex justify-between items-center border-b border-gray-100 shadow-sm sticky top-0 z-50">
                 <h1 className="font-bold text-primary tracking-wide flex items-center gap-2">
                    <span className="material-symbols-outlined">verified_user</span> {user.adminRole === 'super' ? 'SUPER ADMIN' : 'GUEST ADMIN'}
                 </h1>
                 <button onClick={() => setShowSidebar(!showSidebar)} className="text-gray-600 p-2 rounded-lg hover:bg-gray-50">
                     <span className="material-symbols-outlined">menu</span>
                 </button>
            </div>

            {/* Sidebar */}
            <aside className={`fixed md:sticky top-0 left-0 bottom-0 w-72 ${sidebarClass} flex flex-col z-[70] transition-transform transform ${showSidebar ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 h-screen overflow-y-auto duration-300 ease-in-out`}>
                <div className="p-8 border-b border-gray-100 hidden md:flex flex-col items-start gap-2">
                     <div className="flex items-center gap-2">
                        <div className="size-10 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary/30">
                            <span className="material-symbols-outlined text-2xl">verified_user</span>
                        </div>
                        <div>
                            <h1 className="font-bold text-gray-900 tracking-tight text-xl leading-none">ADMIN</h1>
                            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Panel</span>
                        </div>
                     </div>
                     <span className={`text-[10px] px-3 py-1 rounded-full uppercase font-bold tracking-wider mt-2 ${user.adminRole === 'super' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-600'}`}>
                         {user.adminRole === 'super' ? 'Super Access' : 'Guest Access'}
                     </span>
                </div>

                <nav className="flex-1 p-6 space-y-2">
                    <button onClick={onHome} className="w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all font-bold text-gray-600 hover:bg-gray-50 border border-transparent hover:border-gray-200 mb-6 bg-white shadow-sm hover:shadow-md">
                        <span className="material-symbols-outlined text-primary">home</span> Back to Game
                    </button>

                    <p className="text-xs font-bold text-gray-400 uppercase tracking-widest px-4 mb-2">Menu</p>

                    {hasPermission('dashboard') && (<button onClick={() => {setActiveTab('dashboard'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold ${activeTab === 'dashboard' ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'hover:bg-gray-50 text-gray-600 hover:text-primary'}`}><span className="material-symbols-outlined">dashboard</span> Dashboard</button>)}
                    {hasPermission('users') && (<button onClick={() => {setActiveTab('mlm'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold ${activeTab === 'mlm' ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'hover:bg-gray-50 text-gray-600 hover:text-primary'}`}><span className="material-symbols-outlined">hub</span> MLM Network</button>)}
                    {hasPermission('finance') && (<button onClick={() => {setActiveTab('finance'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold ${activeTab === 'finance' ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'hover:bg-gray-50 text-gray-600 hover:text-primary'}`}><span className="material-symbols-outlined">payments</span> Transactions</button>)}
                    {hasPermission('users') && (<button onClick={() => {setActiveTab('users'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold ${activeTab === 'users' ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'hover:bg-gray-50 text-gray-600 hover:text-primary'}`}><span className="material-symbols-outlined">group</span> Users</button>)}
                    
                    {hasPermission('game') && (
                        <>
                            <button onClick={() => {setActiveTab('color_control'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold ${activeTab === 'color_control' ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'hover:bg-gray-50 text-gray-600 hover:text-primary'}`}>
                                <span className="material-symbols-outlined">palette</span> Color Control
                            </button>
                            <button onClick={() => {setActiveTab('aviator_control'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold ${activeTab === 'aviator_control' ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'hover:bg-gray-50 text-gray-600 hover:text-primary'}`}>
                                <span className="material-symbols-outlined">flight_takeoff</span> Aviator Control
                            </button>
                        </>
                    )}

                    {hasPermission('settings') && (<button onClick={() => {setActiveTab('tasks'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold ${activeTab === 'tasks' ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'hover:bg-gray-50 text-gray-600 hover:text-primary'}`}><span className="material-symbols-outlined">task</span> Daily Tasks</button>)}
                    {hasPermission('notifications') && (<button onClick={() => {setActiveTab('notifications'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold ${activeTab === 'notifications' ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'hover:bg-gray-50 text-gray-600 hover:text-primary'}`}><span className="material-symbols-outlined">campaign</span> Notifications</button>)}
                    {hasPermission('settings') && (<button onClick={() => {setActiveTab('settings'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold ${activeTab === 'settings' ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'hover:bg-gray-50 text-gray-600 hover:text-primary'}`}><span className="material-symbols-outlined">settings</span> Settings</button>)}
                    {hasPermission('chat') && (<button onClick={() => {setActiveTab('chat'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold ${activeTab === 'chat' ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'hover:bg-gray-50 text-gray-600 hover:text-primary'}`}><span className="material-symbols-outlined">support_agent</span> Live Chat <span className={`ml-auto text-[10px] px-2 py-0.5 rounded-full ${activeTab === 'chat' ? 'bg-white/20 text-white' : 'bg-primary text-white'}`}>{chatListDetails.length}</span></button>)}
                    
                    {user.adminRole === 'super' && (
                        <button onClick={() => {setActiveTab('admins'); setShowSidebar(false)}} className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all font-bold mt-4 ${activeTab === 'admins' ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/30' : 'hover:bg-purple-50 text-purple-700 hover:text-purple-800'}`}>
                            <span className="material-symbols-outlined">shield_person</span> Manage Admins
                        </button>
                    )}
                </nav>

                <div className="p-6 border-t border-gray-100">
                    <button onClick={onLogout} className="w-full flex items-center justify-center gap-3 bg-red-50 text-red-600 py-4 rounded-2xl text-sm font-bold transition-all hover:bg-red-100 hover:shadow-md">
                        <span className="material-symbols-outlined text-xl">logout</span> Logout
                    </button>
                </div>
            </aside>

            <main className="flex-1 p-4 md:p-10 w-full overflow-x-hidden bg-gray-50/50">
                
                {/* --- DASHBOARD TAB (ENHANCED) --- */}
                {activeTab === 'dashboard' && hasPermission('dashboard') && (
                    <div className="space-y-8 animate-fade-in max-w-7xl mx-auto">
                        <div className="flex justify-between items-center mb-4">
                            <div>
                                <h2 className="text-2xl font-bold text-gray-900">Live Overview</h2>
                                <p className="text-gray-500 text-sm">Financials, Game Performance & User Activity</p>
                            </div>
                            <div className="bg-white px-4 py-2 rounded-xl shadow-sm border border-gray-100 text-sm font-bold text-gray-600 flex items-center gap-2">
                                <span className="size-2 bg-green-500 rounded-full animate-pulse"></span> 
                                System Online
                            </div>
                        </div>

                        {/* Top Stats Grid - Updated to 5 columns on XL screens */}
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
                            
                            {/* 1. House Net Profit */}
                            <div className={`bg-gradient-to-br ${stats.houseProfit >= 0 ? 'from-emerald-500 to-green-600 shadow-green-500/20' : 'from-red-500 to-rose-600 shadow-red-500/20'} rounded-2xl p-6 text-white shadow-lg relative overflow-hidden group hover:scale-[1.02] transition-transform`}>
                                <div className="relative z-10">
                                    <div className="flex items-center gap-2 opacity-90 mb-2">
                                        <span className="material-symbols-outlined text-lg">savings</span> 
                                        <span className="text-xs font-bold uppercase tracking-wide">Net House Profit</span>
                                    </div>
                                    <div className="text-3xl font-black">{stats.houseProfit >= 0 ? '+' : '-'}₹{Math.abs(stats.houseProfit).toLocaleString()}</div>
                                    <p className="text-[10px] opacity-70 mt-1">Total Wagered - Total Won by Users</p>
                                </div>
                                <span className="material-symbols-outlined absolute -bottom-4 -right-4 text-9xl opacity-10 rotate-12">account_balance</span>
                            </div>

                            {/* 1.5. House Net Loss (NEW ADDITION) */}
                            <div className={`bg-gradient-to-br ${stats.houseLoss > 0 ? 'from-red-500 to-rose-600 shadow-red-500/20' : 'from-emerald-500 to-teal-600 shadow-emerald-500/20'} rounded-2xl p-6 text-white shadow-lg relative overflow-hidden group hover:scale-[1.02] transition-transform`}>
                                <div className="relative z-10">
                                    <div className="flex items-center gap-2 opacity-90 mb-2">
                                        <span className="material-symbols-outlined text-lg">trending_down</span> 
                                        <span className="text-xs font-bold uppercase tracking-wide">Net House Loss</span>
                                    </div>
                                    <div className="text-3xl font-black">{stats.houseLoss > 0 ? '-' : '+'}₹{Math.abs(stats.houseLoss).toLocaleString()}</div>
                                    <p className="text-[10px] opacity-70 mt-1">
                                        {stats.houseLoss > 0 ? 'Platform is losing money' : 'Platform is profitable'}
                                    </p>
                                </div>
                                <span className="material-symbols-outlined absolute -bottom-4 -right-4 text-9xl opacity-10 rotate-12">money_off</span>
                            </div>

                            {/* 2. Total Deposits */}
                            <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl p-6 text-white shadow-lg shadow-blue-500/20 relative overflow-hidden hover:scale-[1.02] transition-transform">
                                <div className="relative z-10">
                                    <div className="flex items-center gap-2 opacity-90 mb-2">
                                        <span className="material-symbols-outlined text-lg">download</span>
                                        <span className="text-xs font-bold uppercase tracking-wide">Total Deposits</span>
                                    </div>
                                    <div className="text-3xl font-black">₹{stats.totalDeposits.toLocaleString()}</div>
                                    <p className="text-[10px] opacity-70 mt-1 flex items-center gap-1">
                                        {stats.pendingDeposits > 0 ? <span className="text-yellow-300 font-bold">{stats.pendingDeposits} Pending</span> : 'All Cleared'}
                                    </p>
                                </div>
                                <span className="material-symbols-outlined absolute -bottom-4 -right-4 text-9xl opacity-10 rotate-12">payments</span>
                            </div>

                            {/* 3. Total Withdrawals */}
                            <div className="bg-gradient-to-br from-purple-500 to-violet-600 rounded-2xl p-6 text-white shadow-lg shadow-purple-500/20 relative overflow-hidden hover:scale-[1.02] transition-transform">
                                <div className="relative z-10">
                                    <div className="flex items-center gap-2 opacity-90 mb-2">
                                        <span className="material-symbols-outlined text-lg">upload</span>
                                        <span className="text-xs font-bold uppercase tracking-wide">Total Withdrawals</span>
                                    </div>
                                    <div className="text-3xl font-black">₹{stats.totalWithdrawals.toLocaleString()}</div>
                                    <p className="text-[10px] opacity-70 mt-1 flex items-center gap-1">
                                        {stats.pendingWithdrawals > 0 ? <span className="text-yellow-300 font-bold">{stats.pendingWithdrawals} Pending</span> : 'All Cleared'}
                                    </p>
                                </div>
                                <span className="material-symbols-outlined absolute -bottom-4 -right-4 text-9xl opacity-10 rotate-12">account_balance_wallet</span>
                            </div>

                            {/* 4. User Holdings (Liability) */}
                            <div className="bg-gradient-to-br from-gray-700 to-gray-900 rounded-2xl p-6 text-white shadow-lg shadow-gray-500/20 relative overflow-hidden hover:scale-[1.02] transition-transform">
                                <div className="relative z-10">
                                    <div className="flex items-center gap-2 opacity-90 mb-2">
                                        <span className="material-symbols-outlined text-lg">wallet</span>
                                        <span className="text-xs font-bold uppercase tracking-wide">User Wallet Liability</span>
                                    </div>
                                    <div className="text-3xl font-black">₹{stats.userWalletHoldings.toLocaleString()}</div>
                                    <p className="text-[10px] opacity-70 mt-1">Total active user balance</p>
                                </div>
                                <span className="material-symbols-outlined absolute -bottom-4 -right-4 text-9xl opacity-10 rotate-12">lock</span>
                            </div>
                        </div>

                        {/* Detailed Game Stats Row */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* Betting Volume */}
                            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between">
                                <div>
                                    <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-1">Total Bet Volume</p>
                                    <h3 className="text-2xl font-black text-gray-900">₹{stats.totalBets.toLocaleString()}</h3>
                                    <p className="text-xs text-gray-400 mt-1">Total amount wagered by users</p>
                                </div>
                                <div className="size-14 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
                                    <span className="material-symbols-outlined text-3xl">casino</span>
                                </div>
                            </div>

                            {/* Total Payouts */}
                            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between">
                                <div>
                                    <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-1">Total Winnings Paid</p>
                                    <h3 className="text-2xl font-black text-gray-900">₹{stats.totalPayouts.toLocaleString()}</h3>
                                    <p className="text-xs text-gray-400 mt-1">Total amount won by users</p>
                                </div>
                                <div className="size-14 rounded-full bg-green-50 text-green-600 flex items-center justify-center">
                                    <span className="material-symbols-outlined text-3xl">emoji_events</span>
                                </div>
                            </div>
                        </div>

                        {/* Active Users Summary */}
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <span className="material-symbols-outlined text-gray-400">group</span> User Base Summary
                            </h3>
                            <div className="flex gap-8">
                                <div>
                                    <p className="text-xs text-gray-500">Total Registered</p>
                                    <p className="text-xl font-bold text-gray-900">{users.filter(u => !u.isAdmin).length}</p>
                                </div>
                                <div className="w-px bg-gray-200"></div>
                                <div>
                                    <p className="text-xs text-gray-500">Active (Live)</p>
                                    <p className="text-xl font-bold text-green-600">{stats.activeUsers}</p>
                                </div>
                                <div className="w-px bg-gray-200"></div>
                                <div>
                                    <p className="text-xs text-gray-500">Blocked</p>
                                    <p className="text-xl font-bold text-red-500">{users.filter(u => u.isBlocked).length}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                
                {/* --- COLOR GAME CONTROL --- */}
                {activeTab === 'color_control' && hasPermission('game') && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fade-in max-w-7xl mx-auto">
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary">sports_esports</span> Live Game Control
                            </h3>
                            <div className="flex gap-4 mb-4">
                                <button onClick={() => {localStorage.setItem('ncci_auto_profit', 'true'); setAutoProfitMode(true);}} className={`flex-1 py-3 rounded-xl font-bold transition-all ${autoProfitMode ? 'bg-green-500 text-white shadow-lg shadow-green-500/30' : 'bg-gray-100 text-gray-600'}`}>Auto Profit ON</button>
                                <button onClick={() => {localStorage.setItem('ncci_auto_profit', 'false'); setAutoProfitMode(false);}} className={`flex-1 py-3 rounded-xl font-bold transition-all ${!autoProfitMode ? 'bg-red-500 text-white shadow-lg shadow-red-500/30' : 'bg-gray-100 text-gray-600'}`}>Random / Manual</button>
                            </div>
                            
                            {/* Manual Result Input */}
                            <div className="p-4 bg-gray-50 rounded-xl border border-gray-100 mb-4">
                                <label className={labelClass}>Force Next Result (0-9)</label>
                                <div className="flex gap-2">
                                    <input type="number" max="9" min="0" className={inputClass} placeholder="Number" value={manualResult} onChange={e => setManualResult(e.target.value)} />
                                    <button onClick={setForceResult} className="bg-blue-600 text-white px-6 rounded-xl font-bold hover:bg-blue-700">Set</button>
                                </div>
                                {forcedResultData && <p className="text-xs text-red-500 font-bold mt-2">Next Result Forced: {forcedResultData} <button onClick={cancelForceResult} className="underline ml-2">Cancel</button></p>}
                            </div>

                            {/* Timer Control */}
                            <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
                                <label className={labelClass}>Emergency Timer Control</label>
                                <div className="flex gap-2 mb-2">
                                    {(['1min', '3min', '5min'] as const).map(m => (
                                        <button key={m} onClick={() => setEditTimerMode(m)} className={`flex-1 py-2 text-xs font-bold rounded-lg ${editTimerMode === m ? 'bg-gray-800 text-white' : 'bg-white border border-gray-200 text-gray-600'}`}>{m}</button>
                                    ))}
                                </div>
                                <div className="flex gap-2">
                                    <input type="number" placeholder="Set Seconds" className={inputClass} value={customTime} onChange={e => setCustomTime(e.target.value)} />
                                    <button onClick={handleCustomTimeSubmit} className="bg-orange-500 text-white px-4 rounded-xl font-bold">Update</button>
                                    <button onClick={() => onResetTimer(editTimerMode)} className="bg-gray-200 text-gray-700 px-4 rounded-xl font-bold">Reset</button>
                                </div>
                            </div>
                        </div>

                        {/* Prediction & Live Info */}
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                             <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <span className="material-symbols-outlined text-purple-500">query_stats</span> Live Prediction
                            </h3>
                            <div className="flex items-center justify-between mb-4 bg-gray-50 p-4 rounded-xl border border-gray-100">
                                <div>
                                    <p className="text-xs text-gray-500 uppercase font-bold">Current Period</p>
                                    <p className="text-2xl font-black text-gray-900">{currentPeriod}</p>
                                </div>
                                <div className="text-right">
                                    <p className="text-xs text-gray-500 uppercase font-bold">Suggested Result</p>
                                    <div className="flex items-center justify-end gap-2">
                                        <span className={`text-2xl font-black ${prediction.color === 'Green' ? 'text-green-600' : prediction.color === 'Red' ? 'text-red-600' : 'text-purple-600'}`}>{prediction.number}</span>
                                        <span className={`px-2 py-0.5 rounded text-xs text-white font-bold ${prediction.color === 'Green' ? 'bg-green-600' : prediction.color === 'Red' ? 'bg-red-600' : 'bg-purple-600'}`}>{prediction.color}</span>
                                        <span className="px-2 py-0.5 rounded text-xs bg-gray-800 text-white font-bold">{prediction.size}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 text-center">
                                <p className="text-xs font-bold text-blue-800 uppercase">Estimated Payout with this result</p>
                                <p className="text-3xl font-black text-blue-600">₹{prediction.payout.toLocaleString()}</p>
                            </div>
                        </div>
                    </div>
                )}
                
                {/* --- AVIATOR GAME CONTROL --- */}
                {activeTab === 'aviator_control' && hasPermission('game') && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fade-in max-w-7xl mx-auto">
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-4 opacity-10"><span className="material-symbols-outlined text-9xl">flight_takeoff</span></div>
                            
                            <h3 className="text-lg font-bold text-gray-900 mb-6 relative z-10">Aviator Engine Config</h3>
                            
                            {/* Profit Mode Selector */}
                            <div className="space-y-4 mb-6 relative z-10">
                                <label className={labelClass}>Profit Strategy</label>
                                <div className="grid grid-cols-2 gap-3">
                                    {(['NONE', 'PROFIT_30', 'PROFIT_60', 'PROFIT_80'] as AdminProfitMode[]).map(mode => (
                                        <button 
                                            key={mode} 
                                            onClick={() => setAvProfitMode(mode)}
                                            className={`py-3 px-4 rounded-xl text-xs font-bold border transition-all ${
                                                avProfitMode === mode 
                                                ? 'bg-red-600 text-white border-red-600 shadow-md' 
                                                : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                                            }`}
                                        >
                                            {mode === 'NONE' ? 'Pure Random' : mode.replace('_', ' ')+'%'}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* House Edge Slider */}
                            <div className="mb-6 relative z-10">
                                <div className="flex justify-between mb-2">
                                    <label className={labelClass}>House Edge Target</label>
                                    <span className="font-bold text-red-600">{avHouseEdge}%</span>
                                </div>
                                <input 
                                    type="range" 
                                    min="0" max="20" step="0.5"
                                    value={avHouseEdge}
                                    onChange={(e) => setAvHouseEdge(parseFloat(e.target.value))}
                                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-red-600"
                                />
                                <div className="flex justify-between text-[10px] text-gray-400 font-bold mt-1">
                                    <span>Fair (0%)</span>
                                    <span>Aggressive (20%)</span>
                                </div>
                            </div>
                            
                            {/* Manual Crash Point */}
                            <div className="mb-6 relative z-10">
                                <label className={labelClass}>Force Next Crash Multiplier (Optional)</label>
                                <input 
                                    type="number" 
                                    step="0.01" 
                                    min="1.00" 
                                    placeholder="e.g. 1.00, 2.50, 100.00"
                                    value={avManualCrash}
                                    onChange={(e) => setAvManualCrash(e.target.value)}
                                    className={inputClass}
                                />
                                <p className="text-[10px] text-gray-400 mt-1">Leave empty for auto-generated crash point based on strategy.</p>
                            </div>

                            <div className="flex gap-4 relative z-10">
                                <button onClick={saveAviatorConfig} className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl shadow-lg transition-transform active:scale-95">
                                    Save Configuration
                                </button>
                                <button onClick={handleAuditLog} className="px-4 py-3 border border-gray-300 rounded-xl text-gray-600 hover:bg-gray-50 font-bold">
                                    Audit
                                </button>
                            </div>
                        </div>

                        {/* Explanation Card */}
                        <div className="bg-gray-800 p-6 rounded-2xl shadow-lg text-white">
                            <h3 className="font-bold mb-4 flex items-center gap-2"><span className="material-symbols-outlined text-yellow-400">info</span> Logic Breakdown</h3>
                            <ul className="space-y-3 text-sm text-gray-300">
                                <li className="flex gap-2">
                                    <span className="text-red-400 font-bold">Pure Random:</span> True RNG, verified fair (96% RTP).
                                </li>
                                <li className="flex gap-2">
                                    <span className="text-red-400 font-bold">Profit %:</span> Forces crash below 2.00x if house profit is below target % for the hour.
                                </li>
                                <li className="flex gap-2">
                                    <span className="text-red-400 font-bold">House Edge:</span> Long-term mathematical advantage (Default 7.5%).
                                </li>
                                <li className="flex gap-2">
                                    <span className="text-red-400 font-bold">Manual:</span> Overrides all logic for ONE round.
                                </li>
                            </ul>
                        </div>
                    </div>
                )}

                {/* --- USERS MANAGEMENT --- */}
                {activeTab === 'users' && hasPermission('users') && (
                    <div className="space-y-6 animate-fade-in max-w-7xl mx-auto">
                        <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                            <div className="relative w-full max-w-md">
                                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">search</span>
                                <input type="text" placeholder="Search by Phone, Email or Name..." className="pl-10 pr-4 py-2 w-full bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-primary transition-all" value={userSearch} onChange={e => setUserSearch(e.target.value)} />
                            </div>
                            <button onClick={() => setShowCreateUserModal(true)} className="bg-primary text-white px-4 py-2 rounded-xl font-bold text-sm shadow-lg shadow-primary/30 flex items-center gap-2 hover:bg-primary-dark transition-colors">
                                <span className="material-symbols-outlined text-lg">person_add</span> Add User
                            </button>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {users.filter(u => u.identifier.includes(userSearch) || u.name.toLowerCase().includes(userSearch.toLowerCase()) || (u.referralCode && u.referralCode.includes(userSearch))).map(u => (
                                <div key={u.identifier} className={`bg-white p-5 rounded-2xl shadow-sm border ${u.isBlocked ? 'border-red-200 bg-red-50' : 'border-gray-100'} hover:shadow-md transition-shadow relative overflow-hidden group`}>
                                    {u.isAdmin && <div className="absolute top-0 right-0 bg-purple-100 text-purple-700 text-[10px] font-bold px-2 py-1 rounded-bl-lg">ADMIN</div>}
                                    <div className="flex items-center gap-4 mb-4">
                                        <div className={`size-12 rounded-full flex items-center justify-center font-bold text-xl ${u.isBlocked ? 'bg-red-200 text-red-600' : 'bg-primary/10 text-primary'}`}>{u.name.charAt(0)}</div>
                                        <div className="overflow-hidden">
                                            <h4 className="font-bold text-gray-900 truncate">{u.name}</h4>
                                            <p className="text-xs text-gray-500 font-mono truncate">{u.identifier}</p>
                                            <p className="text-[10px] text-gray-400 mt-0.5">Ref: {u.referralCode}</p>
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-2 gap-2 mb-4">
                                        <div className="bg-gray-50 p-2 rounded-lg border border-gray-100">
                                            <p className="text-[10px] font-bold text-gray-400 uppercase">Balance</p>
                                            <p className="font-bold text-gray-800">₹{u.balance}</p>
                                        </div>
                                        <div className="bg-gray-50 p-2 rounded-lg border border-gray-100">
                                            <p className="text-[10px] font-bold text-gray-400 uppercase">Deposits</p>
                                            <p className="font-bold text-green-600">₹{calculateUserDeposits(u.identifier)}</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        <button onClick={() => {setSelectedUser(u); setEditedUser(u); setEditMode(true);}} className="flex-1 bg-white border border-gray-200 text-gray-600 py-2 rounded-lg text-xs font-bold hover:bg-gray-50">Edit</button>
                                        <button onClick={() => {setSelectedUser(u); setShowBonusModal(true);}} className="flex-1 bg-white border border-yellow-200 text-yellow-600 py-2 rounded-lg text-xs font-bold hover:bg-yellow-50">Bonus</button>
                                        {!u.isAdmin && <button onClick={() => handleDeleteUser(u.identifier)} className="p-2 bg-red-50 text-red-500 rounded-lg hover:bg-red-100"><span className="material-symbols-outlined text-lg">delete</span></button>}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
                
                {/* --- FINANCE TAB --- */}
                {activeTab === 'finance' && hasPermission('finance') && (
                    <div className="space-y-6 animate-fade-in max-w-7xl mx-auto">
                        <div className="flex gap-2 overflow-x-auto pb-2">
                            {['All', 'Deposit', 'Withdrawal'].map(f => (
                                <button key={f} onClick={() => setFinanceFilter(f as any)} className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${financeFilter === f ? 'bg-primary text-white shadow-md' : 'bg-white text-gray-600 hover:bg-gray-100'}`}>{f}</button>
                            ))}
                        </div>
                        
                        {/* MOBILE CARD VIEW FOR TRANSACTIONS */}
                        <div className="md:hidden space-y-4">
                            {transactions.filter(t => financeFilter === 'All' || t.type === financeFilter).map(t => (
                                <div key={t.id} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
                                    <div className="flex justify-between items-start mb-3">
                                        <div>
                                            <span className="font-bold text-gray-900 block">{t.userName}</span>
                                            <span className="text-xs text-gray-500 font-mono">{t.userId}</span>
                                        </div>
                                        <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${t.type === 'Deposit' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{t.type}</span>
                                    </div>
                                    
                                    <div className="flex justify-between items-center mb-3 bg-gray-50 p-3 rounded-lg">
                                        <span className="text-xs text-gray-500 font-bold uppercase">Amount</span>
                                        <span className="font-bold text-lg text-gray-900">₹{t.amount} {t.bonusAmount ? <span className="text-green-500 text-xs ml-1">(+₹{t.bonusAmount})</span> : ''}</span>
                                    </div>

                                    {/* Details Section */}
                                    <div className="text-xs text-gray-500 space-y-1 mb-4">
                                        {t.utr && <div>UTR: <span className="font-mono text-gray-700">{t.utr}</span></div>}
                                        {t.upiId && <div>UPI: <span className="font-mono text-gray-700">{t.upiId}</span></div>}
                                        {t.userQrCode && (
                                            <button onClick={() => setViewQr(t.userQrCode || null)} className="text-blue-600 hover:underline font-bold flex items-center gap-1"><span className="material-symbols-outlined text-sm">qr_code</span> View QR</button>
                                        )}
                                        <div>{new Date(t.timestamp).toLocaleString()}</div>
                                    </div>

                                    {/* Actions */}
                                    {t.status === 'Pending' ? (
                                        <div className="grid grid-cols-2 gap-2">
                                            {t.type === 'Withdrawal' && (
                                                <button 
                                                    onClick={() => setProcessingTransaction(t)} 
                                                    className="col-span-2 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-bold text-xs shadow-sm flex items-center justify-center gap-1"
                                                >
                                                    <span className="material-symbols-outlined text-sm">payments</span> Pay Now
                                                </button>
                                            )}
                                            {t.type === 'Deposit' && (
                                                <button onClick={() => handleTransaction(t.id, 'Approved')} className="bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg font-bold text-xs shadow-sm">Approve</button>
                                            )}
                                            <button onClick={() => handleTransaction(t.id, 'Rejected')} className={`bg-red-500 hover:bg-red-600 text-white py-2 rounded-lg font-bold text-xs shadow-sm ${t.type === 'Deposit' ? '' : 'col-span-2'}`}>Reject</button>
                                        </div>
                                    ) : (
                                        <div className={`w-full py-2 rounded-lg font-bold text-xs text-center uppercase border ${t.status === 'Approved' || t.status === 'Success' ? 'bg-green-50 text-green-600 border-green-100' : 'bg-red-50 text-red-600 border-red-100'}`}>
                                            {t.status}
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>

                        {/* DESKTOP TABLE VIEW */}
                        <div className="hidden md:block bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-gray-50 text-xs uppercase text-gray-500 font-bold border-b border-gray-100">
                                    <tr>
                                        <th className="px-6 py-4">User</th>
                                        <th className="px-6 py-4">Type</th>
                                        <th className="px-6 py-4">Amount</th>
                                        <th className="px-6 py-4">Details</th>
                                        <th className="px-6 py-4 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100">
                                    {transactions.filter(t => financeFilter === 'All' || t.type === financeFilter).map(t => (
                                        <tr key={t.id} className="hover:bg-gray-50/50">
                                            <td className="px-6 py-4">
                                                <div className="font-bold text-gray-900">{t.userName}</div>
                                                <div className="text-xs text-gray-500 font-mono">{t.userId}</div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${t.type === 'Deposit' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{t.type}</span>
                                            </td>
                                            <td className="px-6 py-4 font-bold">₹{t.amount} {t.bonusAmount ? <span className="text-green-500 text-xs ml-1">(+₹{t.bonusAmount} Bonus)</span> : ''}</td>
                                            <td className="px-6 py-4 text-xs text-gray-500">
                                                {t.utr && <div>UTR: <span className="font-mono text-gray-700">{t.utr}</span></div>}
                                                {t.upiId && <div>UPI: <span className="font-mono text-gray-700">{t.upiId}</span></div>}
                                                {t.timestamp && <div>{new Date(t.timestamp).toLocaleString()}</div>}
                                                {t.userQrCode && (
                                                    <button onClick={() => setViewQr(t.userQrCode || null)} className="text-blue-600 hover:underline mt-1 font-bold flex items-center gap-1"><span className="material-symbols-outlined text-sm">qr_code</span> View QR</button>
                                                )}
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                {t.status === 'Pending' ? (
                                                    <div className="flex justify-center gap-2">
                                                        {t.type === 'Withdrawal' && (
                                                            <button 
                                                                onClick={() => setProcessingTransaction(t)} 
                                                                className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm flex items-center gap-1"
                                                            >
                                                                <span className="material-symbols-outlined text-sm">payments</span> Pay
                                                            </button>
                                                        )}
                                                        {t.type === 'Deposit' && (
                                                            <button onClick={() => handleTransaction(t.id, 'Approved')} className="bg-green-500 hover:bg-green-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm">Approve</button>
                                                        )}
                                                        <button onClick={() => handleTransaction(t.id, 'Rejected')} className="bg-red-500 hover:bg-red-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm">Reject</button>
                                                    </div>
                                                ) : (
                                                    <span className={`font-bold text-xs uppercase ${t.status === 'Approved' || t.status === 'Success' ? 'text-green-600' : 'text-red-500'}`}>{t.status}</span>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}
                
                {/* --- SETTINGS TAB --- */}
                {activeTab === 'settings' && hasPermission('settings') && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fade-in max-w-6xl mx-auto">
                        {/* Payment Settings */}
                        <div className={cardClass}>
                            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2"><span className="material-symbols-outlined text-primary">account_balance</span> Payment Configuration</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className={labelClass}>Admin UPI ID</label>
                                    <input type="text" className={inputClass} value={adminUpi} onChange={e => setAdminUpi(e.target.value)} />
                                </div>
                                <div>
                                    <label className={labelClass}>Admin QR Code (Upload Image)</label>
                                    <input type="file" ref={qrInputRef} onChange={handleQrCodeUpload} className="hidden" accept="image/*" />
                                    <div className="flex gap-4 items-center">
                                        <div onClick={() => qrInputRef.current?.click()} className="size-24 border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center cursor-pointer hover:bg-gray-50 relative overflow-hidden">
                                            <img src={adminQr} className="w-full h-full object-cover" alt="QR" />
                                        </div>
                                        <button onClick={() => qrInputRef.current?.click()} className="text-sm font-bold text-primary">Change QR</button>
                                    </div>
                                </div>
                                <button onClick={saveSettings} className="w-full bg-primary text-white py-3 rounded-xl font-bold hover:bg-primary-dark">Save Payment Settings</button>
                            </div>
                        </div>

                        {/* OTP Service Settings */}
                        <div className={cardClass}>
                            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2"><span className="material-symbols-outlined text-green-600">sms</span> OTP Service</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className={labelClass}>Service Provider</label>
                                    <select value={otpService} onChange={(e) => setOtpService(e.target.value as any)} className={inputClass}>
                                        <option value="mock">Mock (Console Alert - Free)</option>
                                        <option value="sms">SMS Gateway (API)</option>
                                        <option value="whatsapp">WhatsApp API</option>
                                        <option value="email">Gmail SMTP</option>
                                    </select>
                                </div>
                                {otpService === 'sms' && (
                                    <div><label className={labelClass}>SMS API Key</label><input type="text" className={inputClass} value={smsApiKey} onChange={e => setSmsApiKey(e.target.value)} /></div>
                                )}
                                {otpService === 'whatsapp' && (
                                    <>
                                        <div><label className={labelClass}>Instance ID</label><input type="text" className={inputClass} value={whatsappInstanceId} onChange={e => setWhatsappInstanceId(e.target.value)} /></div>
                                        <div><label className={labelClass}>Access Token</label><input type="text" className={inputClass} value={whatsappApiKey} onChange={e => setWhatsappApiKey(e.target.value)} /></div>
                                    </>
                                )}
                                {otpService === 'email' && (
                                    <>
                                        <div><label className={labelClass}>Gmail Address</label><input type="text" className={inputClass} value={gmailUser} onChange={e => setGmailUser(e.target.value)} /></div>
                                        <div><label className={labelClass}>App Password</label><input type="password" className={inputClass} value={gmailPass} onChange={e => setGmailPass(e.target.value)} /></div>
                                    </>
                                )}
                                <button onClick={saveSettings} className="w-full bg-green-600 text-white py-3 rounded-xl font-bold hover:bg-green-700">Update OTP Config</button>
                            </div>
                        </div>
                    </div>
                )}
                
                {/* --- CHAT TAB --- */}
                {activeTab === 'chat' && hasPermission('chat') && (
                    <div className="flex flex-col md:flex-row h-[80vh] bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden animate-fade-in max-w-6xl mx-auto">
                        <div className="w-full md:w-1/3 border-b md:border-b-0 md:border-r border-gray-200 flex flex-col h-1/3 md:h-full">
                            <div className="p-4 border-b border-gray-100 font-bold text-gray-700 bg-gray-50">Active Chats</div>
                            <div className="flex-1 overflow-y-auto">
                                {chatListDetails.map(c => (
                                    <div key={c.userId} onClick={() => { setActiveChatUser(c.userId); setChatHistory(JSON.parse(localStorage.getItem(`ncci_chat_${c.userId}`) || '[]')); }} className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-blue-50 transition-colors ${activeChatUser === c.userId ? 'bg-blue-50 border-l-4 border-l-primary' : ''}`}>
                                        <div className="flex justify-between items-start mb-1">
                                            <span className="font-bold text-sm text-gray-800">{c.name}</span>
                                            {c.unread && <span className="size-2 bg-red-500 rounded-full"></span>}
                                        </div>
                                        <div className="text-xs text-gray-500 truncate">{c.lastMessage}</div>
                                        <div className="text-[10px] text-gray-400 mt-1">{new Date(c.timestamp).toLocaleTimeString()}</div>
                                    </div>
                                ))}
                                {chatListDetails.length === 0 && <div className="p-8 text-center text-gray-400 text-sm">No active conversations</div>}
                            </div>
                        </div>
                        <div className="flex-1 flex flex-col bg-gray-50/50 h-2/3 md:h-full">
                            {activeChatUser ? (
                                <>
                                    <div className="p-4 bg-white border-b border-gray-200 flex justify-between items-center shadow-sm">
                                        <div className="font-bold text-gray-800 flex items-center gap-2">
                                            <span className="size-2 bg-green-500 rounded-full animate-pulse"></span> {chatListDetails.find(c => c.userId === activeChatUser)?.name}
                                        </div>
                                        <button onClick={endChat} className="text-xs text-red-500 hover:bg-red-50 px-3 py-1 rounded-lg border border-red-100 transition-colors">End Chat</button>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-4 space-y-4">
                                        {chatHistory.map(msg => (
                                            <div key={msg.id} className={`flex ${msg.sender === 'Admin' ? 'justify-end' : 'justify-start'}`}>
                                                <div className={`max-w-[85%] p-3 rounded-2xl text-sm shadow-sm ${msg.sender === 'Admin' ? 'bg-primary text-white rounded-br-none' : 'bg-white text-gray-800 border border-gray-200 rounded-bl-none'}`}>
                                                    {msg.image && <img src={msg.image} className="rounded-lg mb-2 max-w-full" alt="" />}
                                                    {msg.text}
                                                    <div className={`text-[9px] mt-1 text-right ${msg.sender === 'Admin' ? 'text-white/70' : 'text-gray-400'}`}>{new Date(msg.timestamp).toLocaleTimeString()}</div>
                                                </div>
                                            </div>
                                        ))}
                                        <div ref={chatEndRef}></div>
                                    </div>
                                    <div className="p-4 bg-white border-t border-gray-200 flex gap-2">
                                        <input type="file" ref={chatFileRef} className="hidden" onChange={handleAdminChatImage} accept="image/*" />
                                        <button onClick={() => chatFileRef.current?.click()} className="text-gray-400 hover:text-primary"><span className="material-symbols-outlined">image</span></button>
                                        <input type="text" className="flex-1 bg-gray-100 border-none rounded-full px-4 text-sm focus:ring-2 focus:ring-primary/20 outline-none" placeholder="Type a message..." value={chatMessage} onChange={e => setChatMessage(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendAdminMessage()} />
                                        <button onClick={sendAdminMessage} className="bg-primary text-white size-10 rounded-full flex items-center justify-center hover:bg-primary-dark shadow-lg shadow-primary/30"><span className="material-symbols-outlined text-lg">send</span></button>
                                    </div>
                                </>
                            ) : (
                                <div className="flex-1 flex items-center justify-center text-gray-400 flex-col gap-2">
                                    <span className="material-symbols-outlined text-5xl opacity-20">chat_bubble</span>
                                    <span>Select a user to start chatting</span>
                                </div>
                            )}
                        </div>
                    </div>
                )}
                
                {/* --- TASKS TAB --- */}
                {activeTab === 'tasks' && hasPermission('settings') && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fade-in max-w-6xl mx-auto">
                        <div className={cardClass}>
                            <h3 className="font-bold text-gray-800 mb-4">Create Daily Task</h3>
                            <div className="space-y-4">
                                <input type="text" placeholder="Task Title" className={inputClass} value={newTask.title} onChange={e => setNewTask({...newTask, title: e.target.value})} />
                                <textarea placeholder="Description" className={inputClass} value={newTask.description} onChange={e => setNewTask({...newTask, description: e.target.value})} rows={2} />
                                <input type="text" placeholder="Task Link" className={inputClass} value={newTask.link} onChange={e => setNewTask({...newTask, link: e.target.value})} />
                                <div className="grid grid-cols-2 gap-4">
                                    <input type="number" placeholder="Reward Amount" className={inputClass} value={newTask.reward || ''} onChange={e => setNewTask({...newTask, reward: Number(e.target.value)})} />
                                    <select className={inputClass} value={newTask.rewardDest} onChange={e => setNewTask({...newTask, rewardDest: e.target.value as any})}>
                                        <option value="bankMoney">Bank Money</option>
                                        <option value="bonusMoney">Bonus Money</option>
                                        <option value="balance">Winning Balance</option>
                                    </select>
                                </div>
                                <div className="flex gap-4 items-center">
                                    <div className="flex-1">
                                        <label className={labelClass}>Task Type</label>
                                        <select className={inputClass} value={newTask.type} onChange={e => setNewTask({...newTask, type: e.target.value as any})}>
                                            <option value="onetime">One Time</option>
                                            <option value="daily">Daily Recurring</option>
                                        </select>
                                    </div>
                                    <div className="flex-1">
                                        <label className={labelClass}>Expiry (Optional)</label>
                                        <input type="date" className={inputClass} value={expiryInput} onChange={e => setExpiryInput(e.target.value)} />
                                    </div>
                                </div>
                                <div>
                                    <label className={labelClass}>Task Image</label>
                                    <input type="file" ref={taskImageRef} onChange={handleTaskImageUpload} className="hidden" accept="image/*" />
                                    <button onClick={() => taskImageRef.current?.click()} className="w-full border-2 border-dashed border-gray-300 rounded-xl p-4 text-gray-500 font-bold hover:bg-gray-50">{newTask.image ? 'Image Selected' : 'Upload Image'}</button>
                                </div>
                                <button onClick={handleCreateTask} className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 shadow-lg">Create Task</button>
                            </div>
                        </div>
                        
                        <div className="space-y-4">
                            {adminTasks.map(t => (
                                <div key={t.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex gap-4 hover:shadow-md transition-shadow">
                                    <div className="size-16 bg-gray-100 rounded-lg shrink-0 overflow-hidden">
                                        {t.image ? <img src={t.image} className="w-full h-full object-cover" alt="" /> : <div className="w-full h-full flex items-center justify-center text-gray-400"><span className="material-symbols-outlined">task</span></div>}
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex justify-between items-start">
                                            <h4 className="font-bold text-gray-900">{t.title}</h4>
                                            <span className="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded">₹{t.reward}</span>
                                        </div>
                                        <p className="text-xs text-gray-500 mt-1 line-clamp-1">{t.description}</p>
                                        <div className="flex items-center gap-2 mt-2">
                                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${t.type === 'daily' ? 'bg-orange-50 text-orange-600 border-orange-100' : 'bg-blue-50 text-blue-600 border-blue-100'}`}>{t.type === 'daily' ? 'DAILY' : 'ONE-TIME'}</span>
                                            <span className="text-[10px] text-gray-400">{t.rewardDest === 'bankMoney' ? 'Bank' : t.rewardDest === 'bonusMoney' ? 'Bonus' : 'Win'} Wallet</span>
                                            <button onClick={() => handleDeleteTask(t.id)} className="ml-auto text-red-500 hover:bg-red-50 p-1 rounded"><span className="material-symbols-outlined text-sm">delete</span></button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            {adminTasks.length === 0 && <div className="text-center py-10 text-gray-400 font-bold">No active tasks</div>}
                        </div>
                    </div>
                )}
                
                {/* --- NOTIFICATIONS TAB --- */}
                {activeTab === 'notifications' && hasPermission('notifications') && (
                     <div className="max-w-2xl mx-auto animate-fade-in bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
                         <div className="text-center mb-6">
                            <div className="size-16 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner">
                                <span className="material-symbols-outlined text-3xl">campaign</span>
                            </div>
                            <h2 className="text-2xl font-bold text-gray-900">Broadcast Center</h2>
                            <p className="text-gray-500 text-sm">Send updates to all users</p>
                         </div>
                         
                         <div className="space-y-5">
                            <input type="text" placeholder="Notification Title" className={inputClass} value={notifTitle} onChange={e => setNotifTitle(e.target.value)} />
                            <textarea placeholder="Message Body..." className={inputClass} rows={4} value={notifMessage} onChange={e => setNotifMessage(e.target.value)} />
                            <input type="text" placeholder="Action Link (Optional)" className={inputClass} value={notifLink} onChange={e => setNotifLink(e.target.value)} />
                            
                            <div>
                                <label className={labelClass}>Target Audience</label>
                                <select className={inputClass} value={notifTarget} onChange={e => setNotifTarget(e.target.value)}>
                                    <option value="all">All Users</option>
                                    <option value="single">Single User (Enter ID)</option>
                                </select>
                            </div>
                            
                            {notifTarget !== 'all' && (
                                <input type="text" placeholder="Enter User ID" className={inputClass} value={notifTarget === 'all' ? '' : notifTarget} onChange={e => setNotifTarget(e.target.value)} />
                            )}
                            
                            <div>
                                <label className={labelClass}>Attachment Image</label>
                                <input type="file" onChange={handleNotifImageUpload} className={inputClass} accept="image/*" />
                            </div>
                            
                            <button onClick={sendBroadcastNotification} className="w-full bg-indigo-600 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-500/30 hover:bg-indigo-700 transition-transform active:scale-95 text-lg flex items-center justify-center gap-2">
                                <span className="material-symbols-outlined">send</span> Send Broadcast
                            </button>
                         </div>
                     </div>
                )}

                {/* --- MLM TAB --- */}
                {activeTab === 'mlm' && hasPermission('users') && (
                    <div className="max-w-xl mx-auto animate-fade-in bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
                        <div className="text-center mb-6">
                            <div className="size-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner">
                                <span className="material-symbols-outlined text-3xl">hub</span>
                            </div>
                            <h2 className="text-2xl font-bold text-gray-900">Network Manager</h2>
                            <p className="text-gray-500 text-sm">Fix hierarchy issues manually</p>
                         </div>

                        <div className="space-y-6">
                            <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
                                <label className={labelClass}>Search User to Modify</label>
                                <div className="flex gap-2">
                                    <input type="text" placeholder="Enter User ID or Name" className={inputClass} value={mlmSearch} onChange={e => setMlmSearch(e.target.value)} />
                                    <button onClick={handleMlmSearch} className="bg-blue-600 text-white px-4 rounded-xl font-bold"><span className="material-symbols-outlined">search</span></button>
                                </div>
                            </div>
                            
                            {mlmTargetUser && (
                                <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl animate-fade-in">
                                    <div className="flex items-center gap-3 mb-4">
                                        <div className="size-10 bg-white rounded-full flex items-center justify-center font-bold text-blue-600">{mlmTargetUser.name.charAt(0)}</div>
                                        <div>
                                            <div className="font-bold text-gray-900">{mlmTargetUser.name}</div>
                                            <div className="text-xs text-gray-500">Current Upline: {mlmTargetUser.referredBy || 'None'}</div>
                                        </div>
                                    </div>
                                    
                                    <label className={labelClass}>New Upline Referral Code</label>
                                    <div className="flex gap-2">
                                        <input type="text" className={inputClass} placeholder="Enter New Upline Code" value={newUplineCode} onChange={e => setNewUplineCode(e.target.value)} />
                                        <button onClick={handleUpdateUpline} className="bg-green-600 text-white px-4 rounded-xl font-bold shadow-md hover:bg-green-700">Update</button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                )}
                
                {/* --- ADMINS MANAGEMENT --- */}
                {activeTab === 'admins' && user.adminRole === 'super' && (
                    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
                         <div className={cardClass}>
                             <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                                 <span className="material-symbols-outlined text-purple-600">person_add</span> Create Guest Admin
                             </h3>
                             <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                                 <input type="text" placeholder="Name" className={inputClass} value={newAdminName} onChange={e => setNewAdminName(e.target.value)} />
                                 <input type="text" placeholder="Login ID" className={inputClass} value={newAdminId} onChange={e => setNewAdminId(e.target.value)} />
                                 <div className="relative">
                                    <input type={showNewAdminPass ? "text" : "password"} placeholder="Password" className={inputClass} value={newAdminPass} onChange={e => setNewAdminPass(e.target.value)} />
                                    <button onClick={() => setShowNewAdminPass(!showNewAdminPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><span className="material-symbols-outlined text-sm">visibility</span></button>
                                 </div>
                             </div>
                             
                             <div className="mb-4">
                                 <label className={labelClass}>Permissions</label>
                                 <div className="flex flex-wrap gap-2">
                                     {AVAILABLE_PERMISSIONS.map(perm => (
                                         <button 
                                            key={perm.id}
                                            onClick={() => togglePermission(perm.id)}
                                            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${selectedPermissions.includes(perm.id) ? 'bg-purple-100 text-purple-700 border-purple-200' : 'bg-gray-50 text-gray-500 border-gray-200'}`}
                                         >
                                             {perm.label}
                                         </button>
                                     ))}
                                 </div>
                             </div>
                             
                             <button onClick={handleCreateAdmin} className="bg-purple-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-purple-500/30 hover:bg-purple-700 transition-colors">Create Admin</button>
                         </div>
                         
                         <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                             <h3 className="font-bold text-gray-800 mb-4">Guest Admins List</h3>
                             <div className="space-y-3">
                                 {users.filter(u => u.isAdmin && u.adminRole === 'guest').map(admin => (
                                     <div key={admin.identifier} className="flex justify-between items-center bg-gray-50 p-4 rounded-xl border border-gray-100">
                                         <div>
                                             <div className="font-bold text-gray-900">{admin.name}</div>
                                             <div className="text-xs text-gray-500">ID: {admin.identifier} • Access: {admin.permissions?.length || 0} Modules</div>
                                         </div>
                                         <button onClick={() => handleDeleteAdmin(admin.identifier)} className="text-red-500 hover:bg-red-100 p-2 rounded-lg transition-colors"><span className="material-symbols-outlined">delete</span></button>
                                     </div>
                                 ))}
                                 {users.filter(u => u.isAdmin && u.adminRole === 'guest').length === 0 && <div className="text-center text-gray-400 py-4">No guest admins found.</div>}
                             </div>
                         </div>
                    </div>
                )}
            </main>

            {/* --- MODALS --- */}
            
            {/* User Edit Modal */}
            {editMode && selectedUser && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fade-in">
                    <div className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl relative">
                        <button onClick={() => {setEditMode(false); setSelectedUser(null);}} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"><span className="material-symbols-outlined">close</span></button>
                        <h3 className="font-bold text-lg mb-4">Edit User: {selectedUser.name}</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div><label className={labelClass}>Name</label><input className={inputClass} value={editedUser.name || ''} onChange={e => setEditedUser({...editedUser, name: e.target.value})} /></div>
                            <div><label className={labelClass}>Password</label><input className={inputClass} value={editedUser.password || ''} onChange={e => setEditedUser({...editedUser, password: e.target.value})} /></div>
                            <div><label className={labelClass}>Balance</label><input type="number" className={inputClass} value={editedUser.balance} onChange={e => setEditedUser({...editedUser, balance: Number(e.target.value)})} /></div>
                            <div><label className={labelClass}>Bank Money</label><input type="number" className={inputClass} value={editedUser.bankMoney} onChange={e => setEditedUser({...editedUser, bankMoney: Number(e.target.value)})} /></div>
                            <div className="col-span-2">
                                <label className="flex items-center gap-2 cursor-pointer bg-gray-50 p-3 rounded-lg border border-gray-200">
                                    <input type="checkbox" checked={editedUser.isBlocked} onChange={e => setEditedUser({...editedUser, isBlocked: e.target.checked})} className="size-5 accent-red-500" />
                                    <span className="font-bold text-gray-700">Block User Account</span>
                                </label>
                            </div>
                        </div>
                        <button onClick={handleSaveUser} className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl mt-6 hover:bg-blue-700">Save Changes</button>
                    </div>
                </div>
            )}

            {/* Bonus Modal */}
            {showBonusModal && selectedUser && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fade-in">
                    <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl relative text-center">
                         <button onClick={() => {setShowBonusModal(false); setSelectedUser(null);}} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"><span className="material-symbols-outlined">close</span></button>
                         <div className="size-16 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-inner">
                             <span className="material-symbols-outlined text-3xl">star</span>
                         </div>
                         <h3 className="font-bold text-lg mb-1">Add Bonus</h3>
                         <p className="text-gray-500 text-sm mb-4">Credit promotional balance to {selectedUser.name}</p>
                         <input type="number" placeholder="Amount" className={`${inputClass} text-center text-xl font-bold`} value={bonusAmount} onChange={e => setBonusAmount(e.target.value)} />
                         <p className="text-xs text-gray-400 mt-2 mb-4">Note: User must wager 10x this amount to unlock.</p>
                         <button onClick={handleGiveBonus} className="w-full bg-yellow-500 text-white font-bold py-3 rounded-xl hover:bg-yellow-600 shadow-lg shadow-yellow-500/30">Credit Bonus</button>
                    </div>
                </div>
            )}
            
            {/* Create User Modal */}
            {showCreateUserModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fade-in">
                    <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl relative">
                        <button onClick={() => setShowCreateUserModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"><span className="material-symbols-outlined">close</span></button>
                        <h3 className="font-bold text-lg mb-4 text-gray-800">Manually Create User</h3>
                        <div className="space-y-4">
                            <input type="text" placeholder="Full Name" className={inputClass} value={newUser.name} onChange={e => setNewUser({...newUser, name: e.target.value})} />
                            <input type="text" placeholder="Phone/Email (Login ID)" className={inputClass} value={newUser.identifier} onChange={e => setNewUser({...newUser, identifier: e.target.value})} />
                            <input type="text" placeholder="Password" className={inputClass} value={newUser.password} onChange={e => setNewUser({...newUser, password: e.target.value})} />
                            <input type="text" placeholder="Upline Code (Optional)" className={inputClass} value={newUser.referralCode} onChange={e => setNewUser({...newUser, referralCode: e.target.value})} />
                            <button onClick={handleCreateUser} className="w-full bg-primary text-white font-bold py-3 rounded-xl shadow-lg mt-2">Create Account</button>
                        </div>
                    </div>
                </div>
            )}
            
            {/* View QR Modal */}
            {viewQr && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in" onClick={() => setViewQr(null)}>
                    <img src={viewQr} className="max-w-full max-h-[80vh] rounded-2xl shadow-2xl border-4 border-white" alt="Full QR" />
                </div>
            )}
            
            {/* Payment Processing Modal */}
            {processingTransaction && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fade-in">
                    <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl relative text-center">
                         <button onClick={() => setProcessingTransaction(null)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"><span className="material-symbols-outlined">close</span></button>
                         <h3 className="font-bold text-lg mb-4">Process Withdrawal</h3>
                         <div className="bg-blue-50 p-4 rounded-xl mb-4 border border-blue-100">
                             <div className="text-sm text-gray-500 uppercase font-bold">Amount</div>
                             <div className="text-3xl font-black text-blue-600">₹{processingTransaction.amount}</div>
                             <div className="text-xs text-gray-400 mt-1">{processingTransaction.userName}</div>
                         </div>
                         
                         <div className="space-y-3">
                             <button onClick={() => handleAdminPayment('gpay', processingTransaction.upiId!, processingTransaction.amount, processingTransaction.userName)} className="w-full bg-white border border-gray-200 hover:bg-gray-50 py-3 rounded-xl font-bold text-gray-700 flex items-center justify-center gap-2">Pay via GPay</button>
                             <button onClick={() => handleAdminPayment('phonepe', processingTransaction.upiId!, processingTransaction.amount, processingTransaction.userName)} className="w-full bg-white border border-gray-200 hover:bg-gray-50 py-3 rounded-xl font-bold text-gray-700 flex items-center justify-center gap-2">Pay via PhonePe</button>
                             <button onClick={() => handleAdminPayment('paytm', processingTransaction.upiId!, processingTransaction.amount, processingTransaction.userName)} className="w-full bg-white border border-gray-200 hover:bg-gray-50 py-3 rounded-xl font-bold text-gray-700 flex items-center justify-center gap-2">Pay via Paytm</button>
                             
                             <div className="h-px bg-gray-200 my-2"></div>
                             
                             <div className="flex gap-2">
                                 <button onClick={() => handleTransaction(processingTransaction.id, 'Approved')} className="flex-1 bg-green-500 text-white py-3 rounded-xl font-bold hover:bg-green-600 shadow-md">Mark Paid</button>
                                 <div className="relative">
                                     <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => { setProofingTransactionId(processingTransaction.id); handleProofUpload(e); }} accept="image/*" />
                                     <button className="bg-gray-800 text-white px-4 py-3 rounded-xl font-bold hover:bg-black"><span className="material-symbols-outlined">upload</span></button>
                                 </div>
                             </div>
                         </div>
                    </div>
                </div>
            )}

        </div>
    );
};
