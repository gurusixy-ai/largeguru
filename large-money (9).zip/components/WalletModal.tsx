import React, { useState, useEffect, useRef } from 'react';
import { UserProfile } from '../types';

interface WalletModalProps {
    onClose: () => void;
    userId: string;
    userName: string;
    initialTab: 'deposit' | 'withdraw';
    user: UserProfile; 
    onUpdateUser: (user: UserProfile) => void;
}

const WalletModal: React.FC<WalletModalProps> = ({ onClose, userId, userName, initialTab, user, onUpdateUser }) => {
    const [tab, setTab] = useState<'deposit' | 'withdraw'>(initialTab);
    const [amount, setAmount] = useState('');
    const [refId, setRefId] = useState('');
    const [animateCard, setAnimateCard] = useState('');
    
    // Withdrawal QR State
    const [withdrawalQr, setWithdrawalQr] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    // Config from storage
    const adminUpi = localStorage.getItem('ncci_upi') || '8810572406@ptyes';
    const adminQr = localStorage.getItem('ncci_qr') || 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=8810572406@ptyes';

    useEffect(() => {
        // Trigger animation when tab changes
        setAnimateCard(tab === 'deposit' ? 'bank' : 'winnable');
        
        // Auto-fill UPI ID if withdrawing and user has one saved in bankDetails
        if (tab === 'withdraw' && user.bankDetails?.upiId) {
             setRefId(user.bankDetails.upiId);
        } else if (tab === 'deposit') {
             setRefId(''); // Clear for UTR
        }
    }, [tab, user.bankDetails?.upiId]);

    const handleQrUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64 = reader.result as string;
                setWithdrawalQr(base64);
            };
            reader.readAsDataURL(file);
        }
    };

    // --- New Function: Handle Deep Linking for Payments ---
    const handleAppPayment = (app: 'gpay' | 'phonepe' | 'paytm' | 'any') => {
        if (!amount || Number(amount) < 50) {
            alert("Please enter a valid amount first (Min ₹50)");
            return;
        }

        const params = `pa=${adminUpi}&pn=NCCI Game&am=${amount}&cu=INR`;
        let url = `upi://pay?${params}`;

        // Specific App Schemes
        if (app === 'gpay') url = `tez://upi/pay?${params}`;
        if (app === 'phonepe') url = `phonepe://pay?${params}`;
        if (app === 'paytm') url = `paytmmp://pay?${params}`;

        // Open the Intent
        window.location.href = url;
    };
    // -----------------------------------------------------

    const handleSubmit = () => {
        if (!amount || !refId) {
            alert("Please fill all fields");
            return;
        }

        const numAmount = Number(amount);

        // Validation Logic
        if (tab === 'deposit') {
            if (numAmount < 50) {
                alert("Minimum Deposit limit is ₹50");
                return;
            }
        } else if (tab === 'withdraw') {
            if (numAmount < 100) {
                alert("Minimum Withdrawal limit is ₹100");
                return;
            }
            if (numAmount > user.balance) {
                alert("Insufficient Winnings to Withdraw. You can only withdraw from Winning Balance.");
                return;
            }
            if (!withdrawalQr) {
                alert("Please upload your Payment QR Code");
                return;
            }
        }

        const trans = {
            id: Math.random().toString(36).substr(2, 9),
            userId,
            userName,
            type: tab === 'deposit' ? 'Deposit' : 'Withdrawal',
            amount: numAmount,
            status: 'Pending',
            timestamp: Date.now(),
            utr: tab === 'deposit' ? refId : undefined,
            upiId: tab === 'withdraw' ? refId : undefined,
            userQrCode: tab === 'withdraw' ? withdrawalQr : undefined
        };

        const existing = JSON.parse(localStorage.getItem('ncci_transactions') || '[]');
        localStorage.setItem('ncci_transactions', JSON.stringify([...existing, trans]));

        // IMMEDIATE WITHDRAWAL DEDUCTION
        if (tab === 'withdraw') {
            let updatedUser = { 
                ...user, 
                balance: user.balance - numAmount,
            };
            // Save UPI ID to bankDetails if exists
            if (user.bankDetails) {
                updatedUser = {
                    ...updatedUser,
                    bankDetails: {
                        ...user.bankDetails,
                        upiId: refId
                    }
                };
            }
            onUpdateUser(updatedUser); 
        }
        
        alert(`${tab === 'deposit' ? 'Deposit' : 'Withdrawal'} request submitted! Admin will approve shortly.`);
        onClose();
    };

    const WalletCard = ({ type, title, value, icon, gradient, active, subText }: any) => (
        <div className={`relative overflow-hidden rounded-2xl p-4 text-white transition-all duration-500 transform ${
            active ? 'scale-105 shadow-xl ring-2 ring-offset-2 ring-primary/50 z-10' : 'scale-100 opacity-90 grayscale-[0.3]'
        } ${gradient}`}>
            <div className="relative z-10">
                <div className="flex items-center gap-2 mb-2 opacity-90">
                    <span className="material-symbols-outlined text-sm">{icon}</span>
                    <span className="text-xs font-bold uppercase tracking-wider">{title}</span>
                </div>
                <div className="text-2xl font-bold tracking-tight">₹{value.toLocaleString()}</div>
                {subText && <div className="text-[10px] mt-1 opacity-80">{subText}</div>}
            </div>
            {/* Decorative Circle */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-white/10 rounded-full blur-2xl"></div>
        </div>
    );

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
            <div className="bg-white dark:bg-surface-dark w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl slide-up-animation border border-gray-100 dark:border-gray-700 flex flex-col max-h-[90vh]">
                
                {/* Header Tabs */}
                <div className="flex border-b border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/50">
                    <button 
                        onClick={() => setTab('deposit')} 
                        className={`flex-1 py-4 font-bold text-center transition-all relative ${
                            tab === 'deposit' ? 'text-primary' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800'
                        }`}
                    >
                        <span className="flex items-center justify-center gap-2">
                            <span className="material-symbols-outlined">add_circle</span> Deposit
                        </span>
                        {tab === 'deposit' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-primary rounded-t-full"></div>}
                    </button>
                    <button 
                        onClick={() => setTab('withdraw')} 
                        className={`flex-1 py-4 font-bold text-center transition-all relative ${
                            tab === 'withdraw' ? 'text-primary' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800'
                        }`}
                    >
                        <span className="flex items-center justify-center gap-2">
                            <span className="material-symbols-outlined">payments</span> Withdraw
                        </span>
                        {tab === 'withdraw' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-primary rounded-t-full"></div>}
                    </button>
                </div>

                <div className="p-6 overflow-y-auto custom-scrollbar">
                    
                    {/* Visual Wallet Display */}
                    <div className="space-y-4 mb-8">
                        {/* Source Wallets (Bank & Bonus) */}
                        <div className="grid grid-cols-2 gap-4">
                            <WalletCard 
                                type="bank"
                                title="Bank Money"
                                value={user.bankMoney || 0}
                                icon="lock"
                                gradient="bg-gradient-to-br from-blue-500 to-blue-700"
                                active={animateCard === 'bank'}
                                subText="Locked for Betting"
                            />
                            <WalletCard 
                                type="bonus"
                                title="Bonus"
                                value={user.bonusMoney || 0}
                                icon="stars"
                                gradient="bg-gradient-to-br from-orange-400 to-orange-600"
                                active={false}
                                subText="Wager to Unlock"
                            />
                        </div>

                        {/* Visual Flow Indicator */}
                        <div className="flex items-center justify-center gap-2 text-xs text-gray-400 font-medium">
                            <span className="h-[1px] w-12 bg-gray-200 dark:bg-gray-700"></span>
                            <span className="flex items-center gap-1">
                                <span className="material-symbols-outlined text-sm">arrow_downward</span>
                                Betting Flow
                            </span>
                            <span className="h-[1px] w-12 bg-gray-200 dark:bg-gray-700"></span>
                        </div>

                        {/* Destination Wallet (Winnable) */}
                        <WalletCard 
                            type="winnable"
                            title="Winnable Balance"
                            value={user.balance}
                            icon="account_balance_wallet"
                            gradient="bg-gradient-to-br from-green-500 to-green-700"
                            active={animateCard === 'winnable'}
                            subText="Available for Withdrawal"
                        />
                    </div>

                    {/* Forms */}
                    <div className="animate-fade-in">
                        {tab === 'deposit' ? (
                            <div className="space-y-5">
                                <div className="bg-blue-50 dark:bg-blue-900/10 p-4 rounded-xl border border-blue-100 dark:border-blue-900/30 text-center">
                                    <p className="text-sm font-bold text-gray-700 dark:text-gray-200 mb-3">Scan QR to Add Funds</p>
                                    <div className="mx-auto w-40 h-40 bg-white p-2 rounded-xl shadow-sm border border-gray-200 flex items-center justify-center overflow-hidden">
                                        <img src={adminQr} alt="QR" className="w-full h-full object-contain" />
                                    </div>
                                    <div 
                                        onClick={() => {navigator.clipboard.writeText(adminUpi); alert('UPI ID Copied')}} 
                                        className="mt-3 bg-white dark:bg-surface-dark border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 p-2.5 rounded-lg text-sm font-mono font-bold cursor-pointer hover:bg-blue-50 transition-colors flex items-center justify-center gap-2 shadow-sm"
                                    >
                                        {adminUpi} <span className="material-symbols-outlined text-sm">content_copy</span>
                                    </div>
                                </div>
                                
                                <div className="space-y-3">
                                    <label className="block text-xs font-bold text-gray-500 uppercase">Transaction Details</label>
                                    <input 
                                        type="number" 
                                        placeholder="Enter Amount (Min ₹50)" 
                                        value={amount} 
                                        onChange={e => setAmount(e.target.value)}
                                        className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-3.5 rounded-xl outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-bold" 
                                    />
                                    
                                    {/* --- NEW: Quick Pay Buttons --- */}
                                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                                        <button onClick={() => handleAppPayment('gpay')} className="flex flex-col items-center justify-center p-2 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors">
                                            <span className="font-bold text-blue-600 text-sm">GPay</span>
                                        </button>
                                        <button onClick={() => handleAppPayment('phonepe')} className="flex flex-col items-center justify-center p-2 bg-purple-50 hover:bg-purple-100 rounded-lg border border-purple-200 transition-colors">
                                            <span className="font-bold text-purple-600 text-sm">PhonePe</span>
                                        </button>
                                        <button onClick={() => handleAppPayment('paytm')} className="flex flex-col items-center justify-center p-2 bg-cyan-50 hover:bg-cyan-100 rounded-lg border border-cyan-200 transition-colors">
                                            <span className="font-bold text-cyan-600 text-sm">Paytm</span>
                                        </button>
                                        <button onClick={() => handleAppPayment('any')} className="flex flex-col items-center justify-center p-2 bg-gray-100 hover:bg-gray-200 rounded-lg border border-gray-300 transition-colors">
                                            <span className="font-bold text-gray-600 text-xs">Any UPI</span>
                                        </button>
                                    </div>
                                    {/* ------------------------------- */}

                                    <input 
                                        type="text" 
                                        placeholder="12-Digit UTR / Ref Number" 
                                        value={refId} 
                                        onChange={e => setRefId(e.target.value)}
                                        className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-3.5 rounded-xl outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-mono text-sm" 
                                    />
                                </div>
                            </div>
                        ) : (
                            <div className="space-y-5">
                                <div className="bg-green-50 dark:bg-green-900/10 p-4 rounded-xl border border-green-100 dark:border-green-900/30 flex items-center gap-4">
                                    <div className="size-12 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center text-green-600">
                                        <span className="material-symbols-outlined">account_balance</span>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 uppercase font-bold">Withdrawal Limit</p>
                                        <p className="text-lg font-bold text-gray-800 dark:text-white">Min: ₹100 <span className="text-gray-400 font-normal">|</span> Max: ₹50,000</p>
                                    </div>
                                </div>
                                
                                <div className="space-y-3">
                                    <label className="block text-xs font-bold text-gray-500 uppercase">Withdrawal Details</label>
                                    <input 
                                        type="number" 
                                        placeholder="Amount to Withdraw" 
                                        value={amount} 
                                        onChange={e => setAmount(e.target.value)}
                                        className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-3.5 rounded-xl outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-bold" 
                                    />
                                    <input 
                                        type="text" 
                                        placeholder="Your UPI ID (e.g. name@upi)" 
                                        value={refId} 
                                        onChange={e => setRefId(e.target.value)}
                                        className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-3.5 rounded-xl outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-bold" 
                                    />
                                    
                                    <div className="pt-2">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Upload Payment QR Code</label>
                                        <div className="flex items-center gap-3">
                                            <input 
                                                type="file" 
                                                ref={fileInputRef}
                                                accept="image/*"
                                                onChange={handleQrUpload}
                                                className="hidden"
                                            />
                                            <div 
                                                onClick={() => fileInputRef.current?.click()}
                                                className="size-16 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                                            >
                                                {withdrawalQr ? (
                                                    <img src={withdrawalQr} alt="QR" className="w-full h-full object-cover rounded-md" />
                                                ) : (
                                                    <span className="material-symbols-outlined text-gray-400">qr_code_2</span>
                                                )}
                                            </div>
                                            <div className="flex-1">
                                                <button 
                                                    onClick={() => fileInputRef.current?.click()}
                                                    className="text-sm font-bold text-primary hover:underline"
                                                >
                                                    {withdrawalQr ? 'Change Image' : 'Click to Upload QR'}
                                                </button>
                                                <p className="text-[10px] text-gray-400 mt-1">Upload your QR code to receive payment quickly.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        
                        <div className="flex gap-3 pt-6">
                            <button onClick={onClose} className="flex-1 py-3.5 border border-gray-200 dark:border-gray-700 rounded-xl font-bold text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                                Cancel
                            </button>
                            <button onClick={handleSubmit} className="flex-1 py-3.5 bg-primary text-white rounded-xl font-bold shadow-lg shadow-primary/30 hover:bg-primary-dark transition-transform active:scale-95 flex items-center justify-center gap-2">
                                {tab === 'deposit' ? 'Submit Deposit' : 'Request Withdrawal'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default WalletModal;