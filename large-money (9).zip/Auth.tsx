import React, { useState } from 'react';
import { UserProfile } from '../types';

interface AuthProps {
    onLogin: (user: UserProfile) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
    const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
    const [formData, setFormData] = useState({
        identifier: '',
        password: '',
        confirmPassword: '',
        name: '',
        village: '',
        block: '',
        district: '',
        otp: '',
        referralCode: ''
    });
    
    const [otpSent, setOtpSent] = useState(false);
    const [generatedOtp, setGeneratedOtp] = useState('');

    // Password Visibility States
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);

    const sendOtp = () => {
        if (!formData.identifier) {
            alert("Please enter Phone Number/Email first.");
            return;
        }

        // Get Config
        const config = JSON.parse(localStorage.getItem('ncci_admin_config') || '{}');
        const service = config.otpService || 'mock';

        const otp = Math.floor(1000 + Math.random() * 9000).toString();
        setGeneratedOtp(otp);
        setOtpSent(true);
        
        let msg = `[NCCI GATEWAY] Your OTP is: ${otp}\n(Sent to ${formData.identifier})`;
        
        // Simulate different services based on admin selection
        if (service === 'email' && config.gmailUser) {
            msg = `[GMAIL SERVICE]\nFrom: ${config.gmailUser}\nTo: ${formData.identifier}\n\nSubject: NCCI Verification OTP\nYour One Time Password is ${otp}`;
        } else if (service === 'whatsapp' && config.whatsappApiKey) {
            msg = `[WHATSAPP API]\nSent to: ${formData.identifier}\nMessage: Your NCCI OTP is ${otp}`;
        } else if (service === 'sms' && config.smsApiKey) {
            msg = `[SMS GATEWAY]\nSent to: ${formData.identifier}\nMessage: Your NCCI OTP is ${otp}`;
        }

        // In a real app, call the backend here using the stored API Keys
        setTimeout(() => {
            alert(msg);
        }, 500);
    };

    const verifyOtp = () => {
        if (formData.otp === generatedOtp) {
            return true;
        }
        alert("Invalid OTP");
        return false;
    };

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        
        // Super Admin Check (Hardcoded)
        if (formData.identifier === 'ncci.gov@gmail.com' && formData.password === 'Guru563@#') {
            onLogin({
                name: 'Super Administrator',
                identifier: 'ncci.gov@gmail.com',
                password: '',
                village: 'Delhi',
                block: 'Central',
                district: 'New Delhi',
                balance: 1000000,
                bankMoney: 0,
                bonusMoney: 0,
                bonusWagerTarget: 0,
                bonusWagerProgress: 0,
                isAdmin: true,
                adminRole: 'super', // Grant Super Access
                isBlocked: false,
                referralCode: 'ADMIN',
                referralIncome: 0,
                withdrawalActive: true,
                mlmWallet: 0,
                joinedAt: Date.now(),
                lastActiveDeposit: 0
            });
            return;
        }

        // User / Guest Admin Login
        const storedUsers = JSON.parse(localStorage.getItem('ncci_users') || '[]');
        const user = storedUsers.find((u: UserProfile) => u.identifier === formData.identifier && u.password === formData.password);

        if (user) {
            onLogin(user);
        } else {
            alert('Invalid credentials or user not found.');
        }
    };

    const handleSignup = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData.password !== formData.confirmPassword) {
            alert("Passwords do not match");
            return;
        }
        
        // OTP Check removed for Signup as requested
        
        const storedUsers = JSON.parse(localStorage.getItem('ncci_users') || '[]');
        if (storedUsers.find((u: UserProfile) => u.identifier === formData.identifier)) {
            alert("User already exists");
            return;
        }

        // Generate Referral Code: NCCI + Last 4 digits of ID
        const suffix = formData.identifier.replace(/\D/g, '').slice(-4) || Math.floor(Math.random() * 9000).toString();
        const myReferralCode = `NCCI${suffix}`;

        const newUser: UserProfile = {
            name: formData.name,
            identifier: formData.identifier,
            password: formData.password,
            village: formData.village,
            block: formData.block,
            district: formData.district,
            balance: 0,
            bankMoney: 0,
            bonusMoney: 0,
            bonusWagerTarget: 0,
            bonusWagerProgress: 0,
            isAdmin: false,
            isBlocked: false,
            referralCode: myReferralCode,
            referredBy: formData.referralCode || undefined,
            referralIncome: 0,
            withdrawalActive: false,
            mlmWallet: 0,
            joinedAt: Date.now(),
            lastActiveDeposit: 0
        };

        localStorage.setItem('ncci_users', JSON.stringify([...storedUsers, newUser]));
        alert(`Account created successfully!\nYour Referral Code: ${myReferralCode}\nPlease login.`);
        setMode('login');
    };

    const handleForgotPass = (e: React.FormEvent) => {
        e.preventDefault();
        if (!otpSent || !verifyOtp()) return;

        const storedUsers = JSON.parse(localStorage.getItem('ncci_users') || '[]');
        const userIndex = storedUsers.findIndex((u: UserProfile) => u.identifier === formData.identifier);

        if (userIndex === -1) {
            alert("User not found.");
            return;
        }

        storedUsers[userIndex].password = formData.password;
        localStorage.setItem('ncci_users', JSON.stringify(storedUsers));
        alert("Password reset successfully. Please Login.");
        setMode('login');
    };

    // --- 3D Design Styles (Vibrant Color Scheme - NO BLACK) ---
    const inputContainerStyle = "relative group";
    const iconStyle = "absolute left-4 top-1/2 -translate-y-1/2 text-white/70 group-focus-within:text-white transition-colors z-10 material-symbols-outlined text-[20px] drop-shadow-sm";
    const inputStyle = "w-full bg-white/10 border border-white/20 rounded-2xl pl-12 pr-4 py-4 text-white placeholder-white/50 outline-none focus:bg-white/20 focus:border-white/50 focus:ring-4 focus:ring-white/10 transition-all font-medium backdrop-blur-md shadow-inner";
    const labelStyle = "block text-[10px] font-bold text-white/80 uppercase mb-2 tracking-widest ml-1 shadow-sm";
    
    return (
        <div className="min-h-screen bg-[conic-gradient(at_top_right,_var(--tw-gradient-stops))] from-indigo-500 via-purple-500 to-pink-500 relative flex items-center justify-center p-4 overflow-hidden font-display">
            
            {/* 3D Animated Background Blobs (No Black) */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-blue-400 rounded-full mix-blend-multiply filter blur-[100px] opacity-70 animate-pulse"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-purple-400 rounded-full mix-blend-multiply filter blur-[100px] opacity-70 animate-pulse delay-1000"></div>
                <div className="absolute top-[40%] left-[30%] w-[300px] h-[300px] bg-pink-400 rounded-full mix-blend-multiply filter blur-[80px] opacity-60 animate-pulse delay-2000"></div>
            </div>

            {/* Glass Texture Overlay */}
            <div className="absolute inset-0 bg-white/5 backdrop-blur-[1px]"></div>

            {/* Main 3D Glass Card */}
            <div className="relative z-10 w-full max-w-[480px]">
                {/* Top Floating Logo */}
                <div className="absolute -top-12 left-1/2 -translate-x-1/2 z-20">
                     <div className="size-24 bg-gradient-to-tr from-white to-blue-50 rounded-[2rem] shadow-[0_20px_50px_rgba(8,_112,_184,_0.7)] flex items-center justify-center transform hover:rotate-6 transition-all duration-500 border-4 border-white/40">
                        <span className="material-symbols-outlined text-5xl text-indigo-600 drop-shadow-lg">casino</span>
                     </div>
                </div>

                <div className="relative bg-white/10 backdrop-blur-xl border border-white/30 rounded-[3rem] shadow-[0_40px_80px_-20px_rgba(0,0,0,0.3)] overflow-hidden transition-all duration-500 hover:shadow-[0_50px_100px_-20px_rgba(0,0,0,0.4)] mt-8">
                    
                    {/* Header Text */}
                    <div className="pt-16 pb-6 text-center px-8 relative">
                         <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-white/10 to-transparent pointer-events-none"></div>
                         <h1 className="text-3xl font-black text-white tracking-tight drop-shadow-lg mb-1">
                            LARGE MONEY <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-300">GAME</span>
                         </h1>
                         <p className="text-white/80 text-xs font-bold uppercase tracking-[0.3em] drop-shadow-sm">Secure Gaming Gateway</p>
                    </div>

                    {/* Form Container */}
                    <div className="px-8 pb-10">
                        {mode === 'login' && (
                            <form onSubmit={handleLogin} className="space-y-6 animate-fade-in">
                                <div className={inputContainerStyle}>
                                    <label className={labelStyle}>Login ID</label>
                                    <span className={iconStyle}>person</span>
                                    <input 
                                        type="text" 
                                        className={inputStyle}
                                        placeholder="Phone or Email"
                                        value={formData.identifier}
                                        onChange={e => setFormData({...formData, identifier: e.target.value})}
                                        required
                                    />
                                </div>
                                
                                <div className={inputContainerStyle}>
                                    <label className={labelStyle}>Password</label>
                                    <span className={iconStyle}>lock</span>
                                    <input 
                                        type={showPassword ? "text" : "password"}
                                        className={inputStyle}
                                        placeholder="••••••••"
                                        value={formData.password}
                                        onChange={e => setFormData({...formData, password: e.target.value})}
                                        required
                                    />
                                    <button 
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-4 top-[38px] text-white/60 hover:text-white transition-colors"
                                    >
                                        <span className="material-symbols-outlined text-[20px]">
                                            {showPassword ? 'visibility' : 'visibility_off'}
                                        </span>
                                    </button>
                                </div>
                                
                                <div className="flex justify-end">
                                    <button 
                                        type="button" 
                                        onClick={() => {setMode('forgot'); setOtpSent(false); setFormData({...formData, identifier: '', password: ''}); setShowPassword(false);}} 
                                        className="text-xs text-white font-bold hover:text-yellow-300 transition-colors drop-shadow-sm"
                                    >
                                        Forgot Password?
                                    </button>
                                </div>

                                <button type="submit" className="w-full bg-gradient-to-r from-white to-gray-100 hover:from-white hover:to-white text-indigo-700 font-black py-4 rounded-2xl shadow-[0_20px_40px_-15px_rgba(255,255,255,0.4)] transform active:scale-[0.98] transition-all relative overflow-hidden group/btn text-lg">
                                    <span className="relative z-10 flex items-center justify-center gap-2">
                                        Enter Game <span className="material-symbols-outlined text-sm">arrow_forward_ios</span>
                                    </span>
                                </button>
                            </form>
                        )}

                        {mode === 'signup' && (
                            <form onSubmit={handleSignup} className="space-y-4 animate-fade-in">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className={inputContainerStyle}>
                                        <label className={labelStyle}>Full Name</label>
                                        <span className={iconStyle}>badge</span>
                                        <input type="text" className={inputStyle} required placeholder="Your Name"
                                            value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                                    </div>
                                    <div className={inputContainerStyle}>
                                        <label className={labelStyle}>Login ID</label>
                                        <span className={iconStyle}>alternate_email</span>
                                        <input type="text" className={inputStyle} required placeholder="Phone/Email"
                                            value={formData.identifier} onChange={e => setFormData({...formData, identifier: e.target.value})} />
                                    </div>
                                </div>
                                
                                <div className="grid grid-cols-3 gap-2">
                                    <div className="relative">
                                        <input type="text" className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-3 text-sm text-white placeholder-white/50 outline-none focus:bg-white/20 focus:border-white/50" required placeholder="Village"
                                            value={formData.village} onChange={e => setFormData({...formData, village: e.target.value})} />
                                    </div>
                                    <div className="relative">
                                        <input type="text" className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-3 text-sm text-white placeholder-white/50 outline-none focus:bg-white/20 focus:border-white/50" required placeholder="Block"
                                            value={formData.block} onChange={e => setFormData({...formData, block: e.target.value})} />
                                    </div>
                                    <div className="relative">
                                        <input type="text" className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-3 text-sm text-white placeholder-white/50 outline-none focus:bg-white/20 focus:border-white/50" required placeholder="District"
                                            value={formData.district} onChange={e => setFormData({...formData, district: e.target.value})} />
                                    </div>
                                </div>
                                
                                <div className={inputContainerStyle}>
                                    <label className={labelStyle}>Referral Code (Optional)</label>
                                    <span className={iconStyle}>group_add</span>
                                    <input type="text" className={inputStyle} 
                                        placeholder="Enter Upline Code"
                                        value={formData.referralCode} onChange={e => setFormData({...formData, referralCode: e.target.value})} />
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div className={inputContainerStyle}>
                                        <label className={labelStyle}>Password</label>
                                        <span className={iconStyle}>lock</span>
                                        <input 
                                            type={showPassword ? "text" : "password"}
                                            className={inputStyle} 
                                            required placeholder="Create"
                                            value={formData.password} 
                                            onChange={e => setFormData({...formData, password: e.target.value})} 
                                        />
                                    </div>
                                    <div className={inputContainerStyle}>
                                        <label className={labelStyle}>Confirm</label>
                                        <span className={iconStyle}>lock_reset</span>
                                        <input 
                                            type={showConfirmPassword ? "text" : "password"}
                                            className={inputStyle} 
                                            required placeholder="Confirm"
                                            value={formData.confirmPassword} 
                                            onChange={e => setFormData({...formData, confirmPassword: e.target.value})} 
                                        />
                                    </div>
                                </div>

                                <button type="submit" className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400 text-white font-black py-4 rounded-2xl shadow-[0_10px_30px_-5px_rgba(251,191,36,0.5)] transform active:scale-[0.98] transition-all relative overflow-hidden group/btn mt-2">
                                    <span className="relative z-10 flex items-center justify-center gap-2 text-lg">
                                        Create Account
                                    </span>
                                </button>
                            </form>
                        )}

                        {mode === 'forgot' && (
                             <form onSubmit={handleForgotPass} className="space-y-6 animate-fade-in">
                                <div className="text-center mb-6">
                                    <div className="inline-flex size-16 rounded-full bg-white/20 items-center justify-center mb-3 border border-white/30 backdrop-blur-md">
                                        <span className="material-symbols-outlined text-3xl text-yellow-300">lock_reset</span>
                                    </div>
                                    <h3 className="text-xl font-bold text-white">Reset Password</h3>
                                    <p className="text-white/70 text-xs mt-1">Verify your ID to proceed</p>
                                </div>

                                <div className={inputContainerStyle}>
                                    <label className={labelStyle}>Login ID</label>
                                    <span className={iconStyle}>person</span>
                                    <input type="text" className={inputStyle} required placeholder="Phone/Email"
                                        value={formData.identifier} onChange={e => setFormData({...formData, identifier: e.target.value})} />
                                </div>
                                
                                <div className="flex gap-3 items-end">
                                    <div className="flex-1 relative group">
                                        <label className={labelStyle}>Enter OTP</label>
                                        <span className={iconStyle}>pin</span>
                                        <input type="text" className={inputStyle} 
                                            placeholder="----"
                                            value={formData.otp} onChange={e => setFormData({...formData, otp: e.target.value})} />
                                    </div>
                                    <button type="button" onClick={sendOtp} className="bg-white/20 hover:bg-white/30 border border-white/30 text-white px-4 py-4 rounded-2xl text-sm font-bold h-[58px] transition-colors disabled:opacity-50 min-w-[100px]" disabled={otpSent}>
                                        {otpSent ? 'Resend' : 'Get OTP'}
                                    </button>
                                </div>

                                <div className={inputContainerStyle}>
                                    <label className={labelStyle}>New Password</label>
                                    <span className={iconStyle}>key</span>
                                    <input 
                                        type={showPassword ? "text" : "password"}
                                        className={inputStyle} 
                                        required placeholder="New Password"
                                        value={formData.password} 
                                        onChange={e => setFormData({...formData, password: e.target.value})} 
                                    />
                                </div>

                                <button type="submit" className="w-full bg-gradient-to-r from-green-400 to-emerald-500 hover:from-green-300 hover:to-emerald-400 text-white font-black py-4 rounded-2xl shadow-[0_10px_30px_-5px_rgba(52,211,153,0.5)] transform active:scale-[0.98] transition-all mt-4 text-lg">
                                    Update Password
                                </button>
                            </form>
                        )}
                    </div>

                    {/* Footer / Switcher - Glass Style */}
                    <div className="bg-white/10 border-t border-white/20 p-6 text-center backdrop-blur-md">
                        {mode === 'login' && (
                            <p className="text-sm text-white/80 font-medium">
                                Don't have an account? <button type="button" onClick={() => {setMode('signup'); setOtpSent(false); setShowPassword(false); setShowConfirmPassword(false);}} className="text-yellow-300 font-bold hover:text-white hover:underline transition-colors ml-1">Register Now</button>
                            </p>
                        )}
                        {mode === 'signup' && (
                            <p className="text-sm text-white/80 font-medium">
                                Already registered? <button type="button" onClick={() => {setMode('login'); setOtpSent(false); setShowPassword(false); setShowConfirmPassword(false);}} className="text-yellow-300 font-bold hover:text-white hover:underline transition-colors ml-1">Login Here</button>
                            </p>
                        )}
                        {mode === 'forgot' && (
                            <button type="button" onClick={() => {setMode('login'); setOtpSent(false); setShowPassword(false);}} className="text-sm text-white/80 hover:text-white flex items-center justify-center gap-2 mx-auto transition-colors font-bold">
                                <span className="material-symbols-outlined text-sm">arrow_back</span> Back to Login
                            </button>
                        )}
                    </div>

                </div>
            </div>
            
            {/* Bottom 3D Decorative Text */}
            <div className="absolute bottom-6 left-0 right-0 text-center text-white/30 text-[10px] font-bold tracking-[0.5em] pointer-events-none">
                SECURE • FAST • TRUSTED
            </div>
        </div>
    );
};

export default Auth;